#!/bin/sh
# ПОЛНАЯ установка qBittorrent на чистую CoreELEC (Entware + qBittorrent + настройка + автозапуск).
# Запуск по SSH:  sh /storage/setup-qbittorrent.sh [папка_загрузок]
# По умолчанию загрузки идут в /storage/videos/Torrents
#
# Что делает скрипт:
#  1. Если Entware нет — ставит его (installentware) и САМ перезагружает приставку;
#     после перезагрузки установка продолжается автоматически (журнал: /storage/qbittorrent-install.log).
#  2. Ставит qBittorrent, создаёт конфиг: веб-интерфейс на порту 9080, логин admin, пароль admin.
#  3. Запускает qBittorrent напрямую (без init-скрипта Entware), добавляет автозапуск.
# Скрипт можно запускать повторно — он безопасен (пересоздаёт настройки, не трогает загрузки).

DL="${1:-/storage/videos/Torrents}"
RESUME=0
[ "$1" = "--resume" ] && { RESUME=1; DL="${2:-/storage/videos/Torrents}"; }
PORT=9080
OPT="${OPT:-/opt}"
PROFILE="${PROFILE:-/storage/qbittorrent}"
AUTOSTART="${AUTOSTART:-/storage/.config/autostart.sh}"
SELF="${SELF:-/storage/setup-qbittorrent.sh}"
# CoreELEC подсовывает Entware-программам свою новую libc из /usr/lib ("GLIBC_2.35 not found").
# Для запуска qBittorrent явно указываем библиотеки Entware.
EL="$OPT/lib:$OPT/usr/lib"
CFGDIR="$PROFILE/qBittorrent/config"
CFG="$CFGDIR/qBittorrent.conf"

# снимаем отметку "продолжить после перезагрузки"
if [ -f "$AUTOSTART" ] && grep -q 'phoneremote-install-resume' "$AUTOSTART"; then
  grep -v 'phoneremote-install-resume' "$AUTOSTART" > "$AUTOSTART.tmp" && cat "$AUTOSTART.tmp" > "$AUTOSTART"; rm -f "$AUTOSTART.tmp"
fi

if [ ! -x "$OPT/bin/opkg" ]; then
  if [ "$RESUME" = 1 ]; then
    echo "Entware так и не установился. Запустите скрипт вручную:  sh $SELF"
    exit 1
  fi
  if ! command -v installentware >/dev/null 2>&1; then
    echo "Команда installentware не найдена — это не CoreELEC?"
    exit 1
  fi
  echo "== Устанавливаю Entware (нужен интернет)"
  installentware
  [ -z "$NORESUME" ] && [ "$0" != "$SELF" ] && [ -f "$0" ] && cp "$0" "$SELF"
  if [ -z "$NORESUME" ]; then
    [ -f "$AUTOSTART" ] || printf '#!/bin/sh\n' > "$AUTOSTART"
    echo "( sleep 45; sh \"$SELF\" --resume \"$DL\" > /storage/qbittorrent-install.log 2>&1 ) & # phoneremote-install-resume" >> "$AUTOSTART"
    chmod +x "$AUTOSTART"
  fi
  echo
  echo "Entware установлен. Нужна перезагрузка — после неё установка qBittorrent продолжится сама."
  echo "Через ~2 минуты после загрузки открывайте http://IP-приставки:$PORT  (admin / admin)."
  if [ -z "$NOREBOOT" ]; then
    echo "Перезагрузка через 10 секунд (Ctrl+C — отмена, тогда перезагрузите вручную: reboot)"
    sleep 10
    reboot
  fi
  [ -n "$NOREBOOT" ] && exit 10   # код 10 = «нужна перезагрузка» (для установщика в аддоне)
  exit 0
fi

mkdir -p "$DL" "$CFGDIR" || exit 1

BIN="$(ls "$OPT"/bin/qbittorrent-nox 2>/dev/null | head -n 1)"
if [ -z "$BIN" ]; then
  # сеть на приставке иногда обрывается — пробуем несколько раз
  n=0
  while [ $n -lt 6 ]; do
    n=$((n+1))
    echo "== opkg, попытка $n"
    "$OPT/bin/opkg" update
    "$OPT/bin/opkg" install qbittorrent && break
    sleep 10
  done
  BIN="$(ls "$OPT"/bin/qbittorrent-nox 2>/dev/null | head -n 1)"
fi
if [ -z "$BIN" ]; then
  echo "Не удалось установить qBittorrent через Entware (нет сети до bin.entware.net?)."
  exit 1
fi

echo "== Проверка бинарника: $BIN"
VER="$(LD_LIBRARY_PATH="$EL" "$BIN" --version 2>&1)"
echo "$VER"
case "$VER" in
  *[Qq][Bb]ittorrent*v*) ;;
  *)
    echo
    echo "qBittorrent из Entware не запускается на этой системе (текст ошибки выше)."
    echo "Пришлите этот текст ошибки — подберём другой способ."
    exit 1 ;;
esac

# --- останавливаем qBittorrent (он перезаписывает конфиг при выходе), затем правим конфиг
killall qbittorrent-nox 2>/dev/null
sleep 4
# --- конфиг (создаём или правим)
[ -f "$CFG" ] || printf '[LegalNotice]\nAccepted=true\n\n[Preferences]\n' > "$CFG"
cp "$CFG" "$CFG.bak" 2>/dev/null
for k in 'WebUI\Username' 'WebUI\Password_PBKDF2' 'WebUI\Port' 'WebUI\LocalHostAuth' 'WebUI\Address' 'WebUI\HostHeaderValidation' \
         'WebUI\CSRFProtection' 'Downloads\SavePath'; do
  K="$k=" awk 'index($0, ENVIRON["K"]) != 1' "$CFG" > "$CFG.tmp" && mv "$CFG.tmp" "$CFG"
done
# логин admin / пароль admin
PBKDF='"@ByteArray(XzqcHnstSAahw+X3CStNbg==:MX8SzdMqn+UPBq0vK/v0epAYKjltZAfKLUYQKuPAoXphGzmUOgXW1yknry2O0GAeYiYGgKTwRNoZ51WqLWs8TQ==)"'
NEW="$(printf '%s\n' \
  'WebUI\Username=admin' \
  "WebUI\\Password_PBKDF2=$PBKDF" \
  "WebUI\\Port=$PORT" \
  'WebUI\LocalHostAuth=false' \
  'WebUI\Address=*' \
  'WebUI\HostHeaderValidation=false' \
  'WebUI\CSRFProtection=false' \
  "Downloads\\SavePath=$DL")"
if grep -q '^\[Preferences\]' "$CFG"; then
  NEW="$NEW" awk '{print} /^\[Preferences\]/{print ENVIRON["NEW"]}' "$CFG" > "$CFG.tmp" && mv "$CFG.tmp" "$CFG"
else
  { echo; echo '[Preferences]'; echo "$NEW"; } >> "$CFG"
fi
grep -q '^\[LegalNotice\]' "$CFG" || printf '\n[LegalNotice]\nAccepted=true\n' >> "$CFG"

# --- запуск
LD_LIBRARY_PATH="$EL" "$BIN" --daemon --profile="$PROFILE" --webui-port=$PORT > "$PROFILE/start.log" 2>&1

# --- автозапуск при загрузке
if ! grep -q 'phoneremote-qbittorrent' "$AUTOSTART" 2>/dev/null; then
  [ -f "$AUTOSTART" ] || printf '#!/bin/sh\n' > "$AUTOSTART"
  cat >> "$AUTOSTART" <<EOT

# phoneremote-qbittorrent
( i=0; while [ ! -x /opt/bin/qbittorrent-nox ] && [ \$i -lt 60 ]; do sleep 2; i=\$((i+1)); done
  LD_LIBRARY_PATH=/opt/lib:/opt/usr/lib /opt/bin/qbittorrent-nox --daemon --profile=$PROFILE --webui-port=$PORT ) &
EOT
  chmod +x "$AUTOSTART"
fi

# --- проверка
fetch() { if command -v curl >/dev/null 2>&1; then curl -s -m 3 "$1"; else wget -qO- -T 3 "$1"; fi; }
i=0; V=""
while [ $i -lt 20 ]; do
  V="$(fetch "http://127.0.0.1:$PORT/api/v2/app/version" 2>/dev/null)"
  [ -n "$V" ] && break
  i=$((i+1)); sleep 1
done
if [ -n "$V" ]; then
  echo "qBittorrent работает, версия: $V"
  echo "Веб-интерфейс: http://IP-приставки:$PORT  | загрузки: $DL"
  echo "Логин: admin  пароль: admin  (в Phone Remote они подставляются сами)."
else
  echo "qBittorrent не отвечает на порту $PORT. Журнал запуска:"
  tail -n 20 "$PROFILE/start.log"
  echo "Пришлите этот текст — разберёмся."
  exit 1
fi
