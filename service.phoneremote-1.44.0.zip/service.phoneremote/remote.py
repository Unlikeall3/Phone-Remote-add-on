"""Доступ к Phone Remote из интернета: автоматический проброс порта на роутере по UPnP (IGD) и определение внешнего адреса.

Только стандартная библиотека. Состояние читается из service.py через remote.STATE.
"""
import re
import socket
import threading
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

STATE = {"state": "off", "msg": "", "ext_ip": "", "ext_port": 0, "upnp": False, "ts": 0}
_lock = threading.Lock()
_igd = {"ctl": None, "svc": None}

SSDP_ST = ("urn:schemas-upnp-org:device:InternetGatewayDevice:1", "urn:schemas-upnp-org:device:InternetGatewayDevice:2",
           "upnp:rootdevice")
SVC = ("urn:schemas-upnp-org:service:WANIPConnection:2", "urn:schemas-upnp-org:service:WANIPConnection:1",
       "urn:schemas-upnp-org:service:WANPPPConnection:1")


def is_public_ip(ip):
    m = re.match(r"^(\d+)\.(\d+)\.(\d+)\.(\d+)$", ip or "")
    if not m:
        return False
    a, b = int(m.group(1)), int(m.group(2))
    if a in (0, 10, 127) or a >= 224 or (a == 169 and b == 254) or (a == 172 and 16 <= b <= 31) or \
            (a == 192 and b == 168) or (a == 100 and 64 <= b <= 127):
        return False
    return True


def _discover(lan_ip, timeout=3.0):
    seen = set()
    sk = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sk.settimeout(0.7)
    try:
        if lan_ip:
            sk.bind((lan_ip, 0))
        for st in SSDP_ST:
            msg = ("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: %s\r\n\r\n" % st)
            try:
                sk.sendto(msg.encode(), ("239.255.255.250", 1900))
            except OSError:
                pass
        end = time.time() + timeout
        while time.time() < end:
            try:
                data, _ = sk.recvfrom(4096)
            except socket.timeout:
                continue
            except OSError:
                break
            m = re.search(r"(?im)^location:\s*(\S+)", data.decode("utf-8", "ignore"))
            if m and m.group(1) not in seen:
                seen.add(m.group(1))
                yield m.group(1)
    finally:
        sk.close()


def _find_service(location):
    with urllib.request.urlopen(location, timeout=4) as r:
        xml = r.read()
    root = ET.fromstring(xml)
    ns = re.match(r"\{.*\}", root.tag)
    ns = ns.group(0) if ns else ""
    for s in root.iter(ns + "service"):
        st = (s.findtext(ns + "serviceType") or "").strip()
        ctl = (s.findtext(ns + "controlURL") or "").strip()
        if st in SVC and ctl:
            return st, urllib.parse.urljoin(location, ctl)
    return None


def _soap(ctl, svc, action, args):
    body = ('<?xml version="1.0"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" '
            's:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:%s xmlns:u="%s">%s</u:%s></s:Body></s:Envelope>'
            % (action, svc, "".join("<%s>%s</%s>" % (k, v, k) for k, v in args), action))
    req = urllib.request.Request(ctl, body.encode(), {"Content-Type": 'text/xml; charset="utf-8"',
                                                      "SOAPAction": '"%s#%s"' % (svc, action)})
    with urllib.request.urlopen(req, timeout=5) as r:
        return r.read().decode("utf-8", "ignore")


def _gateway(lan_ip):
    if _igd["ctl"]:
        return _igd["svc"], _igd["ctl"]
    for loc in _discover(lan_ip):
        try:
            f = _find_service(loc)
        except Exception:  # noqa
            f = None
        if f:
            _igd["svc"], _igd["ctl"] = f
            return f
    return None


def _external_ip_web():
    for u in ("https://api.ipify.org", "https://ifconfig.me/ip", "https://icanhazip.com"):
        try:
            with urllib.request.urlopen(u, timeout=5) as r:
                ip = r.read().decode().strip()
            if re.match(r"^\d+\.\d+\.\d+\.\d+$", ip):
                return ip
        except Exception:  # noqa
            continue
    return ""


def apply(enabled, pin_ok, lan_ip, int_port, ext_port, log=lambda m: None):
    """Один проход: включить/выключить проброс и обновить STATE."""
    with _lock:
        S = STATE
        S["ts"] = time.time()
        S["ext_port"] = ext_port
        if not enabled:
            if _igd["ctl"]:
                try:
                    _soap(_igd["ctl"], _igd["svc"], "DeletePortMapping", [("NewRemoteHost", ""), ("NewExternalPort", ext_port),
                                                                           ("NewProtocol", "TCP")])
                    log("remote: проброс порта %s снят" % ext_port)
                except Exception:  # noqa
                    pass
                _igd["ctl"] = None
            S.update(state="off", msg="", ext_ip="", upnp=False)
            return
        if not pin_ok:
            S.update(state="no_pin", msg="Задайте PIN-код (не короче 6 символов) в настройках add-on'а — без него доступ из интернета не включается.",
                     ext_ip="", upnp=False)
            return
        if not lan_ip:
            S.update(state="error", msg="Нет локального IP-адреса приставки.", upnp=False)
            return
        gw = None
        try:
            gw = _gateway(lan_ip)
        except Exception as e:  # noqa
            log("remote: поиск роутера: %r" % e)
        ext_ip = ""
        if gw:
            svc, ctl = gw
            try:
                try:
                    _soap(ctl, svc, "AddPortMapping", [("NewRemoteHost", ""), ("NewExternalPort", ext_port), ("NewProtocol", "TCP"),
                                                       ("NewInternalPort", int_port), ("NewInternalClient", lan_ip), ("NewEnabled", 1),
                                                       ("NewPortMappingDescription", "Phone Remote"), ("NewLeaseDuration", 0)])
                except Exception:  # часть роутеров не принимает «навсегда» — просим на час (обновляем каждые 10 минут)
                    _soap(ctl, svc, "AddPortMapping", [("NewRemoteHost", ""), ("NewExternalPort", ext_port), ("NewProtocol", "TCP"),
                                                       ("NewInternalPort", int_port), ("NewInternalClient", lan_ip), ("NewEnabled", 1),
                                                       ("NewPortMappingDescription", "Phone Remote"), ("NewLeaseDuration", 3600)])
                S["upnp"] = True
                try:
                    m = re.search(r"<NewExternalIPAddress>([^<]*)<", _soap(ctl, svc, "GetExternalIPAddress", []))
                    ext_ip = m.group(1).strip() if m else ""
                except Exception:  # noqa
                    ext_ip = ""
            except Exception as e:  # noqa
                log("remote: AddPortMapping: %r" % e)
                _igd["ctl"] = None
                S["upnp"] = False
                gw = None
        web_ip = _external_ip_web()
        ip = ext_ip if is_public_ip(ext_ip) else web_ip
        S["ext_ip"] = ip or ext_ip
        if gw and ext_ip and not is_public_ip(ext_ip):
            S.update(state="cgnat", msg="Провайдер выдаёт «серый» адрес (%s, CGNAT): прямое подключение из интернета невозможно. "
                                         "Попросите у провайдера белый IP или используйте VPN (WireGuard, Tailscale)." % ext_ip)
        elif gw:
            S.update(state="ok", msg="Порт %s открыт на роутере автоматически (UPnP)." % ext_port)
        else:
            S.update(state="manual", msg="Роутер не ответил по UPnP (или он выключен). Откройте порт вручную: в роутере "
                                         "перенаправьте TCP-порт %s на %s:%s." % (ext_port, lan_ip, int_port))
