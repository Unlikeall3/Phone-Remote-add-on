import base64
import collections
import errno
import json
import mimetypes
import os
import posixpath
import re
import codecs
try:
    import fcntl
except ImportError:  # Windows
    fcntl = None
try:
    import pty
except ImportError:
    pty = None
import select
import signal
try:
    import termios
except ImportError:
    termios = None
import ftplib
import glob
import hashlib
import shutil
import socket
import struct
import subprocess
import threading
import time
import uuid
import zipfile
import zlib
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import qbctl
import remote
import hmac
import ipaddress
import instjob

ADDON_ID = "service.phoneremote"
VIDEO_EXT = {".mkv", ".mp4", ".avi", ".mov", ".m4v", ".ts", ".m2ts", ".mts", ".wmv",
             ".webm", ".iso", ".mpg", ".mpeg", ".flv", ".bdmv", ".strm"}
MUSIC_EXT = {".mp3", ".flac", ".wav", ".m4a", ".aac", ".ogg", ".opus", ".wma", ".ape", ".alac",
             ".aiff", ".aif", ".dsf", ".dff", ".mka", ".wv", ".m3u", ".m3u8"}
PHOTO_EXT = {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".tif", ".tiff", ".heic"}


def shown_exts():
    s = cfg()
    out = set()
    for key, exts in (("show_video", VIDEO_EXT), ("show_music", MUSIC_EXT), ("show_photo", PHOTO_EXT)):
        if (s.getSetting(key) or "true").lower() != "false":
            out |= exts
    return out


def kind_of(name, show_all=False):
    e = os.path.splitext(name)[1].lower()
    if show_all and e not in MUSIC_EXT and e not in PHOTO_EXT and e not in VIDEO_EXT:
        return "other"
    return "music" if e in MUSIC_EXT else "photo" if e in PHOTO_EXT else "video"


EVENTS = collections.deque(maxlen=300)  # журнал событий для вкладки «Статус»


_SRC = (("cec", re.compile(r"cec|aocec|громкост", re.I)), ("ftp", re.compile(r"ftp|vfs_list|stream|smb|nfs", re.I)),
        ("torrent", re.compile(r"torrent|qbit|watch|transmission|торрент", re.I)),
        ("wake", re.compile(r"wol|wake|tv_|tv wol|питани|sleep|power", re.I)),
        ("catalog", re.compile(r"catalog|lib_meta|каталог", re.I)))
_ERR = re.compile(r"fail|error|ошиб|cannot|refused|недоступ|не удал|не запуст|не найден|timed out|traceback", re.I)


def ev_add(msg, lvl=None, src=None):
    msg = str(msg)[:400]
    src = src or next((n for n, rx in _SRC if rx.search(msg)), "system")
    EVENTS.append({"ts": time.time(), "lvl": lvl or ("err" if _ERR.search(msg) else "info"), "src": src, "msg": msg})


def log(msg, ev=True):
    xbmc.log("[%s] %s" % (ADDON_ID, msg), xbmc.LOGINFO)
    if ev:
        ev_add(msg)


def cfg():
    return xbmcaddon.Addon(ADDON_ID)


def rpc(method, params=None):
    req = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        req["params"] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    except Exception as e:  # noqa
        log("rpc error %s: %s" % (method, e))
        return {}


def rpc_batch(calls):
    """Несколько JSON-RPC вызовов за один раз (массив запросов) — на порядок быстрее, чем по одному."""
    reqs = []
    for n, (method, params) in enumerate(calls):
        r = {"jsonrpc": "2.0", "id": n + 1, "method": method}
        if params is not None:
            r["params"] = params
        reqs.append(r)
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(reqs)))
    except Exception as e:  # noqa
        log("rpc batch error: %s" % e)
        return []


def to_sec(t):
    if not t:
        return 0
    return t.get("hours", 0) * 3600 + t.get("minutes", 0) * 60 + t.get("seconds", 0)


def from_sec(s):
    s = max(0, int(s))
    return {"hours": s // 3600, "minutes": (s % 3600) // 60, "seconds": s % 60, "milliseconds": 0}


# ---------- files ----------
MAX_ROOTS = 5


AUTO_ROOTS = ("/storage", "/media")  # внутренняя память и подключённые диски CoreELEC


def user_roots():
    """Папки, заданные в настройках (по ним строится каталог)."""
    s = cfg()
    out = []
    for i in range(1, MAX_ROOTS + 1):
        v = (s.getSetting("root%d" % i) or "").strip()
        if v:
            out.append(v)
    return out or ["/storage/videos"]


def roots():
    """Папки из настроек + (если включено) /storage и /media + источники, добавленные на странице (FTP, SMB…).
    Порядок важен: номера в сохранённых плейлистах — это индексы, поэтому новое добавляем только в конец."""
    out = user_roots()
    if (cfg().getSetting("auto_roots") or "true").lower() != "false":
        have = {os.path.realpath(r) for r in out if not is_url(r)}
        for r in AUTO_ROOTS:
            if os.path.isdir(r) and os.path.realpath(r) not in have:
                out.append(r)
    for sc in sources_load():
        try:
            out.append(source_url(sc))
        except Exception:  # noqa
            pass
    return out


def is_url(v):
    return "://" in v


def root_name(v):
    if is_url(v):
        u = urllib.parse.urlparse(v)  # credentials are never shown
        tail = [p for p in u.path.split("/") if p]
        return urllib.parse.unquote("%s/%s" % (u.hostname or u.scheme, tail[-1]) if tail else (u.hostname or v))
    return os.path.basename(v.rstrip("/")) or v


def split_id(pid):
    if ":" not in pid:
        raise ValueError("bad path")
    i, rel = pid.split(":", 1)
    rs = roots()
    i = int(i)
    if i < 0 or i >= len(rs):
        raise ValueError("bad path")
    parts = [p for p in rel.split("/") if p]
    for p in parts:
        d = urllib.parse.unquote(p)
        if d in (".", "..") or "/" in d or "\\" in d:
            raise ValueError("path outside root")
    return i, rs[i], "/".join(parts)


def child_id(i, rel, name, quote=False):
    if quote:
        name = urllib.parse.quote(name, safe="")
    return "%d:%s" % (i, (rel + "/" if rel else "") + name)


def local_abs(root, rel):
    base = os.path.realpath(root)
    p = os.path.realpath(os.path.join(base, rel))
    if p != base and not p.startswith(base + os.sep):
        raise ValueError("path outside root")
    return base, p


def url_abs(root, rel):
    return root.rstrip("/") + "/" + rel if rel else root.rstrip("/") + "/"


def mask_url(u):
    return re.sub(r"://[^/@]*@", "://***@", u)


_ftp_lock = threading.Lock()
_UNIX_LS = re.compile(r"^([\-dlbcps])\S*\s+\d+\s+\S+\s+\S+\s+(\d+)\s+\S+\s+\S+\s+\S+\s+(.+)$")
_DOS_LS = re.compile(r"^\d\d-\d\d-\d+\s+\d\d:\d\d\s*[AP]?M?\s+(<DIR>|\d+)\s+(.+)$")


def ftp_connect(u, enc="utf-8", timeout=10):
    ftp = ftplib.FTP()
    ftp.encoding = enc
    ftp.connect(u.hostname, u.port or 21, timeout=timeout)
    ftp.login(urllib.parse.unquote(u.username) if u.username else "anonymous",
              urllib.parse.unquote(u.password or "") if u.username else "anonymous@")
    ftp.set_pasv(True)
    return ftp


def ftp_connect_retry(u, tries=6):
    """После закрытия предыдущего соединения FTP-серверу с лимитом подключений нужно мгновение."""
    for n in range(tries):
        try:
            return ftp_connect(u)
        except ftplib.error_temp:
            if n == tries - 1:
                raise
            time.sleep(0.5)


def _list_on(ftp, path):
    out = []
    try:
        for name, facts in ftp.mlsd(path, facts=["type", "size"]):
            t = facts.get("type", "")
            if t in ("cdir", "pdir") or name in (".", ".."):
                continue
            out.append((name, t == "dir", int(facts.get("size") or 0)))
        return out
    except ftplib.error_perm:
        pass  # сервер без MLSD
    out = []
    lines = []
    ftp.cwd(path)
    ftp.retrlines("LIST", lines.append)
    for ln in lines:
        m = _UNIX_LS.match(ln)
        if m:
            name = m.group(3).split(" -> ")[0]
            out.append((name, m.group(1) in "dl", int(m.group(2))))
            continue
        m = _DOS_LS.match(ln)
        if m:
            out.append((m.group(2), m.group(1) == "<DIR>", 0 if m.group(1) == "<DIR>" else int(m.group(1))))
    return [e for e in out if e[0] not in (".", "..")]


def _ftp_entries(u, path, enc):
    ftp = ftp_connect(u, enc)
    try:
        return _list_on(ftp, path)
    finally:
        try:
            ftp.quit()
        except Exception:  # noqa
            ftp.close()


def ftp_path(root, rel):
    u = urllib.parse.urlparse(root)
    return posixpath.join(urllib.parse.unquote(u.path) or "/",
                          *[urllib.parse.unquote(p) for p in rel.split("/") if p])


def ftp_list(root, rel):
    """FTP читаем сами (ftplib): одно короткое соединение на запрос, с таймаутом.
    Через Kodi VFS соединение остаётся открытым и FTP-серверы на телефонах/NAS
    с лимитом подключений на второй папке зависают."""
    u = urllib.parse.urlparse(root)
    path = ftp_path(root, rel)
    last = None
    with _ftp_lock:
        for enc in ("utf-8", "latin-1"):
            try:
                return _ftp_entries(u, path, enc)
            except UnicodeDecodeError as e:
                last = e
            except ftplib.all_errors as e:
                log("ftp_list failed for %s: %s" % (mask_url(root), e))
                raise RuntimeError("FTP: не удалось открыть %s (%s)" % (mask_url(root) + "/" + rel, e))
    raise RuntimeError("FTP: не удалось прочитать имена файлов (%s)" % last)


def vfs_list(base, hidden=False):
    """Остальные протоколы (smb/nfs/http...) — через VFS Kodi.
    Files.GetDirectory в JSON-RPC отказывает для адресов, не добавленных в sources.xml."""
    err = None
    try:
        dirs, files = xbmcvfs.listdir(base)
        dirs = [d for d in dirs if d and (hidden or not d.startswith("."))]
        files = [f for f in files if f and (hidden or not f.startswith("."))]
        if dirs or files or xbmcvfs.exists(base):
            return [(d, True, 0) for d in dirs] + [(f, False, 0) for f in files]
    except Exception as e:  # noqa
        err = e
    r = rpc("Files.GetDirectory", {"directory": base, "media": "files"})
    if "error" not in r and r.get("result") is not None:
        out = []
        for f in r["result"].get("files", []) or []:
            fp = f.get("file", "")
            name = urllib.parse.unquote((fp[len(base):] if fp.startswith(base) else f.get("label", "")).strip("/").split("/")[0])
            if name:
                out.append((name, f.get("filetype") == "directory", int(f.get("size") or 0)))
        return out
    log("vfs_list failed for %s: %s" % (mask_url(base), err or r.get("error")))
    raise RuntimeError("Не удалось открыть %s — проверьте адрес, логин и пароль в настройках add-on" % mask_url(base))


def list_dir(pid, show_all=False, hidden=False):
    rs = roots()
    if pid == "":  # корень: список источников (всегда, чтобы можно было добавить новый)
        return {"path": "", "crumb": "/", "parent": None, "ops": file_ops_on(), "items": [
            {"name": root_label(r), "dir": True, "size": 0, "path": "%d:" % i, "src": is_url(r), "sid": root_sid(r)} for i, r in enumerate(rs)], "sources": True}
    if pid == "":
        pid = "0:"
    i, root, rel = split_id(pid)
    if rel:
        up = "/".join(rel.split("/")[:-1])
        parent = "%d:%s" % (i, up)
    else:
        parent = None if len(rs) == 1 else ""
    crumb = "/" + root_label(root) + ("/" + urllib.parse.unquote(rel) if rel else "")
    items = []
    exts = shown_exts()
    if is_url(root):
        base = url_abs(root, rel)
        base = base if base.endswith("/") else base + "/"
        if urllib.parse.urlparse(root).scheme.lower() == "ftp":
            entries = ftp_list(root, rel)
        else:
            entries = vfs_list(base, hidden)
        for name, is_dir, size in entries:
            if (hidden or not name.startswith(".")) and (is_dir or show_all or os.path.splitext(name)[1].lower() in exts):
                items.append({"name": name, "dir": is_dir, "size": 0 if is_dir else size,
                              "kind": kind_of(name, show_all), "path": child_id(i, rel, name, True)})
    else:
        _, p = local_abs(root, rel)
        with os.scandir(p) as it:
            for e in it:
                if e.name.startswith(".") and not hidden:
                    continue
                try:
                    is_dir = e.is_dir()
                    if not is_dir and not show_all and os.path.splitext(e.name)[1].lower() not in exts:
                        continue
                    size = 0 if is_dir else e.stat().st_size
                except OSError:
                    continue
                items.append({"name": e.name, "dir": is_dir, "size": size, "kind": kind_of(e.name, show_all),
                              "path": child_id(i, rel, e.name)})
    items.sort(key=lambda x: (not x["dir"], x["name"].lower()))
    return {"path": pid, "crumb": crumb, "parent": parent, "ops": file_ops_on(), "items": items}


# ---------- файловые операции: переименовать / переместить / удалить ----------
def file_ops_on():
    return (cfg().getSetting("file_ops") or "true").lower() != "false"


def _file_ops_check():
    if not file_ops_on():
        raise ValueError("Файловые операции выключены в настройках Phone Remote")


def _clean_name(n):
    n = (n or "").strip()
    if not n or n in (".", "..") or any(c in n for c in "/\\\0") or len(n.encode("utf-8")) > 255:
        raise ValueError("Недопустимое имя")
    return n


def _split_rel(rel):
    parts = [p for p in rel.split("/") if p]
    return "/".join(parts[:-1]), (parts[-1] if parts else "")


def _real_name(root, raw):
    return urllib.parse.unquote(raw) if is_url(root) else raw


def _local_path(root, rel):
    """Путь внутри корня без разыменования последнего звена (чтобы можно было удалить/переименовать саму ссылку)."""
    base = os.path.realpath(root)
    p = os.path.join(base, *[x for x in rel.split("/") if x])
    par = os.path.realpath(os.path.dirname(p))
    if par != base and not par.startswith(base + os.sep):
        raise ValueError("path outside root")
    return base, p


def _stat_entry(i, root, rel):
    """None, если нет такой записи; иначе (папка?, размер)."""
    parent, raw = _split_rel(rel)
    if not is_url(root):
        _, p = _local_path(root, rel)
        if not os.path.lexists(p):
            return None
        return (os.path.isdir(p) and not os.path.islink(p), 0)
    name = _real_name(root, raw)
    for n, d, sz in _raw_list(i, root, parent):
        if n == name:
            return (d, sz)
    return None


def _is_ftp(root):
    return is_url(root) and urllib.parse.urlparse(root).scheme.lower() == "ftp"


def _ftp_remove(ftp, path, is_dir, depth=0):
    if not is_dir:
        ftp.delete(path)
        return
    if depth > 12:
        raise RuntimeError("FTP: слишком глубокая вложенность")
    for name, d, _ in _list_on(ftp, path):
        _ftp_remove(ftp, posixpath.join(path, name), d, depth + 1)
    ftp.cwd("/")
    ftp.rmd(path)


def _bg_move(a, b):
    try:
        shutil.move(a, b)
        log("file move done: %s -> %s" % (a, b))
        xbmcgui.Dialog().notification("Phone Remote", "Перемещено: " + os.path.basename(b), xbmcgui.NOTIFICATION_INFO, 5000)
    except Exception as e:  # noqa
        log("file move failed: %s -> %s: %r" % (a, b, e))
        xbmcgui.Dialog().notification("Phone Remote", "Не удалось переместить: %s" % e, xbmcgui.NOTIFICATION_ERROR, 8000)


def _do_move(i1, root1, rel1, i2, root2, rel2):
    """Переименование/перенос одной записью. Возвращает True, если копирование между дисками ушло в фон."""
    if not is_url(root1) and not is_url(root2):
        _, a = _local_path(root1, rel1)
        _, b = _local_path(root2, rel2)
        if os.path.lexists(b):
            raise ValueError("Такое имя уже есть")
        ra = os.path.realpath(a)
        if os.path.isdir(a) and (os.path.realpath(os.path.dirname(b)) + os.sep).startswith(ra + os.sep):
            raise ValueError("Нельзя переместить папку саму в себя")
        try:
            os.rename(a, b)
        except OSError as e:
            if e.errno != errno.EXDEV:
                raise ValueError("Не удалось: %s" % (e.strerror or e))
            threading.Thread(target=_bg_move, args=(a, b), daemon=True).start()
            return True
        return False
    if is_url(root1) and root1 == root2:
        if _is_ftp(root1):
            u = urllib.parse.urlparse(root1)
            with _ftp_lock:
                ftp = ftp_connect_retry(u)
                try:
                    ftp.rename(ftp_path(root1, rel1), ftp_path(root2, rel2))
                except ftplib.all_errors as e:
                    raise RuntimeError("FTP: %s" % e)
                finally:
                    try:
                        ftp.quit()
                    except Exception:  # noqa
                        ftp.close()
            return False
        if not xbmcvfs.rename(url_abs(root1, rel1).rstrip("/"), url_abs(root2, rel2).rstrip("/")):
            raise RuntimeError("Не удалось: проверьте права на запись в сетевой папке")
        return False
    raise ValueError("Перемещение между разными источниками не поддерживается")


def _after_change(old, new=None):
    """История просмотра и каталог поиска после переименования/переноса (new) или удаления (new=None)."""
    def remap(key):
        if key == old:
            return new
        if key.startswith(old + "/"):
            return new + key[len(old):]
        return None
    with _hist_lock:
        out = []
        for e in hist_load():
            k = e.get("key", "")
            if k == old or k.startswith(old + "/"):
                if not new:
                    continue
                e["key"] = remap(k)
                if e.get("id"):
                    e["id"] = e["key"]
                if k == old:  # переименование/перенос самого файла: имя в списке — новое
                    try:
                        idx, rel = e["key"].split(":", 1)
                        e["name"] = _real_name(roots()[int(idx)], _split_rel(rel)[1])
                    except Exception:  # noqa
                        pass
            out.append(e)
        hist_save(out)
    rs = roots()
    changed, items = False, []
    for it in CAT["items"]:
        pth = it.get("p", "")
        if pth == old or pth.startswith(old + "/"):
            changed = True
            if not new:
                continue
            exact = pth == old
            it["p"] = remap(pth)
            try:
                idx, rel = it["p"].split(":", 1)
                root = rs[int(idx)]
                parent, raw = _split_rel(rel)
                it["n"] = _real_name(root, raw)
                it["d"] = root_name(root) + ("/" + urllib.parse.unquote(parent) if parent else "")
                it["_h"] = norm(it["n"] + " " + it["d"])
            except Exception:  # noqa
                pass
            for k in ("a", "o"):
                if k in it:
                    nv = None if exact else remap(it[k])
                    if nv:
                        it[k] = nv
                    else:
                        it.pop(k, None)
        items.append(it)
    if changed:
        CAT["items"] = items
        CAT["count"] = len(items)
        cat_save()


def fop_rename(body):
    _file_ops_check()
    pid = str(body.get("path", ""))
    new = _clean_name(body.get("name"))
    i, root, rel = split_id(pid)
    if not rel:
        raise ValueError("Корневую папку переименовать нельзя")
    parent, raw = _split_rel(rel)
    if new == _real_name(root, raw):
        raise ValueError("Имя не изменилось")
    st = _stat_entry(i, root, rel)
    if not st:
        raise ValueError("Файл не найден (возможно, его уже переместили)")
    new_raw = urllib.parse.quote(new, safe="") if is_url(root) else new
    new_rel = (parent + "/" if parent else "") + new_raw
    if _stat_entry(i, root, new_rel):
        raise ValueError("Такое имя уже есть")
    _do_move(i, root, rel, i, root, new_rel)
    new_pid = "%d:%s" % (i, new_rel)
    _after_change(pid, new_pid)
    log("file renamed: %s -> %s" % (pid, new), ev=False)
    return {"ok": True, "path": new_pid}


def fop_mkdir(body):
    _file_ops_check()
    pid = str(body.get("dir", ""))
    name = _clean_name(body.get("name"))
    if ":" not in pid:
        raise ValueError("Откройте папку, в которой нужно создать новую")
    i, root, rel = split_id(pid)
    raw = urllib.parse.quote(name, safe="") if is_url(root) else name
    new_rel = (rel + "/" if rel else "") + raw
    if _stat_entry(i, root, new_rel):
        raise ValueError("Такое имя уже есть")
    if not is_url(root):
        _, p = _local_path(root, new_rel)
        try:
            os.mkdir(p)
        except OSError as e:
            raise ValueError("Не удалось создать папку: %s" % (e.strerror or e))
    elif _is_ftp(root):
        u = urllib.parse.urlparse(root)
        with _ftp_lock:
            ftp = ftp_connect_retry(u)
            try:
                ftp.mkd(ftp_path(root, new_rel))
            except ftplib.all_errors as e:
                raise RuntimeError("FTP: %s" % e)
            finally:
                try:
                    ftp.quit()
                except Exception:  # noqa
                    pass
    else:
        if not xbmcvfs.mkdir(url_abs(root, new_rel) + "/"):
            raise RuntimeError("Не удалось создать папку на этом источнике")
    log("папка создана: %s" % ("%d:%s" % (i, new_rel)), ev=False)
    return {"ok": True, "path": "%d:%s" % (i, new_rel)}


def fop_move(body):
    _file_ops_check()
    pid, dest = str(body.get("path", "")), str(body.get("dest", ""))
    i1, root1, rel1 = split_id(pid)
    if not rel1:
        raise ValueError("Корневую папку переместить нельзя")
    if ":" not in dest:
        raise ValueError("Выберите папку назначения")
    i2, root2, drel = split_id(dest)
    st = _stat_entry(i1, root1, rel1)
    if not st:
        raise ValueError("Файл не найден (возможно, его уже переместили)")
    if drel:
        dst = _stat_entry(i2, root2, drel)
        if not dst or not dst[0]:
            raise ValueError("Папка назначения не найдена")
    parent1, raw = _split_rel(rel1)
    if i1 == i2 and parent1 == drel:
        raise ValueError("Файл уже в этой папке")
    if i1 == i2 and st[0] and (drel == rel1 or drel.startswith(rel1 + "/")):
        raise ValueError("Нельзя переместить папку саму в себя")
    new_rel = (drel + "/" if drel else "") + raw
    if _stat_entry(i2, root2, new_rel):
        raise ValueError("В папке назначения уже есть «%s»" % _real_name(root1, raw))
    bg = _do_move(i1, root1, rel1, i2, root2, new_rel)
    new_pid = "%d:%s" % (i2, new_rel)
    _after_change(pid, new_pid)
    log("file moved: %s -> %s" % (pid, new_pid), ev=False)
    return {"ok": True, "path": new_pid, "bg": bg}


# ---------- копирование файлов и папок на приставке (в фоне, с прогрессом) ----------
COPY_JOBS = collections.OrderedDict()


def _copy_name(dirp, name):
    p = os.path.join(dirp, name)
    if not os.path.lexists(p):
        return p
    stem, ext = os.path.splitext(name) if not os.path.isdir(os.path.join(dirp, name)) else (name, "")
    n = 1
    while True:
        p = os.path.join(dirp, "%s — копия%s%s" % (stem, "" if n == 1 else " %d" % n, ext))
        if not os.path.lexists(p):
            return p
        n += 1


def _copy_worker(job, src, dst):
    try:
        total = 0
        if os.path.isdir(src):
            for r_, _d, fs in os.walk(src):
                for f in fs:
                    try:
                        total += os.path.getsize(os.path.join(r_, f))
                    except OSError:
                        pass
        else:
            total = os.path.getsize(src)
        job["total"] = total

        def cp(a, b):
            with open(a, "rb") as fi, open(b, "wb") as fo:
                while True:
                    ch = fi.read(4 << 20)
                    if not ch:
                        break
                    fo.write(ch)
                    job["done"] += len(ch)
                    if job.get("cancel"):
                        raise RuntimeError("отменено")
            try:
                shutil.copystat(a, b)
            except OSError:
                pass
        if os.path.isdir(src):
            for r_, ds, fs in os.walk(src):
                rel = os.path.relpath(r_, src)
                d0 = dst if rel == "." else os.path.join(dst, rel)
                os.makedirs(d0, exist_ok=True)
                for f in fs:
                    cp(os.path.join(r_, f), os.path.join(d0, f))
        else:
            cp(src, dst)
        job["state"] = "done"
        log("скопировано: %s -> %s" % (src, dst))
    except Exception as e:  # noqa
        job["state"] = "error"
        job["error"] = (e.strerror if isinstance(e, OSError) and e.strerror else str(e)) or "ошибка"
        log("копирование не удалось: %s (%s)" % (src, job["error"]))
        try:
            shutil.rmtree(dst) if os.path.isdir(dst) else os.remove(dst)
        except OSError:
            pass


def _dir_parts(pid, limit=20000):
    """Все файлы папки (рекурсивно) как части ZIP: (путь внутри архива, размер, генератор). Читаются по очереди."""
    i, root, rel = split_id(pid)
    if not rel:
        raise ValueError("Корневую папку скачать целиком нельзя — откройте нужную папку внутри")
    if not (_stat_entry(i, root, rel) or (False, 0))[0]:
        raise ValueError("это не папка")
    top = urllib.parse.unquote(rel.split("/")[-1]) if is_url(root) else rel.split("/")[-1]
    parts, stack = [], [(rel, top)]
    while stack:
        r, prefix = stack.pop()
        for name, is_dir, size in sorted(_raw_list(i, root, r), key=lambda x: x[0].lower()):
            if is_dir:
                stack.append((child_id(i, r, name, is_url(root)).split(":", 1)[1], prefix + "/" + name))
            else:
                if len(parts) >= limit:
                    raise ValueError("В папке больше %d файлов — скачайте её частями" % limit)
                cid = child_id(i, r, name, is_url(root))
                parts.append((prefix + "/" + name, size,
                              (lambda c: (lambda: _open_chunks(c)[2]()))(cid)))
    if not parts:
        raise ValueError("Папка пуста")
    return top, parts


def fop_copy(body):
    _file_ops_check()
    pid, dest = str(body.get("path", "")), str(body.get("dest", ""))
    i1, root1, rel1 = split_id(pid)
    if not rel1:
        raise ValueError("Корневую папку копировать нельзя")
    if ":" not in dest:
        raise ValueError("Выберите папку назначения")
    i2, root2, drel = split_id(dest)
    if is_url(root1) or is_url(root2):
        raise ValueError("Копирование работает между папками на самой приставке (память, USB, карта); для сетевых источников используйте «Скачать»")
    if not _stat_entry(i1, root1, rel1):
        raise ValueError("Файл не найден")
    _, src = _local_path(root1, rel1)
    _, dd = _local_path(root2, drel) if drel else (None, os.path.realpath(root2))
    if not os.path.isdir(dd):
        raise ValueError("Папка назначения не найдена")
    if os.path.isdir(src) and (os.path.realpath(dd) + os.sep).startswith(os.path.realpath(src) + os.sep):
        raise ValueError("Нельзя копировать папку саму в себя")
    dst = _copy_name(dd, os.path.basename(src))
    for k in [k for k, v in COPY_JOBS.items() if v["state"] != "run"][:-5]:
        COPY_JOBS.pop(k, None)
    jid = uuid.uuid4().hex[:8]
    job = {"id": jid, "name": os.path.basename(src), "to": os.path.basename(dst), "done": 0, "total": 0, "state": "run", "error": ""}
    COPY_JOBS[jid] = job
    threading.Thread(target=_copy_worker, args=(job, src, dst), daemon=True).start()
    return {"ok": True, "job": jid, "to": os.path.basename(dst)}


def fop_job(jid):
    j = COPY_JOBS.get(jid)
    if not j:
        raise ValueError("задание не найдено")
    return {k: j[k] for k in ("id", "name", "to", "done", "total", "state", "error")}



def fop_delete(body):
    _file_ops_check()
    pid = str(body.get("path", ""))
    i, root, rel = split_id(pid)
    if not rel:
        raise ValueError("Корневую папку удалить нельзя")
    st = _stat_entry(i, root, rel)
    if not st:
        raise ValueError("Файл не найден (возможно, его уже удалили)")
    is_dir = st[0]
    if not is_url(root):
        _, p = _local_path(root, rel)
        try:
            if is_dir:
                shutil.rmtree(p)
            else:
                os.remove(p)
        except OSError as e:
            raise ValueError("Не удалось удалить: %s" % (e.strerror or e))
    elif _is_ftp(root):
        u = urllib.parse.urlparse(root)
        with _ftp_lock:
            ftp = ftp_connect_retry(u)
            try:
                _ftp_remove(ftp, ftp_path(root, rel), is_dir)
            except ftplib.all_errors as e:
                raise RuntimeError("FTP: %s" % e)
            finally:
                try:
                    ftp.quit()
                except Exception:  # noqa
                    ftp.close()
    else:
        url = url_abs(root, rel).rstrip("/")
        ok = xbmcvfs.rmdir(url + "/", True) if is_dir else xbmcvfs.delete(url)
        if not ok:
            raise RuntimeError("Не удалось удалить: проверьте права на запись в сетевой папке")
    _after_change(pid, None)
    log("file deleted: %s" % pid, ev=False)
    return {"ok": True}


# ---------- FTP -> HTTP relay for Kodi ----------
# Kodi плохо дружит с простыми FTP-серверами (лимит подключений, нет EPSV/SIZE...).
# Поэтому ftp:// играется через локальный HTTP-прокси add-on: Kodi читает http://127.0.0.1,
# а FTP читаем мы сами, по одному соединению на запрос (с поддержкой Range/перемотки).
STREAM_TOKEN = os.urandom(8).hex()
_stream_lock = threading.Lock()
_stream_gen = [0]
_stream_cur = {"key": None, "t": 0.0}  # какой файл сейчас отдаём и когда последний раз шли данные
_size_cache = {}


def ftp_file_size(ftp, path):
    try:
        n = ftp.size(path)
        if n:
            return int(n)
    except ftplib.error_perm:
        pass
    parent, name = posixpath.split(path)
    for nm, is_dir, size in _list_on(ftp, parent or "/"):
        if nm == name and not is_dir:
            return size
    raise RuntimeError("FTP: не удалось узнать размер файла")


def target_for(pid):
    """Что именно отдать Kodi для id из браузера файлов: (адрес, имя, тип)."""
    i, root, rel = split_id(pid)
    if not rel:
        raise ValueError("not a file")
    name = urllib.parse.unquote(rel.split("/")[-1])
    if is_url(root):
        if urllib.parse.urlparse(root).scheme.lower() == "ftp":
            port = int(cfg().getSetting("port") or 8090)
            target = "http://127.0.0.1:%d/stream/%s?id=%s&t=%s" % (
                port, rel.split("/")[-1], urllib.parse.quote(pid, safe=""), STREAM_TOKEN)
        else:
            target = url_abs(root, rel).rstrip("/")
    else:
        _, target = local_abs(root, rel)
        if not os.path.isfile(target):
            raise ValueError("not a file")
    return target, name, kind_of(name)


# ---------- источники (как «Добавить источник» в Kodi), скачивание и загрузка файлов ----------
SRC_PROTOS = {"ftp": 21, "sftp": 22, "smb": 0, "nfs": 0, "dav": 80, "davs": 443}
_src_cache = {"mt": None, "v": []}
_src_lock = threading.Lock()


def _src_path():
    return os.path.join(data_dir(), "sources.json")


def sources_load():
    try:
        mt = os.path.getmtime(_src_path())
    except OSError:
        return []
    if _src_cache["mt"] != mt:
        try:
            with open(_src_path(), encoding="utf-8") as f:
                v = json.load(f)
        except Exception:  # noqa
            v = []
        _src_cache.update(mt=mt, v=v if isinstance(v, list) else [])
    return _src_cache["v"]


def _sources_write(lst):
    p = _src_path()
    with open(p + ".tmp", "w", encoding="utf-8") as f:
        json.dump(lst, f, ensure_ascii=False)
    try:
        os.chmod(p + ".tmp", 0o600)  # внутри пароли
    except OSError:
        pass
    os.replace(p + ".tmp", p)
    _src_cache["mt"] = None


def source_url(s):
    proto = s["proto"]
    q = lambda x: urllib.parse.quote(x, safe="")  # noqa: E731
    cred = ""
    if s.get("user"):
        cred = q(s["user"]) + (":" + q(s["pass"]) if s.get("pass") else "") + "@"
    hp = s["host"] + (":%d" % s["port"] if s.get("port") else "")
    path = "/".join(q(x) for x in (s.get("path") or "").strip("/").split("/") if x)
    return "%s://%s%s%s" % (proto, cred, hp, ("/" + path) if path else "")


def root_sid(r):
    for sc in sources_load():
        try:
            if source_url(sc) == r:
                return sc["id"]
        except Exception:  # noqa
            pass
    return ""


def root_label(r):
    for s in sources_load():
        try:
            if source_url(s) == r:
                return s.get("name") or root_name(r)
        except Exception:  # noqa
            pass
    return root_name(r)


def sources_public():
    return {"protos": [{"id": k, "port": v} for k, v in SRC_PROTOS.items()],
            "items": [{"id": s["id"], "name": s.get("name", ""), "proto": s["proto"], "host": s["host"],
                       "port": s.get("port") or 0, "path": s.get("path", ""), "user": s.get("user", ""),
                       "has_pass": bool(s.get("pass"))} for s in sources_load()]}


def _source_from_body(body, keep=None):
    proto = str(body.get("proto", "")).lower()
    if proto not in SRC_PROTOS:
        raise ValueError("Неизвестный протокол")
    host = str(body.get("host", "")).strip()
    host = re.sub(r"^[a-z]+://", "", host, flags=re.I).strip("/ ")
    if "@" in host or "/" in host or not host:
        raise ValueError("Укажите адрес сервера (например 192.168.1.10)")
    try:
        port = int(body.get("port") or 0)
    except ValueError:
        raise ValueError("Порт должен быть числом")
    if not 0 <= port <= 65535:
        raise ValueError("Недопустимый порт")
    pw = body.get("pass")
    if (pw is None or pw == "") and keep and not body.get("clear_pass"):
        pw = keep.get("pass", "")
    return {"id": (keep or {}).get("id") or uuid.uuid4().hex[:8],
            "name": " ".join(str(body.get("name", "")).split())[:60] or host,
            "proto": proto, "host": host, "port": port, "path": str(body.get("path", "")).strip(),
            "user": str(body.get("user", "")).strip(), "pass": pw or ""}


def source_save(body):
    with _src_lock:
        lst = list(sources_load())
        keep = next((x for x in lst if x["id"] == body.get("id")), None) if body.get("id") else None
        if body.get("id") and not keep:
            raise ValueError("источник не найден")
        s = _source_from_body(body, keep)
        if keep:
            lst[lst.index(keep)] = s
        else:
            if len(lst) >= 20:
                raise ValueError("Слишком много источников (максимум 20)")
            lst.append(s)
        _sources_write(lst)
    return {"ok": True, "id": s["id"]}


def source_delete(body):
    with _src_lock:
        lst = [x for x in sources_load() if x["id"] != body.get("id")]
        _sources_write(lst)
    return {"ok": True}


def source_test(body):
    keep = next((x for x in sources_load() if x["id"] == body.get("id")), None) if body.get("id") else None
    root = source_url(_source_from_body(body, keep))
    if urllib.parse.urlparse(root).scheme == "ftp":
        entries = ftp_list(root, "")
    else:
        entries = vfs_list(root.rstrip("/") + "/")
    return {"ok": True, "count": len(entries)}


def _open_chunks(pid):
    """(имя, размер или None, генератор кусков) — читаем файл из любого источника: локальный, FTP или VFS Kodi."""
    i, root, rel = split_id(pid)
    if not rel:
        raise ValueError("это не файл")
    name = urllib.parse.unquote(rel.split("/")[-1])
    if not is_url(root):
        _, p = local_abs(root, rel)
        if not os.path.isfile(p):
            raise ValueError("это не файл")

        def gen_local():
            with open(p, "rb") as f:
                while True:
                    b = f.read(1 << 20)
                    if not b:
                        break
                    yield b
        return name, os.path.getsize(p), gen_local
    if urllib.parse.urlparse(root).scheme.lower() == "ftp":
        u = urllib.parse.urlparse(root)
        path = ftp_path(root, rel)
        ftp = ftp_connect_retry(u)
        try:
            size = ftp_file_size(ftp, path)
        except Exception:  # noqa
            size = None

        def gen_ftp():
            try:
                ftp.voidcmd("TYPE I")
                conn = ftp.transfercmd("RETR " + path)
                try:
                    while True:
                        b = conn.recv(1 << 18)
                        if not b:
                            break
                        yield b
                finally:
                    conn.close()
            finally:
                try:
                    ftp.close()
                except Exception:  # noqa
                    pass
        return name, size, gen_ftp
    url = url_abs(root, rel).rstrip("/")
    vf = xbmcvfs.File(url)
    size = int(vf.size() or 0) or None

    def gen_vfs():
        try:
            while True:
                b = vf.readBytes(1 << 20)
                if not b:
                    break
                yield bytes(b)
        finally:
            vf.close()
    return name, size, gen_vfs


class _Body:
    """Ограниченный по длине читатель тела запроса (для загрузки файла)."""

    def __init__(self, rfile, n):
        self.rfile, self.left = rfile, n

    def read(self, k=-1):
        if self.left <= 0:
            return b""
        k = self.left if k is None or k < 0 else min(k, self.left)
        b = self.rfile.read(k)
        self.left -= len(b)
        return b


def _unique_path(d, name):
    p = os.path.join(d, name)
    if not os.path.exists(p):
        return p
    stem, ext = os.path.splitext(name)
    n = 1
    while os.path.exists(os.path.join(d, "%s (%d)%s" % (stem, n, ext))):
        n += 1
    return os.path.join(d, "%s (%d)%s" % (stem, n, ext))


def upload_file(rfile, length, dir_pid, name):
    """Принимаем файл с телефона и кладём в папку dir_pid (локальную, FTP или любую, что умеет Kodi VFS)."""
    _file_ops_check()
    name = _clean_name(name)
    i, root, rel = split_id(dir_pid)
    body = _Body(rfile, length)
    if not is_url(root):
        _, d = local_abs(root, rel)
        if not os.path.isdir(d):
            raise ValueError("папка назначения не найдена")
        if shutil.disk_usage(d).free < length + 64 * MB:
            raise ValueError("Недостаточно места на диске (%s свободно)" % fmtsize(shutil.disk_usage(d).free))
        dest = _unique_path(d, name)
        tmp = dest + ".part"
        try:
            with open(tmp, "wb") as f:
                while True:
                    b = body.read(1 << 20)
                    if not b:
                        break
                    f.write(b)
            if body.left:
                raise RuntimeError("загрузка прервана")
            os.replace(tmp, dest)
        except BaseException:
            try:
                os.remove(tmp)
            except OSError:
                pass
            raise
        return {"ok": True, "name": os.path.basename(dest), "size": length}
    if urllib.parse.urlparse(root).scheme.lower() == "ftp":
        ftp = ftp_connect_retry(urllib.parse.urlparse(root))
        try:
            ftp.voidcmd("TYPE I")
            ftp.storbinary("STOR " + posixpath.join(ftp_path(root, rel), name), body, 262144)
        finally:
            try:
                ftp.close()
            except Exception:  # noqa
                pass
    else:
        url = url_abs(root, rel).rstrip("/") + "/" + urllib.parse.quote(name, safe="")
        vf = xbmcvfs.File(url, "w")
        try:
            while True:
                b = body.read(1 << 20)
                if not b:
                    break
                if not vf.write(bytearray(b)):
                    raise RuntimeError("не удалось записать на источник")
        finally:
            vf.close()
    if body.left:
        raise RuntimeError("загрузка прервана")
    return {"ok": True, "name": name, "size": length}


def fmtsize(n):
    for u in ("Б", "КБ", "МБ", "ГБ", "ТБ"):
        if n < 1024 or u == "ТБ":
            return "%.1f %s" % (n, u) if u != "Б" else "%d Б" % n
        n /= 1024.0


# ---------- add-ons Kodi: список, обзор содержимого (с обложками и описаниями), запуск ----------
_art_cache = collections.OrderedDict()
_art_bytes = [0]
ADDON_KINDS = (("video", "video"), ("audio", "audio"), ("image", "image"), ("executable", "program"))
ADDON_MEDIA = {"video": "video", "audio": "music", "image": "pictures", "program": "files"}
ART_SCHEMES = ("image://", "special://", "http://", "https://", "resource://")


ART_EXT = (".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp")


def _art_local(u):
    """Локальный файл-картинка add-on'а: image://…/, special://… или обычный путь. Берём только файлы внутри папок
    add-on'ов и медиа Kodi — читать произвольные файлы приставки через этот адрес нельзя."""
    if u.startswith("image://"):
        u = urllib.parse.unquote(u[len("image://"):].rstrip("/"))
    u = u.split("|")[0]
    if u.startswith("special://"):
        try:
            u = xbmcvfs.translatePath(u)
        except Exception:  # noqa
            return ""
    if u.startswith("/") and ".." not in u and u.lower().endswith(ART_EXT) and \
            any(k in u for k in ("/addons/", "/media/", "/skin.")) and os.path.isfile(u):
        return u
    return ""


def art_fetch(url):
    """Картинка add-on'а (обложка, значок, фон): локальный файл или через VFS Kodi. Только безопасные адреса,
    общий лимит кэша."""
    if len(url) > 2000:
        raise ValueError("недопустимый адрес картинки")
    hit = _art_cache.get(url)
    if hit:
        return hit
    lp = _art_local(url)
    if lp:
        with open(lp, "rb") as fh:
            data = fh.read(6 * MB)
    elif url.startswith(ART_SCHEMES):
        f = xbmcvfs.File(url)
        try:
            data = bytes(f.readBytes(6 * MB))
        finally:
            f.close()
    else:
        raise ValueError("недопустимый адрес картинки")
    if len(data) < 100:
        raise RuntimeError("нет картинки")
    ctype = "image/png" if data[:4] == b"\x89PNG" else "image/webp" if data[:4] == b"RIFF" else \
        "image/gif" if data[:3] == b"GIF" else "image/jpeg"
    _art_cache[url] = (data, ctype)
    _art_bytes[0] += len(data)
    while _art_bytes[0] > 40 * MB or len(_art_cache) > 400:
        _, (d, _c) = _art_cache.popitem(last=False)
        _art_bytes[0] -= len(d)
    return data, ctype


def _art_proxy(u):
    return "/api/addonart?u=" + urllib.parse.quote(u, safe="") if u else ""


def _art_direct(u):
    """Если обложка лежит в интернете (TMDB и т. п.), отдаём браузеру прямую ссылку: быстрее и не нагружает приставку.
    Kodi часто оборачивает такой адрес в image://…/ — разворачиваем."""
    if not u:
        return ""
    if u.startswith("image://"):
        u = urllib.parse.unquote(u[len("image://"):].rstrip("/"))
    u = u.split("|")[0]
    return u if u.startswith(("http://", "https://")) else ""


def _art_url(u):
    return _art_direct(u) or _art_proxy(u)


def addons_list():
    calls = []
    for c, _k in ADDON_KINDS:
        p = {"content": c, "enabled": True, "properties": ["name", "summary", "thumbnail", "fanart", "path"]}
        if c != "executable":            # «Программы» — это и плагины, и скрипты (CoreELEC Configuration и т. п.)
            p["type"] = "xbmc.python.pluginsource"
        calls.append(("Addons.GetAddons", p))
    res = sorted([r for r in rpc_batch(calls) if isinstance(r, dict)], key=lambda r: r.get("id", 0))
    seen, out = set(), []
    for (c, kind), r in zip(ADDON_KINDS, res):
        for a in ((r or {}).get("result") or {}).get("addons") or []:
            aid = a.get("addonid")
            if not aid or aid in seen or aid == ADDON_ID:
                continue
            seen.add(aid)
            base = a.get("path") or ""
            icon = next((p for p in (os.path.join(base, x) for x in ("icon.png", "resources/icon.png", "icon.jpg",
                                                                      "resources/media/icon.png", "resources/icon.jpg"))
                         if base and os.path.isfile(p)), "")
            fan = next((p for p in (os.path.join(base, x) for x in ("fanart.jpg", "resources/fanart.jpg", "fanart.png"))
                        if base and os.path.isfile(p)), "")
            out.append({"id": aid, "name": a.get("name") or aid, "summary": a.get("summary") or "",
                        "kind": kind, "thumb": _art_proxy(icon) if icon else _art_url(a.get("thumbnail")),
                        "thumb2": _art_proxy(a.get("thumbnail")),
                        "fanart": _art_proxy(fan) if fan else _art_url(a.get("fanart"))})
    out.sort(key=lambda x: x["name"].lower())
    try:
        me = cfg()
        base = me.getAddonInfo("path")
        ic = next((p for p in (os.path.join(base, x) for x in ("icon.png", "resources/icon.png")) if os.path.isfile(p)), "")
        out.insert(0, {"id": ADDON_ID, "name": me.getAddonInfo("name") or "Phone Remote",
                       "summary": "Настройки этого add-on", "kind": "self", "thumb": _art_proxy(ic), "thumb2": "", "fanart": ""})
    except Exception:  # noqa
        pass
    return {"items": out}


# ---------- настройки add-on'ов (читаем resources/settings.xml, значения через xbmcaddon) ----------
_PO_CACHE = {}
LOCKED_SETTINGS = {ADDON_ID: {"shell_enabled", "remote_enabled", "remote_pin", "remote_port", "remote_shell"}}
HIDDEN_SETTINGS = {ADDON_ID: {"remote_pin"}}   # включение оболочки из веб-интерфейса запрещено: он без пароля


def _po_strings(base):
    """{id: текст} из resources/language/*/strings.po: русский приоритетнее английского."""
    if base in _PO_CACHE:
        return _PO_CACHE[base]
    out = {}
    root = os.path.join(base, "resources", "language")
    dirs = sorted(glob.glob(os.path.join(root, "resource.language.*")), key=lambda d: (
        0 if d.endswith("en_gb") else 1 if d.endswith("en_us") else 2))
    ru = [d for d in dirs if d.endswith("ru_ru")]
    for d in dirs + ru:                                  # ru последним — перекрывает
        try:
            txt = open(os.path.join(d, "strings.po"), encoding="utf-8").read()
        except Exception:  # noqa
            continue
        for m in re.finditer(r'msgctxt "#(\d+)"\s*\nmsgid "((?:[^"\\]|\\.)*)"\s*\nmsgstr "((?:[^"\\]|\\.)*)"', txt):
            v = (m.group(3) if d in ru and m.group(3) else m.group(2)).replace('\\"', '"').replace("\\n", "\n")
            if v or m.group(1) not in out:
                out[m.group(1)] = v
    _PO_CACHE[base] = out
    return out


def _lab(po, v):
    v = (v or "").strip()
    return po.get(v, "") or ("" if v.isdigit() else v) if v else ""


def _tx(e, tag, default=""):
    x = e.find(tag)
    return (x.text or "").strip() if x is not None and x.text is not None else default


def _parse_settings(base, po):
    """Список групп [{title, items:[{id,type,label,value,...}]}] из settings.xml (формат Kodi 18- и 19+)."""
    import xml.etree.ElementTree as ET
    path = os.path.join(base, "resources", "settings.xml")
    if not os.path.isfile(path):
        return []
    root = ET.parse(path).getroot()
    cats = []

    def mk(id_, typ, label, default, extra):
        d = {"id": id_, "type": typ, "label": label, "default": default}
        d.update(extra)
        return d

    if root.find("section") is not None:                         # новый формат
        for cat in root.iter("category"):
            items = []
            for st in cat.iter("setting"):
                sid, typ = st.get("id"), st.get("type") or "string"
                if not sid:
                    continue
                ctl = st.find("control")
                ctype = (ctl.get("type") if ctl is not None else "") or ""
                lbl = _lab(po, st.get("label")) or sid
                ex = {}
                con = st.find("constraints")
                opts = [] if con is None else [{"v": (o.text or "").strip(), "l": _lab(po, o.get("label")) or (o.text or "").strip()}
                                               for o in con.iter("option")]
                if con is not None and con.find("options") is not None and con.find("options").get("format") == "string" \
                        and not opts:
                    pass
                if typ == "action" or ctype == "button" and typ not in ("path", "string", "integer", "number"):
                    k = "action"
                elif typ == "boolean":
                    k = "bool"
                elif typ in ("integer", "number"):
                    k = "num" if not opts else "list"
                    if con is not None and typ == "integer":
                        mn, mx, stp = _tx(con, "minimum"), _tx(con, "maximum"), _tx(con, "step")
                        ex.update({k2: v for k2, v in (("min", mn), ("max", mx), ("step", stp)) if v != ""})
                    ex["float"] = typ == "number"
                elif typ == "path":
                    k = "text"
                    ex["hint"] = "путь"
                else:
                    k = "list" if opts else "text"
                    if ctl is not None and (ctl.get("hidden") == "true" or ctype == "edit" and ctl.get("hidden") == "true"):
                        ex["secret"] = True
                if opts:
                    ex["options"] = opts
                if typ == "string" and ctl is not None and ctl.get("hidden") == "true":
                    ex["secret"] = True
                items.append(mk(sid, typ, lbl, _tx(st, "default"), dict(ex, kind=k)))
            if items:
                cats.append({"title": _lab(po, cat.get("label")) or cat.get("id") or "", "items": items})
    else:                                                       # старый формат
        for cat in root.iter("category") if root.find("category") is not None else [root]:
            items = []
            for st in cat.findall("setting"):
                sid, typ = st.get("id"), (st.get("type") or "text").lower()
                if typ in ("sep", "lsep") or not sid:
                    continue
                lbl = _lab(po, st.get("label")) or sid
                ex = {}
                if typ in ("bool",):
                    k = "bool"
                elif typ in ("number", "slider"):
                    k = "num"
                    rg = st.get("range") or ""
                    if "," in rg:
                        a, b = rg.split(",")[:2]
                        ex.update({"min": a, "max": b})
                    ex["float"] = st.get("option") == "float"
                elif typ in ("enum", "labelenum", "select"):
                    k = "list"
                    vals = (st.get("values") or "").split("|") if st.get("values") else []
                    lv = (st.get("lvalues") or "").split("|") if st.get("lvalues") else []
                    if typ == "enum":
                        ex["options"] = [{"v": str(i), "l": _lab(po, (lv[i] if i < len(lv) else (vals[i] if i < len(vals) else str(i))))}
                                         for i in range(max(len(lv), len(vals)))]
                    else:
                        ex["options"] = [{"v": v, "l": _lab(po, lv[i]) if i < len(lv) else v} for i, v in enumerate(vals)]
                elif typ in ("action", "executebuiltin"):
                    k = "action"
                else:
                    k = "text"
                    if typ in ("folder", "file", "audio", "video", "image", "executable"):
                        ex["hint"] = "путь"
                    if st.get("option") == "hidden":
                        ex["secret"] = True
                items.append(mk(sid, typ, lbl, st.get("default") or "", dict(ex, kind=k)))
            if items:
                cats.append({"title": _lab(po, cat.get("label")) or "", "items": items})
    return cats


def _addon_obj(aid):
    if not re.fullmatch(r"[A-Za-z0-9_.\-]{1,100}", aid or ""):
        raise ValueError("недопустимый id add-on'а")
    try:
        return xbmcaddon.Addon(aid)
    except Exception:  # noqa
        raise RuntimeError("add-on не найден: %s" % aid)


def addon_settings(aid):
    a = _addon_obj(aid)
    base = a.getAddonInfo("path")
    po = _po_strings(base)
    cats = _parse_settings(base, po)
    locked = LOCKED_SETTINGS.get(aid, set())
    out = []
    for c in cats:
        its = []
        for it in c["items"]:
            if it["kind"] == "action" or it["id"] in HIDDEN_SETTINGS.get(aid, ()):
                continue
            try:
                val = a.getSetting(it["id"])
            except Exception:  # noqa
                val = ""
            it["value"] = val if val != "" else it["default"] if it["kind"] != "text" else val
            if it["kind"] == "bool":
                it["value"] = "true" if str(it["value"]).lower() == "true" else "false"
            if it["id"] in locked:
                it["locked"] = "меняется только на самой приставке"
            its.append(it)
        if its:
            out.append({"title": c["title"], "items": its})
    return {"id": aid, "name": a.getAddonInfo("name") or aid, "groups": out,
            "icon": _art_proxy(next((p for p in (os.path.join(base, x) for x in ("icon.png", "resources/icon.png"))
                                     if os.path.isfile(p)), ""))}


def addon_setting_set(body):
    aid, changes = body.get("id", ""), body.get("values")
    if not isinstance(changes, dict) or not changes or len(changes) > 200:
        raise ValueError("нечего сохранять")
    a = _addon_obj(aid)
    base = a.getAddonInfo("path")
    known = {it["id"]: it for c in _parse_settings(base, _po_strings(base)) for it in c["items"]}
    locked = LOCKED_SETTINGS.get(aid, set())
    n = 0
    for k, v in changes.items():
        it = known.get(k)
        if not it or it["kind"] == "action":
            raise ValueError("неизвестная настройка: %s" % k)
        if k in locked:
            raise ValueError("настройку «%s» можно менять только на приставке" % it["label"])
        v = "true" if v is True else "false" if v is False else str(v)
        if len(v) > 4000:
            raise ValueError("слишком длинное значение")
        if it["kind"] == "bool":
            v = "true" if v.lower() == "true" else "false"
        elif it["kind"] == "num":
            try:
                float(v)
            except ValueError:
                raise ValueError("«%s»: нужно число" % it["label"])
        elif it["kind"] == "list" and it.get("options") and v not in [o["v"] for o in it["options"]]:
            raise ValueError("«%s»: недопустимое значение" % it["label"])
        a.setSetting(k, v)
        n += 1
    log("настройки add-on'а %s изменены из веб-интерфейса: %d" % (aid, n))
    return {"ok": True, "saved": n}



# ---------- установка add-on'ов: из репозитория и из ZIP ----------
_repo_cache = {}
MAX_ZIP = 300 * 1024 * 1024


def _install_allowed():
    if (cfg().getSetting("allow_install") or "true") != "true":
        raise RuntimeError("Установка add-on'ов с веб-страницы выключена в настройках Phone Remote")


REPO_CATS = [("repository", "Add-on repository"), ("audiodecoder", "Audio decoders"), ("audioencoder", "Audio encoders"),
             ("context", "Context menus"), ("game", "Game add-ons"), ("imagedecoder", "Image decoder"),
             ("info", "Information providers"), ("look", "Look and feel"), ("lyrics", "Lyrics"),
             ("audio", "Music add-ons"), ("peripheral", "Peripheral libraries"), ("image", "Picture add-ons"),
             ("program", "Program add-ons"), ("pvr", "PVR clients"), ("service", "Services"), ("subtitle", "Subtitles"),
             ("video", "Video add-ons"), ("inputstream", "VideoPlayer InputStream"), ("vfs", "Virtual filesystems"),
             ("weather", "Weather"), ("web", "Web interface")]
_TYPE_CAT = (("repository", "repository"), ("audiodecoder", "audiodecoder"), ("audioencoder", "audioencoder"),
             ("context", "context"), ("imagedecoder", "imagedecoder"), ("metadata.scraper", "info"),
             ("lyrics", "lyrics"), ("peripheral", "peripheral"), ("pvrclient", "pvr"), ("xbmc.service", "service"),
             ("subtitle", "subtitle"), ("inputstream", "inputstream"), ("kodi.vfs", "vfs"), ("weather", "weather"),
             ("webinterface", "web"), ("skin", "look"), ("resource.", "look"), ("screensaver", "look"),
             ("visualization", "look"), ("musicviz", "look"), ("game", "game"))


_repo_lock = threading.Lock()
_repo_bg = [False]


def _repo_file():
    return os.path.join(data_dir(), "repo_cache.json")


def _repo_disk_load():
    """Список из прошлого запуска (хранится на диске): открывается мгновенно, обновляется в фоне."""
    try:
        with open(_repo_file(), "r", encoding="utf-8") as f:
            d = json.load(f)
        items = d["items"]
        for i in items:
            i["cats"] = set(i["cats"])
        return d["t"], items
    except Exception:
        return None


def _repo_disk_save(items):
    try:
        with open(_repo_file(), "w", encoding="utf-8") as f:
            json.dump({"t": time.time(), "items": [dict(i, cats=sorted(i["cats"])) for i in items]}, f, ensure_ascii=False)
    except Exception as e:  # noqa
        log("repo cache save: %s" % e, ev=False)


def _repo_refresh_bg():
    if _repo_bg[0]:
        return
    _repo_bg[0] = True

    def run():
        try:
            _repo_fetch()
        except Exception as e:  # noqa
            log("repo refresh: %s" % e, ev=False)
        finally:
            _repo_bg[0] = False
    threading.Thread(target=run, daemon=True).start()


def _repo_installed():
    hit = _repo_cache.get("inst")
    if hit and time.time() - hit[0] < 20:
        return hit[1]
    r = rpc("Addons.GetAddons", {"installed": True}).get("result", {}).get("addons") or []
    ids = {a.get("addonid") for a in r}
    _repo_cache["inst"] = (time.time(), ids)
    return ids


def _repo_load():
    """Список add-on'ов из репозиториев без уже установленных. Память → диск → запрос в Kodi (одновременно один)."""
    hit = _repo_cache.get("all")
    if hit and time.time() - hit[0] < 600:
        items = hit[1]
    else:
        with _repo_lock:
            hit = _repo_cache.get("all")
            if not (hit and time.time() - hit[0] < 600):
                disk = None if hit else _repo_disk_load()
                if disk and time.time() - disk[0] < 14 * 86400:
                    _repo_cache["all"] = (time.time() - (590 if time.time() - disk[0] > 600 else 0), disk[1])
                    if time.time() - disk[0] > 600:
                        _repo_refresh_bg()
                elif hit:
                    _repo_cache["all"] = (time.time() - 590, hit[1])   # устарел — отдаём старый, обновляем в фоне
                    _repo_refresh_bg()
                else:
                    return _repo_visible(_repo_fetch())
            items = _repo_cache["all"][1]
    return _repo_visible(items)


def _repo_visible(items):
    inst = _repo_installed()
    return [i for i in items if i["id"] not in inst]


def _repo_fetch():
    t0 = time.time()
    props = ["name", "summary", "version", "author", "thumbnail", "broken"]   # type Kodi отдаёт сам
    calls = [("Addons.GetAddons", {"installed": False, "enabled": "all", "properties": props})]
    contents = ("video", "audio", "image", "executable")
    calls += [("Addons.GetAddons", {"installed": False, "enabled": "all", "content": c, "properties": ["name"]})
              for c in contents]
    res = sorted([r for r in rpc_batch(calls) if isinstance(r, dict)], key=lambda r: r.get("id", 0))
    log("Addons.GetAddons: ответ Kodi за %.1f с" % (time.time() - t0), ev=False)
    first = res[0] if res else {}
    if not first or "error" in first:          # запасной вариант: самый простой запрос
        r2 = rpc("Addons.GetAddons", {"installed": False, "properties": ["name", "summary", "version", "author",
                                                                          "thumbnail"]})
        if r2 and "error" not in r2:
            first = {"result": r2.get("result")}
    if not first or "error" in first:
        raise RuntimeError("Список add-on'ов из репозиториев недоступен: %s" %
                           (((first or {}).get("error") or {}).get("message") or "нет ответа (включены ли репозитории?)"))
    by_content = {}
    for c, r in zip(contents, res[1:]):
        by_content[c] = {a.get("addonid") for a in ((r or {}).get("result") or {}).get("addons") or []}
    items = []
    for a in (first.get("result") or {}).get("addons") or []:
        aid = a.get("addonid")
        if a.get("broken") or not aid or aid == ADDON_ID:
            continue
        t = (a.get("type") or "").lower()
        cats = set()
        for c, cat in (("video", "video"), ("audio", "audio"), ("image", "image"), ("executable", "program")):
            if aid in by_content.get(c, ()) and t.endswith(("pluginsource", "script")):
                cats.add(cat)
        for key, cat in _TYPE_CAT:
            if key in t:
                cats.add(cat)
                break
        if not cats:
            continue                       # библиотеки/модули Kodi в списках не показывает
        items.append({"id": aid, "name": a.get("name") or aid, "summary": a.get("summary") or "",
                      "version": a.get("version") or "", "author": a.get("author") or "",
                      "thumb": _art_url(a.get("thumbnail")), "cats": cats})
    items.sort(key=lambda x: x["name"].lower())
    _repo_cache["all"] = (time.time(), items)
    _repo_disk_save(items)
    log("список add-on'ов из репозиториев: %d шт. за %.1f с" % (len(items), time.time() - t0), ev=False)
    return items


def repo_cats():
    items = _repo_load()
    return {"items": [{"id": k, "label": l, "n": sum(1 for i in items if k in i["cats"])} for k, l in REPO_CATS]}


def repo_list(q="", kind="", start=0):
    """Add-on'ы из репозиториев, которые ещё не установлены (кэш 10 минут); kind — категория как в Kodi."""
    q = (q or "").strip().lower()
    items = [i for i in _repo_load() if (not kind or kind in i["cats"]) and
             (not q or q in i["name"].lower() or q in i["id"].lower() or q in i["summary"].lower())]
    start = max(0, int(start or 0))
    page = [{k: v for k, v in i.items() if k != "cats"} for i in items[start:start + 40]]
    return {"items": page, "more": len(items) > start + 40, "total": len(items)}


def addon_has(aid):
    return bool(xbmc.getCondVisibility("System.HasAddon(%s)" % aid))


def addon_install(body):
    _install_allowed()
    aid = str(body.get("id", ""))
    if not re.fullmatch(r"[A-Za-z0-9_.\-]{1,100}", aid):
        raise ValueError("недопустимый id")
    xbmc.executebuiltin("InstallAddon(%s)" % aid)
    _repo_cache.pop("inst", None)
    return {"ok": True}


def addon_state(aid):
    if not re.fullmatch(r"[A-Za-z0-9_.\-]{1,100}", aid or ""):
        raise ValueError("недопустимый id")
    return {"installed": addon_has(aid)}


def install_zip(rfile, n, name):
    """Установка add-on'а из ZIP: проверка структуры, безопасная распаковка в special://home/addons, включение."""
    _install_allowed()
    import xml.etree.ElementTree as ET
    if n <= 0 or n > MAX_ZIP:
        raise ValueError("файл пустой или больше 300 МБ")
    tmp = os.path.join(data_dir(), "install-%s.zip" % uuid.uuid4().hex[:8])
    body = _Body(rfile, n)
    try:
        with open(tmp, "wb") as f:
            while True:
                b = body.read(1 << 20)
                if not b:
                    break
                f.write(b)
        if body.left:
            raise RuntimeError("загрузка прервана")
        try:
            zf = zipfile.ZipFile(tmp)
        except zipfile.BadZipFile:
            raise ValueError("это не ZIP-архив")
        with zf:
            names = [x for x in zf.namelist() if not x.startswith("__MACOSX/") and not x.endswith(".DS_Store")]
            tops = {x.split("/")[0] for x in names if x.strip("/")}
            if len(tops) != 1:
                raise ValueError("в архиве должна быть одна папка add-on'а (внутри addon.xml)")
            top = tops.pop()
            if not re.fullmatch(r"[A-Za-z0-9_.\-]{1,100}", top) or "%s/addon.xml" % top not in names:
                raise ValueError("не похоже на add-on Kodi: нет «%s/addon.xml»" % top)
            total = 0
            for zi in [z for z in zf.infolist() if z.filename in names]:
                nm = zi.filename
                if nm.startswith("/") or ".." in nm.split("/") or "\\" in nm:
                    raise ValueError("небезопасный путь в архиве: %s" % nm)
                total += zi.file_size
            if total > 1024 * MB:
                raise ValueError("архив слишком велик после распаковки")
            root = ET.fromstring(zf.read("%s/addon.xml" % top))
            if root.get("id") != top:
                raise ValueError("id в addon.xml (%s) не совпадает с папкой (%s)" % (root.get("id"), top))
            addons_dir = xbmcvfs.translatePath("special://home/addons/")
            dest = os.path.join(addons_dir, top)
            stage = os.path.join(addons_dir, ".pr-%s-%s" % (top, uuid.uuid4().hex[:6]))
            backup = ""
            try:
                zf.extractall(stage, members=names)
                src = os.path.join(stage, top)
                if os.path.isdir(dest):
                    backup = dest + ".old-" + uuid.uuid4().hex[:6]
                    os.rename(dest, backup)
                os.rename(src, dest)
            except Exception:
                if backup and not os.path.isdir(dest):
                    os.rename(backup, dest)
                raise
            finally:
                shutil.rmtree(stage, ignore_errors=True)
            if backup:
                shutil.rmtree(backup, ignore_errors=True)
        deps = [i.get("addon") for i in root.iter("import") if i.get("addon") and not i.get("optional") == "true"]
        deps = [d for d in deps if not d.startswith("xbmc.") and not d.startswith("kodi.")]
        is_repo = any(e.get("point") == "xbmc.addon.repository" for e in root.iter("extension"))
        xbmc.executebuiltin("UpdateLocalAddons")
        for _ in range(20):
            xbmc.sleep(250)
            if addon_has(top):
                break
        rpc("Addons.SetAddonEnabled", {"addonid": top, "enabled": True})
        if is_repo:                       # репозиторий: сразу просим Kodi скачать его список add-on'ов
            xbmc.executebuiltin("UpdateAddonRepos")
            _repo_cache.pop("inst", None)
            _repo_refresh_bg()
        missing = [d for d in deps if not addon_has(d)]
        for d in missing:
            xbmc.executebuiltin("InstallAddon(%s)" % d)
        log("add-on установлен из ZIP: %s %s" % (top, root.get("version")))
        return {"ok": True, "id": top, "name": root.get("name") or top, "version": root.get("version") or "",
                "deps": missing, "repo": is_repo}
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass



# ---------- все установленные add-on'ы (как «Мои дополнения») и удаление ----------
_TYPE_RU = (("pluginsource", "Плагин"), ("python.script", "Скрипт"), ("python.module", "Библиотека Python"),
            ("xbmc.service", "Служба"), ("repository", "Репозиторий"), ("skin", "Тема"), ("resource.", "Ресурсы"),
            ("screensaver", "Заставка"), ("visualization", "Визуализация"), ("musicviz", "Визуализация"),
            ("scraper", "Скрапер"), ("lyrics", "Тексты песен"), ("subtitle", "Субтитры"), ("pvr", "PVR"),
            ("inputstream", "InputStream"), ("vfs", "Файловая система"), ("weather", "Погода"),
            ("webinterface", "Веб-интерфейс"), ("audiodecoder", "Аудио-декодер"), ("audioencoder", "Аудио-кодер"),
            ("imagedecoder", "Декодер картинок"), ("context", "Контекстное меню"), ("peripheral", "Периферия"),
            ("game", "Игры"))


def _addon_icon(base):
    return next((p for p in (os.path.join(base, x) for x in ("icon.png", "resources/icon.png", "icon.jpg",
                                                              "resources/media/icon.png")) if base and os.path.isfile(p)), "")


def _user_addons_dir():
    return os.path.realpath(xbmcvfs.translatePath("special://home/addons/"))


def addons_all():
    r = rpc("Addons.GetAddons", {"enabled": "all", "properties": ["name", "summary", "version", "author", "thumbnail",
                                                                  "enabled", "path"]})
    if not r or "error" in r:
        raise RuntimeError("Список add-on'ов недоступен: %s" % (((r or {}).get("error") or {}).get("message") or "нет ответа"))
    udir = _user_addons_dir() + os.sep
    out = []
    for a in (r.get("result") or {}).get("addons") or []:
        aid = a.get("addonid")
        if not aid:
            continue
        base = a.get("path") or ""
        t = (a.get("type") or "").lower()
        label = next((l for k, l in _TYPE_RU if k in t), t)
        icon = _addon_icon(base)
        out.append({"id": aid, "name": a.get("name") or aid, "summary": a.get("summary") or "",
                    "version": a.get("version") or "", "author": a.get("author") or "", "type": label,
                    "enabled": a.get("enabled") is not False,
                    "removable": bool(base) and os.path.realpath(base).startswith(udir) and aid != ADDON_ID,
                    "self": aid == ADDON_ID,
                    "thumb": _art_proxy(icon) if icon else _art_url(a.get("thumbnail"))})
    out.sort(key=lambda x: x["name"].lower())
    return {"items": out}


def _addon_dependents(aid, udir):
    """Установленные пользователем add-on'ы, которые требуют удаляемый (import в addon.xml)."""
    import xml.etree.ElementTree as ET
    out = []
    try:
        names = os.listdir(udir)
    except OSError:
        return out
    for n in names:
        p = os.path.join(udir, n, "addon.xml")
        if n == aid or not os.path.isfile(p):
            continue
        try:
            root = ET.parse(p).getroot()
        except Exception:  # noqa
            continue
        if any(i.get("addon") == aid and i.get("optional") != "true" for i in root.iter("import")):
            out.append(root.get("name") or n)
    return out


def addon_uninstall(body):
    """Удаление add-on'а: отключаем, стираем папку (и данные), просим Kodi перечитать список. Встроенной команды
    удаления в Kodi нет, поэтому делаем это сами — так же, как и установку из ZIP."""
    _install_allowed()
    aid = str(body.get("id", ""))
    if not re.fullmatch(r"[A-Za-z0-9_.\-]{1,100}", aid):
        raise ValueError("недопустимый id")
    if aid == ADDON_ID:
        raise ValueError("Phone Remote нельзя удалить из самого себя")
    if not addon_has(aid):
        raise ValueError("add-on не установлен")
    udir = _user_addons_dir()
    try:
        base = xbmcaddon.Addon(aid).getAddonInfo("path")
    except Exception:  # noqa
        base = ""
    rp = os.path.realpath(base) if base else ""
    if not rp or os.path.dirname(rp) != udir or os.path.basename(rp) != aid:
        raise ValueError("Системные add-on'ы Kodi и CoreELEC удалить нельзя")
    deps = _addon_dependents(aid, udir)
    if deps and not body.get("force"):
        return {"ok": False, "needs_force": True, "dependents": deps}
    rpc("Addons.SetAddonEnabled", {"addonid": aid, "enabled": False})
    xbmc.sleep(500)
    try:
        shutil.rmtree(rp)
    except OSError as e:
        rpc("Addons.SetAddonEnabled", {"addonid": aid, "enabled": True})
        raise RuntimeError("Не удалось удалить папку add-on'а: %s" % (e.strerror or e))
    if body.get("data", True):
        try:
            prof = os.path.realpath(xbmcvfs.translatePath("special://profile/addon_data/"))
            shutil.rmtree(os.path.join(prof, aid), ignore_errors=True)
        except Exception:  # noqa
            pass
    xbmc.executebuiltin("UpdateLocalAddons")
    for _ in range(20):
        xbmc.sleep(250)
        if not addon_has(aid):
            break
    log("add-on удалён: %s" % aid)
    return {"ok": True}



# ---------- настройки Kodi (как на приставке: разделы → категории → параметры) ----------
_KS_LEVELS = ("standard", "advanced", "expert")
_ks_cache = {}
_ks_en = {"t": 0, "ids": {}}


def _ks_level(v):
    return v if v in _KS_LEVELS else "expert"


def _read_po(path):
    out = {}
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            ctx = None
            for line in f:
                if line.startswith('msgctxt "#'):
                    ctx = line.strip()[10:-1]
                elif line.startswith("msgid ") and ctx:
                    out[ctx] = line.strip()[7:-1].replace('\\"', '"')
                    ctx = None
    except OSError:
        pass
    return out


def _ks_english():
    """id параметра → английские название и подсказка (из файлов Kodi), чтобы искать по-английски при любом языке интерфейса."""
    if _ks_en["ids"] or time.time() - _ks_en["t"] < 300:
        return _ks_en["ids"]
    _ks_en["t"] = time.time()
    try:
        po = {}
        for p in ("special://xbmc/language/resource.language.en_gb/strings.po",
                  "special://xbmc/addons/resource.language.en_gb/resources/strings.po"):
            po.update(_read_po(xbmcvfs.translatePath(p)))
        ru = {}
        for p in ("special://home/addons/resource.language.ru_ru/resources/strings.po",
                  "special://xbmc/addons/resource.language.ru_ru/resources/strings.po"):
            ru.update(_read_po(xbmcvfs.translatePath(p)))
        d = xbmcvfs.translatePath("special://xbmc/system/settings/")
        ids = {}
        for fn in glob.glob(os.path.join(d, "*.xml")):
            try:
                txt = open(fn, encoding="utf-8", errors="replace").read()
            except OSError:
                continue
            for m in re.finditer(r"<setting\b([^>]*)>", txt):
                at = dict(re.findall(r'(\w+)="([^"]*)"', m.group(1)))
                if not at.get("id"):
                    continue
                e = ids.setdefault(at["id"], ["", ""])
                for k, i in (("label", 0), ("help", 1)):
                    v = at.get(k, "")
                    if v.isdigit():
                        e[i] = (e[i] + " " + po.get(v, "") + " " + ru.get(v, "")).strip()
        _ks_en["ids"] = ids
    except Exception as ex:  # noqa
        log("kodi settings: английские подписи недоступны: %r" % ex, ev=False)
    return _ks_en["ids"]


SRC_MEDIA = ("video", "music", "pictures")


def _sources_file():
    return xbmcvfs.translatePath("special://profile/sources.xml")


def _src_norm(p):
    return (p or "").strip().rstrip("/")


def _src_xml_read():
    """{media: [{"name","path"}]} из sources.xml профиля."""
    import xml.etree.ElementTree as ET
    out = {m: [] for m in SRC_MEDIA}
    fn = _sources_file()
    if not os.path.isfile(fn):
        return out
    try:
        root = ET.parse(fn).getroot()
    except ET.ParseError:
        return out
    for m in SRC_MEDIA:
        sec = root.find(m)
        if sec is None:
            continue
        for sr in sec.findall("source"):
            out[m].append({"name": (sr.findtext("name") or "").strip(), "path": (sr.findtext("path") or "").strip()})
    return out


def _src_public(p):
    """Пароль из адреса не показываем: smb://user:***@host/…"""
    return re.sub(r"(://[^/:@]+):[^@/]*@", r"\1:***@", p or "")


def src_list():
    xml = _src_xml_read()
    out = {}
    for m in SRC_MEDIA:
        loaded = []
        try:
            loaded = rpc("Files.GetSources", {"media": m}).get("result", {}).get("sources", []) or []
        except Exception:  # noqa
            pass
        items, seen = [], set()
        for x in xml[m]:
            k = _src_norm(x["path"])
            ld = any(_src_norm(s.get("file")) == k for s in loaded)
            items.append({"name": x["name"], "path": _src_public(x["path"]), "raw": _src_strip_creds(x["path"]), "editable": True, "pending": not ld})
            seen.add(k)
        for s2 in loaded:
            if _src_norm(s2.get("file")) not in seen:
                items.append({"name": s2.get("label", ""), "path": _src_public(s2.get("file", "")), "raw": _src_strip_creds(s2.get("file", "")), "editable": False, "pending": False})
        out[m] = items
    return {"sources": out}


def _src_xml_write(mut):
    import xml.etree.ElementTree as ET
    fn = _sources_file()
    if os.path.isfile(fn):
        root = ET.parse(fn).getroot()
        if not os.path.isfile(fn + ".phoneremote.bak"):
            shutil.copy2(fn, fn + ".phoneremote.bak")
    else:
        root = ET.Element("sources")
    for m in ("programs", "video", "music", "pictures", "files"):
        if root.find(m) is None:
            sec = ET.SubElement(root, m)
            ET.SubElement(sec, "default", {"pathversion": "1"})
    mut(root)
    try:
        ET.indent(root)
    except AttributeError:
        pass
    tmp = fn + ".tmp"
    ET.ElementTree(root).write(tmp, encoding="utf-8", xml_declaration=True)
    os.replace(tmp, fn)


def _src_strip_creds(p):
    return re.sub(r"^([a-z][a-z0-9+.-]*://)[^/@]*@", r"\1", p, flags=re.I)


def _passwords_add(clean, full):
    import xml.etree.ElementTree as ET
    fn = xbmcvfs.translatePath("special://profile/passwords.xml")
    root = ET.parse(fn).getroot() if os.path.isfile(fn) else ET.Element("passwords")
    for pe in list(root.findall("path")):
        if (pe.findtext("from") or "").strip() == clean:
            root.remove(pe)
    pe = ET.SubElement(root, "path")
    ET.SubElement(pe, "from", {"pathversion": "1"}).text = clean
    ET.SubElement(pe, "to", {"pathversion": "1"}).text = full
    try:
        ET.indent(root)
    except AttributeError:
        pass
    ET.ElementTree(root).write(fn + ".tmp", encoding="utf-8", xml_declaration=True)
    os.replace(fn + ".tmp", fn)
    try:
        os.chmod(fn, 0o600)
    except OSError:
        pass


def src_resolve(pid):
    """Настоящий путь/адрес папки, выбранной в файловом браузере страницы (без логина и пароля)."""
    i, root, rel = split_id(pid)
    if is_url(root):
        p = _src_strip_creds(url_abs(root, urllib.parse.unquote(rel) if rel else ""))
    else:
        _, p = local_abs(root, urllib.parse.unquote(rel))
        if not os.path.isdir(p):
            raise ValueError("это не папка")
    return {"path": p if p.endswith("/") else p + "/", "name": os.path.basename(p.rstrip("/")) or root_label(root)}


# ---- Set content: тип содержимого и скрапер источника видео (как диалог «Set content» в Kodi) ----
CONTENT_ADDON = {"movies": "xbmc.metadata.scraper.movies", "tvshows": "xbmc.metadata.scraper.tvshows",
                 "musicvideos": "xbmc.metadata.scraper.musicvideos"}


def _video_db():
    d = xbmcvfs.translatePath("special://database/")
    fs = sorted(glob.glob(os.path.join(d, "MyVideos*.db")),
                key=lambda f: int(re.sub(r"\D", "", os.path.basename(f)) or 0))
    if not fs:
        raise ValueError("база видео Kodi не найдена")
    return fs[-1]


def _vdb():
    import sqlite3
    c = sqlite3.connect(_video_db(), timeout=15)
    c.row_factory = sqlite3.Row
    return c


def src_scrapers(content):
    t = CONTENT_ADDON.get(content)
    if not t:
        return {"scrapers": []}
    r = rpc("Addons.GetAddons", {"type": t, "enabled": True, "properties": ["name"]}).get("result", {}).get("addons", []) or []
    return {"scrapers": [{"id": a["addonid"], "name": a.get("name") or a["addonid"]} for a in r]}


def src_content_get(path):
    path = _src_strip_creds(path)
    out = {"content": "", "scraper": "", "recursive": True, "folder_names": False, "no_update": False}
    with _vdb() as c:
        row = None
        for cand in {path, path.rstrip("/") + "/", path.rstrip("/")}:
            row = c.execute("SELECT * FROM path WHERE strPath=?", (cand,)).fetchone()
            if row:
                break
    if row:
        k = row.keys()
        out["content"] = (row["strContent"] or "") if "strContent" in k else ""
        out["scraper"] = (row["strScraper"] or "") if "strScraper" in k else ""
        if "scanRecursive" in k and row["scanRecursive"] is not None:
            out["recursive"] = int(row["scanRecursive"]) > 0
        if "useFolderNames" in k:
            out["folder_names"] = bool(row["useFolderNames"])
        if "noUpdate" in k:
            out["no_update"] = bool(row["noUpdate"])
    return out


def src_content_set(body):
    path = _src_strip_creds((body.get("path") or "").strip())
    content = body.get("content") or ""
    scraper = body.get("scraper") or ""
    if not path:
        raise ValueError("не указан источник")
    if content and content not in CONTENT_ADDON:
        raise ValueError("неизвестный тип содержимого")
    if content and not re.fullmatch(r"[A-Za-z0-9_.\-]+", scraper):
        raise ValueError("выберите источник информации (скрапер)")
    if not content:
        scraper = ""
    path = path.rstrip("/") + "/"
    vals = {"strContent": content, "strScraper": scraper, "scanRecursive": 2147483647 if body.get("recursive", True) else 0,
            "useFolderNames": 1 if body.get("folder_names") else 0, "noUpdate": 1 if body.get("no_update") else 0}
    with _vdb() as c:
        cols = {r["name"] for r in c.execute("PRAGMA table_info(path)")}
        if not {"strPath", "strContent", "strScraper"} <= cols:
            raise ValueError("неожиданная структура базы видео Kodi")
        row = c.execute("SELECT * FROM path WHERE strPath=?", (path,)).fetchone()
        vals = {k: v for k, v in vals.items() if k in cols}
        if row:
            if "strSettings" in cols and (row["strScraper"] or "") != scraper:
                vals["strSettings"] = ""     # другой скрапер — его настройки по умолчанию
            if not content and "strHash" in cols:
                vals["strHash"] = None
            c.execute("UPDATE path SET %s WHERE idPath=?" % ",".join("%s=?" % k for k in vals), list(vals.values()) + [row["idPath"]])
        else:
            vals["strPath"] = path
            if "strSettings" in cols:
                vals["strSettings"] = ""
            if "dateAdded" in cols:
                vals["dateAdded"] = time.strftime("%Y-%m-%d %H:%M:%S")
            c.execute("INSERT INTO path (%s) VALUES (%s)" % (",".join(vals), ",".join("?" * len(vals))), list(vals.values()))
    log("set content: %s → %s (%s)" % (_src_public(path), content or "нет", scraper), ev=False)
    return {"ok": True}


def src_add(body):
    import xml.etree.ElementTree as ET
    m = body.get("media")
    name = (body.get("name") or "").strip()
    path = (body.get("path") or "").strip()
    if m not in SRC_MEDIA:
        raise ValueError("неизвестный тип источника")
    if not name or len(name) > 60 or re.search(r"[\x00-\x1f<>]", name):
        raise ValueError("укажите название источника (до 60 символов)")
    if not (re.match(r"^[a-z][a-z0-9+.-]*://", path, re.I) or path.startswith("/")):
        raise ValueError("путь должен быть вида /storage/…, smb://…, nfs://…, ftp://…, http://…")
    if path.startswith("/") and not os.path.isdir(path):
        raise ValueError("такой папки нет на приставке: %s" % path)
    if not path.endswith("/"):
        path += "/"
    full = path
    path = _src_strip_creds(path)   # в sources.xml — адрес без логина/пароля, учётные данные — в passwords.xml (как делает Kodi)
    if any(x["name"].lower() == name.lower() for x in _src_xml_read()[m]):
        raise ValueError("источник с таким названием уже есть")

    def mut(root):
        sec = root.find(m)
        sr = ET.SubElement(sec, "source")
        ET.SubElement(sr, "name").text = name
        ET.SubElement(sr, "path", {"pathversion": "1"}).text = path
        ET.SubElement(sr, "allowsharing").text = "true"
    _src_xml_write(mut)
    if full != path:
        _passwords_add(path, full)
    log("источник добавлен: %s %s" % (m, _src_public(path)), ev=False)
    return {"ok": True, "restart": True}


def src_del(body):
    m, name = body.get("media"), (body.get("name") or "").strip()
    if m not in SRC_MEDIA or not name:
        raise ValueError("неверные параметры")
    hit = []

    def mut(root):
        sec = root.find(m)
        for sr in list(sec.findall("source")):
            if (sr.findtext("name") or "").strip() == name:
                sec.remove(sr)
                hit.append(1)
    _src_xml_write(mut)
    if not hit:
        raise ValueError("источник не найден в sources.xml (системные источники не удаляются)")
    return {"ok": True, "restart": True}


# ---------- зеркало текущего окна Kodi (например, «CoreELEC Configuration») ----------
_win_probe = {}


def _win_lists(wid):
    """Номера списков (Container) в текущем окне. Перебираем id один раз на окно и запоминаем на 40 с."""
    c = _win_probe.get(wid)
    if c and time.time() - c[0] < 40 and c[1]:
        return c[1]
    g = xbmc.getInfoLabel
    ids = []
    for i in list(range(1, 3000)) + list(range(9000, 9100)):
        n = g("Container(%d).NumItems" % i)
        if n and n.isdigit() and int(n) > 0:
            ids.append(i)
    _win_probe[wid] = (time.time(), ids)
    return ids


_WIN_PROPS = ("value", "typ", "entry", "InfoText", "type", "Value")


def win_info():
    wid = _did() or xbmcgui.getCurrentWindowId()  # CoreELEC Configuration — это диалог поверх основного окна
    g = xbmc.getInfoLabel
    out = {"window": wid, "title": g("System.CurrentWindow") or "", "lists": []}
    if wid == 10000:  # главное меню — не зеркалим, чтобы не мигало
        out["title"] = "Home"
        return out
    for i in (_win_lists(wid)[:20]):
        # скрытые списки (другие категории) не показываем
        if not xbmc.getCondVisibility("Control.IsVisible(%d)" % i):
            continue
        try:
            n = int(g("Container(%d).NumItems" % i) or 0)
        except ValueError:
            continue
        cur = g("Container(%d).CurrentItem" % i)
        items = []
        for k in range(min(n, 150)):
            p = "Container(%d).ListItemAbsolute(%d)." % (i, k)
            row = [g(p + "Label"), g(p + "Label2")]
            for pn in _WIN_PROPS[:3]:
                row.append(g(p + "Property(%s)" % pn))
            items.append(row)
        out["lists"].append({"id": i, "n": n, "cur": int(cur) - 1 if cur.isdigit() else -1,
                             "focus": bool(xbmc.getCondVisibility("Control.HasFocus(%d)" % i)), "items": items})
    if out["lists"] and not _win_probe.get(("dbg", wid)):
        _win_probe[("dbg", wid)] = 1
        try:
            l = out["lists"][-1]
            xbmc.log("[service.phoneremote] win %s lists=%s sample=%s" % (wid, [x["id"] for x in out["lists"]], l["items"][:4]), xbmc.LOGINFO)
        except Exception:
            pass
    return out


_CTX_VIEWS = [50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512,
              513, 514, 515, 516, 517, 518, 519, 520]


# ---------- макросы на вкладке Home («＋»): набор шагов, как «Change action» в Aeon Nox ----------
_MK_KEYS = {"up": "Action(Up)", "down": "Action(Down)", "left": "Action(Left)", "right": "Action(Right)",
            "select": "Action(Select)", "back": "Action(Back)", "home": "ActivateWindow(home)", "info": "Action(Info)",
            "context": "Action(ContextMenu)", "playpause": "PlayerControl(Play)", "stop": "PlayerControl(Stop)",
            "next": "PlayerControl(Next)", "prev": "PlayerControl(Previous)", "volup": "Action(VolumeUp)",
            "voldown": "Action(VolumeDown)", "mute": "Mute", "fullscreen": "Action(FullScreen)"}
_MK_WINS = {"home", "videos", "music", "pictures", "programs", "games", "addonbrowser", "favourites", "weather",
            "settings", "skinsettings", "systeminfo", "filemanager", "tvchannels", "radiochannels", "tvguide",
            "playlistvideo", "playlistmusic", "musicvideos", "subtitlesearch", "profiles", "videosettings"}
_MK_TYPES = ("builtin", "addon", "open", "window", "play", "key", "wait")


def _mk_file():
    return os.path.join(data_dir(), "macros.json")


def _ui_file():
    return os.path.join(data_dir(), "ui.json")


def ui_get():
    try:
        with open(_ui_file(), "r", encoding="utf-8") as f:
            u = json.load(f)
        return {"ui": u if isinstance(u, dict) else {}}
    except Exception:
        return {"ui": {}}


def ui_save(body):
    u = body.get("ui")
    if not isinstance(u, dict):
        raise ValueError("нет настроек")
    raw = json.dumps(u, ensure_ascii=False)
    if len(raw) > 40000:
        raise ValueError("настройки слишком большие")
    with open(_ui_file(), "w", encoding="utf-8") as f:
        f.write(raw)
    return {"ok": True}


def mk_load():
    try:
        with open(_mk_file(), "r", encoding="utf-8") as f:
            m = json.load(f).get("macros")
        return m if isinstance(m, list) else []
    except Exception:
        return []


def _mk_clean_steps(steps):
    if not isinstance(steps, list) or len(steps) > 30:
        raise ValueError("шагов должно быть не больше 30")
    out = []
    for st in steps:
        t, v = str((st or {}).get("t", "")), str((st or {}).get("v", "")).strip()
        if t not in _MK_TYPES or len(v) > 600:
            raise ValueError("неверный шаг макроса")
        if not v:
            raise ValueError("у шага не заполнено значение")
        if t == "addon" and not re.fullmatch(r"[A-Za-z0-9_.\-]{1,100}", v):
            raise ValueError("недопустимый id add-on'а: %s" % v[:40])
        if t == "open" and not v.startswith(_HOME_OK):
            raise ValueError("путь должен начинаться с plugin://, videodb://, musicdb://, sources:// и т. п.")
        if t == "window" and v not in _MK_WINS:
            raise ValueError("неизвестное окно: %s" % v[:40])
        if t == "key" and v not in _MK_KEYS:
            raise ValueError("неизвестная кнопка: %s" % v[:40])
        if t == "wait":
            try:
                v = str(max(0.1, min(float(v.replace(",", ".")), 60)))
            except ValueError:
                raise ValueError("пауза: нужно число секунд")
        if t == "builtin" and re.search(r"system\.exec", v, re.I):
            shell_gate()      # запуск программ — только если разрешён терминал
        step = {"t": t, "v": v}
        if t == "open" and str(st.get("m") or "") in ("video", "music", "pictures", "programs"):
            step["m"] = st["m"]
        out.append(step)
    if not out:
        raise ValueError("добавьте хотя бы один шаг")
    return out


def mk_save(body):
    items = body.get("macros")
    if not isinstance(items, list) or len(items) > 60:
        raise ValueError("слишком много макросов")
    res, ids = [], set()
    for m in items:
        mid = str(m.get("id") or uuid.uuid4().hex[:8])
        if not re.fullmatch(r"[A-Za-z0-9_\-]{1,40}", mid) or mid in ids:
            mid = uuid.uuid4().hex[:8]
        ids.add(mid)
        name = str(m.get("name") or "").strip()[:60]
        if not name:
            raise ValueError("у макроса нет названия")
        res.append({"id": mid, "name": name, "icon": str(m.get("icon") or "▶")[:8],
                    "steps": _mk_clean_steps(m.get("steps"))})
    with open(_mk_file(), "w", encoding="utf-8") as f:
        json.dump({"macros": res}, f, ensure_ascii=False, indent=1)
    return {"ok": True, "macros": res}


def _mk_exec(steps):
    for st in steps:
        t, v = st["t"], st["v"]
        try:
            if t == "builtin":
                xbmc.executebuiltin(v)
            elif t == "addon":
                xbmc.executebuiltin("RunAddon(%s)" % v)
            elif t == "open":
                win = {"music": "Music", "pictures": "Pictures", "programs": "Programs"}.get(
                    st.get("m"), "Music" if v.startswith(("musicdb://", "plugin://plugin.audio.")) else "Videos")
                xbmc.executebuiltin('ActivateWindow(%s,"%s",return)' % (win, v.replace('"', "")))
            elif t == "window":
                xbmc.executebuiltin("ActivateWindow(%s)" % v)
            elif t == "play":
                addon_play({"file": v})
            elif t == "key":
                xbmc.executebuiltin(_MK_KEYS[v])
            elif t == "wait":
                end = time.time() + float(v)
                while time.time() < end:
                    time.sleep(0.1)
                continue
        except Exception as e:  # noqa
            log("макрос: шаг %s «%s» не удался: %s" % (t, v[:60], e))
        time.sleep(0.3)      # Kodi нужно время обработать предыдущий шаг


def mk_run(body):
    mid = str(body.get("id") or "")
    steps = body.get("steps")
    if steps is None:
        m = next((x for x in mk_load() if x.get("id") == mid), None)
        if not m:
            raise ValueError("макрос не найден")
        steps = m["steps"]
    steps = _mk_clean_steps(steps)        # заодно проверка (в т. ч. запрет System.Exec без терминала)
    threading.Thread(target=_mk_exec, args=(steps,), daemon=True).start()
    return {"ok": True, "n": len(steps)}


def ctx_open(body):
    """«Больше действий»: открыть папку с пунктом на ТВ, встать на него и вызвать контекстное меню Kodi
    (как долгое нажатие на пульте). Само меню потом показывается в вебе обычным окном выбора."""
    path = str(body.get("path") or "")
    if not path.startswith(_HOME_OK):
        raise ValueError("недопустимый адрес")
    media = str(body.get("media") or "video")
    win = {"music": "Music", "audio": "Music", "pictures": "Pictures", "image": "Pictures"}.get(media, "Videos")
    f, lab = str(body.get("file") or ""), str(body.get("label") or "").strip().lower()
    g = xbmc.getInfoLabel
    xbmc.executebuiltin('ActivateWindow(%s,"%s",return)' % (win, path.replace('"', "")))
    n = 0
    t0 = time.time()
    while time.time() - t0 < 20:
        time.sleep(0.4)
        if _norm_pl(g("Container.FolderPath")) == _norm_pl(path) or g("Container.FolderPath") == path:
            n = _num("Container.NumItems")
            if n > 0:
                break
    if n <= 0:
        raise RuntimeError("Папка на ТВ не открылась")
    time.sleep(0.5)
    idx = -1
    for i in range(min(n, 1000)):
        p = "Container.ListItemAbsolute(%d)." % i
        if f and g(p + "FileNameAndPath") == f:
            idx = i
            break
        if idx < 0 and lab and g(p + "Label").strip().lower() == lab:
            idx = i
    if idx < 0:
        raise RuntimeError("Не нашёл этот пункт в списке на ТВ")
    cur = g("System.CurrentControlID")
    cid = 0
    for c in ([int(cur)] if cur.isdigit() else []) + _CTX_VIEWS:
        if _num("Container(%d).NumItems" % c) == n and xbmc.getCondVisibility("Control.IsVisible(%d)" % c):
            cid = c
            break
    if not cid:
        raise RuntimeError("Не нашёл список на ТВ")
    xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (cid, idx))
    time.sleep(0.5)
    xbmc.executebuiltin("Action(ContextMenu)")
    for _ in range(12):
        time.sleep(0.3)
        if xbmc.getCondVisibility("Window.IsActive(contextmenu)"):
            log("context menu: %s (list %d, item %d) n996=%s cur=%s first=%r" % (
                lab[:40], cid, idx, g("Container(996).NumItems"), g("System.CurrentControlID"),
                g("Container(996).ListItemAbsolute(0).Label")), ev=False)
            return {"ok": True}
    raise RuntimeError("Контекстное меню не открылось")


def win_act(body):
    act = body.get("act")
    g = xbmc.getCondVisibility
    if act == "select":
        i, pos = int(body["id"]), int(body["pos"])
        xbmc.executebuiltin("SetFocus(%d,%d)" % (i, pos))
        time.sleep(0.25)
        if not g("Control.HasFocus(%d)" % i):
            rpc("Input.Right")
            time.sleep(0.3)
            xbmc.executebuiltin("SetFocus(%d,%d)" % (i, pos))
            time.sleep(0.25)
        rpc("Input.Select")
    elif act == "cat":
        # выбор категории в левом списке: на ТВ страница меняется по фокусу
        i, pos = int(body["id"]), int(body["pos"])
        if str(pos + 1) != xbmc.getInfoLabel("Container(%d).CurrentItem" % i):
            xbmc.executebuiltin("SetFocus(%d,%d)" % (i, pos))
            time.sleep(0.4)
        else:
            rpc("Input.Select")
    elif act == "focus":
        xbmc.executebuiltin("SetFocus(%d,%d)" % (int(body["id"]), int(body["pos"])))
    elif act in ("back", "left", "right", "up", "down", "select_cur"):
        rpc({"back": "Input.Back", "left": "Input.Left", "right": "Input.Right", "up": "Input.Up", "down": "Input.Down",
             "select_cur": "Input.Select"}[act])
    else:
        raise ValueError("неизвестное действие")
    _win_probe.clear()
    return {"ok": True}


def library_scan(body):
    """Сканирование (и по желанию очистка) медиатеки видео и музыки средствами Kodi."""
    clean = bool(body.get("clean"))
    done = []
    for lib, name in (("VideoLibrary", "видео"), ("AudioLibrary", "музыка")):
        try:
            rpc(lib + ".Scan", {"showdialogs": True})
            done.append(name)
        except Exception as e:  # noqa
            log("library scan %s: %r" % (lib, e), ev=False)
    if clean:
        for lib in ("VideoLibrary", "AudioLibrary"):
            try:
                rpc(lib + ".Clean", {"showdialogs": True})
            except Exception as e:  # noqa
                log("library clean %s: %r" % (lib, e), ev=False)
    if not done:
        raise ValueError("Kodi не принял команду сканирования")
    return {"ok": True, "scanned": done, "clean": clean}


def ks_sysinfo():
    """Страница «Информация о системе» как в Kodi: сводка, хранилище, сеть, видео, оборудование."""
    g = xbmc.getInfoLabel

    def rows(items):
        out = []
        for lab, val in items:
            v = g(val[1:]) if val.startswith("@") else val
            v = (v or "").strip()
            if v and v.lower() not in ("not available", "n/a", "unknown"):
                out.append([lab, v])
        return out

    cpu = ""
    for ln in _read("/proc/cpuinfo").splitlines():
        k, _, v = ln.partition(":")
        if k.strip().lower() in ("model name", "hardware", "model") and v.strip() and not v.strip().isdigit():
            cpu = v.strip()
            break
    board = _read("/proc/device-tree/model").strip("\x00\n ")
    try:
        un = os.uname()
        kern = "%s %s %s" % (un.sysname, un.release, un.machine)
    except AttributeError:
        kern = ""
    si = sysinfo()
    mt, mf = si.get("mem_total"), si.get("mem_free")
    up = si.get("uptime")
    net = si.get("net") or {}
    summary = rows([
        ("Имя устройства", "@System.FriendlyName"), ("Версия Kodi", "@System.BuildVersion"),
        ("Сборка от", "@System.BuildDate"), ("Git", "@System.BuildVersionGit"), ("Система", si.get("os") or ""),
        ("Ядро", kern), ("Разрешение экрана", "@System.ScreenResolution"),
        ("Память", "%d МБ из %d МБ (%d%%)" % ((mt - mf) // 1048576, mt // 1048576, (mt - mf) * 100 // mt)
         if mt and mf is not None else ""),
        ("Загрузка CPU", "@System.CpuUsage"),
        ("Температура CPU", ("%.1f °C" % si["temp"]) if si.get("temp") is not None else ""),
        ("Время работы", "%dд %dч %dм" % (up // 86400, up % 86400 // 3600, up % 3600 // 60) if up else ""),
        ("Интернет", "@System.InternetState")])
    storage = [[d["name"] + " (" + d["path"] + ")", "свободно %.1f ГБ из %.1f ГБ (занято %d%%)" % (
        d["free"] / 1073741824.0, d["total"] / 1073741824.0, (d["total"] - d["free"]) * 100 // max(1, d["total"]))]
        for d in si.get("disks", [])]
    network = rows([("Состояние", "@Network.LinkState"), ("IP-адрес", si.get("ip") or "@Network.IPAddress"),
                    ("Маска подсети", "@Network.SubnetMask"), ("Шлюз", "@Network.GatewayAddress"),
                    ("DNS 1", "@Network.DNS1Address"), ("DNS 2", "@Network.DNS2Address"),
                    ("MAC-адрес", "@Network.MacAddress"), ("Интерфейс", net.get("iface") or ""),
                    ("Скорость соединения", "%d Мбит/с" % net["speed"] if net.get("speed") else "")])
    video = rows([("Видеоускоритель (GPU)", "@System.RenderRenderer"), ("Разрешение экрана", "@System.ScreenResolution"),
                  ("Режим экрана", "@System.ScreenMode"), ("OpenGL: производитель", "@System.RenderVendor"),
                  ("OpenGL: версия", "@System.RenderVersion"), ("Температура GPU", "@System.GPUTemperature"),
                  ("Поддерживаемые HDR", "@System.SupportedHDRTypes")])
    hardware = rows([("Плата", board), ("Процессор", cpu), ("Ядер", str(os.cpu_count() or "")),
                     ("Частота CPU", "@System.CpuFrequency"), ("Скорость вентилятора", "@System.FanSpeed"),
                     ("Память всего", "%d МБ" % (mt // 1048576) if mt else "")])
    return {"sections": [{"id": "summary", "label": "Сводка", "rows": summary},
                         {"id": "storage", "label": "Хранилище", "rows": storage},
                         {"id": "network", "label": "Сеть", "rows": network},
                         {"id": "video", "label": "Видео", "rows": video},
                         {"id": "hardware", "label": "Оборудование", "rows": hardware}]}


def ks_sections(level):
    r = rpc("Settings.GetSections", {"level": _ks_level(level)})
    if "error" in r:
        raise RuntimeError("Kodi: %s" % ((r["error"] or {}).get("message") or "ошибка"))
    return {"sections": [{"id": x.get("id"), "label": kodi_fmt(x.get("label") or x.get("id")), "help": x.get("help") or ""}
                         for x in (r.get("result") or {}).get("sections", [])]}


def ks_categories(section, level):
    r = rpc("Settings.GetCategories", {"level": _ks_level(level), "section": section})
    if "error" in r:
        raise RuntimeError("Kodi: %s" % ((r["error"] or {}).get("message") or "ошибка"))
    return {"categories": [{"id": x.get("id"), "label": kodi_fmt(x.get("label") or x.get("id")), "help": x.get("help") or ""}
                           for x in (r.get("result") or {}).get("categories", [])]}


def _ks_item(x):
    o = {"id": x.get("id"), "label": kodi_fmt(x.get("label") or x.get("id")), "help": kodi_fmt(x.get("help") or ""),
         "type": x.get("type"), "value": x.get("value"), "enabled": x.get("enabled", True),
         "level": x.get("level"), "parent": x.get("parent") or ""}
    c = x.get("control") or {}
    o["control"] = c.get("type") or ""
    o["format"] = c.get("format") or ""
    for k in ("minimum", "maximum", "step"):
        if x.get(k) is not None:
            o[k] = x[k]
    if x.get("options"):
        o["options"] = [{"label": kodi_fmt(p.get("label") or str(p.get("value"))), "value": p.get("value")}
                        for p in x["options"]][:300]
    return o


def ks_settings(section, category, level):
    r = rpc("Settings.GetSettings", {"level": _ks_level(level), "filter": {"section": section, "category": category}})
    if "error" in r:
        raise RuntimeError("Kodi: %s" % ((r["error"] or {}).get("message") or "ошибка"))
    return {"settings": [_ks_item(x) for x in (r.get("result") or {}).get("settings", [])]}


def ks_set(body):
    sid = str(body.get("id", ""))
    if not re.fullmatch(r"[\w.\-]{1,100}", sid):
        raise ValueError("недопустимый параметр")
    r = rpc("Settings.SetSettingValue", {"setting": sid, "value": body.get("value")})
    if "error" in r or r.get("result") is False:
        raise ValueError("Kodi не принял значение")
    g = rpc("Settings.GetSettingValue", {"setting": sid})
    log("настройка Kodi %s = %r" % (sid, body.get("value")), ev=False)
    return {"ok": True, "value": (g.get("result") or {}).get("value", body.get("value"))}


def ks_reset(body):
    sid = str(body.get("id", ""))
    if not re.fullmatch(r"[\w.\-]{1,100}", sid):
        raise ValueError("недопустимый параметр")
    rpc("Settings.ResetSettingValue", {"setting": sid})
    g = rpc("Settings.GetSettingValue", {"setting": sid})
    return {"ok": True, "value": (g.get("result") or {}).get("value")}


def _ks_index(level):
    """Все параметры (раздел/категория/название/подсказка/английское название) — для поиска; кэш на 2 минуты."""
    lv = _ks_level(level)
    c = _ks_cache.get(lv)
    if c and time.time() - c[0] < 120:
        return c[1]
    en = _ks_english()
    secs = ks_sections(lv)["sections"]
    calls = [("Settings.GetCategories", {"level": lv, "section": s["id"]}) for s in secs]
    rr = rpc_batch(calls)
    pairs = []
    for s, r in zip(secs, sorted(rr, key=lambda x: x.get("id", 0)) if isinstance(rr, list) else []):
        for cat in (r.get("result") or {}).get("categories", []):
            pairs.append((s, cat))
    rr = rpc_batch([("Settings.GetSettings", {"level": lv, "filter": {"section": s["id"], "category": cat["id"]}})
                    for s, cat in pairs])
    idx = []
    for (s, cat), r in zip(pairs, sorted(rr, key=lambda x: x.get("id", 0)) if isinstance(rr, list) else []):
        for x in (r.get("result") or {}).get("settings", []):
            it = _ks_item(x)
            e = en.get(it["id"], ["", ""])
            it.update({"section": s["id"], "section_label": s["label"], "category": cat["id"],
                       "category_label": cat["label"],
                       "hay": " ".join([it["label"], it["help"], it["id"], e[0], e[1], cat["label"], s["label"]]).lower()})
            idx.append(it)
    _ks_cache[lv] = (time.time(), idx)
    return idx


def ks_search(q, level):
    words = [w for w in re.split(r"\s+", (q or "").lower().strip()) if w]
    if not words:
        return {"settings": []}
    out = []
    for it in _ks_index(level):
        if all(w in it["hay"] for w in words):
            o = {k: v for k, v in it.items() if k != "hay"}
            out.append(o)
            if len(out) >= 80:
                break
    return {"settings": out}


# ---------- Elementum: добавить торрент (magnet, ссылка или .torrent с телефона) ----------
ELEMENTUM = "plugin.video.elementum"


def _elementum_check():
    if not addon_has(ELEMENTUM):
        raise ValueError("Elementum не установлен")


def elementum_add(uri, play=False):
    _elementum_check()
    if _ele_kind() == "insert":      # на ТВ открыто окно Elementum «вставьте ссылку/файл»: закрываем его и играем сами
        rpc("Input.Back")
        time.sleep(0.8)
        play = True
    uri = (uri or "").strip()
    if not uri or len(uri) > 8000 or "\n" in uri:
        raise ValueError("Вставьте magnet-ссылку или адрес .torrent")
    if not (uri.startswith(("magnet:?", "http://", "https://")) or uri.startswith(TORRENT_DIR())
            or uri.startswith(_phist_tdir())):
        raise ValueError("Нужна magnet-ссылка, адрес http(s) или файл .torrent")
    if play:
        _phist_pending("magnet" if uri.startswith("magnet:?") else "torrent", uri)
    q = urllib.parse.quote(uri, safe="")
    if play:
        xbmc.executebuiltin("PlayMedia(plugin://%s/play?uri=%s)" % (ELEMENTUM, q))
    else:
        xbmc.executebuiltin("RunPlugin(plugin://%s/torrents/add?uri=%s)" % (ELEMENTUM, q))
    log("Elementum: %s %s" % ("play" if play else "add", mask_url(uri)[:100]))
    return {"ok": True}


def TORRENT_DIR():
    d = os.path.join(xbmcvfs.translatePath("special://temp/"), "phoneremote-torrents")
    os.makedirs(d, exist_ok=True)
    return d + os.sep


def elementum_upload(rfile, n, name, play):
    _elementum_check()
    if n <= 0 or n > 20 * 1024 * 1024:
        raise ValueError("файл пустой или больше 20 МБ")
    base = re.sub(r"[^\w.\- ()\[\]]", "_", os.path.basename(name or "file.torrent"))[:120] or "file.torrent"
    if not base.lower().endswith(".torrent"):
        raise ValueError("Нужен файл .torrent")
    path = os.path.join(TORRENT_DIR(), "%s-%s" % (uuid.uuid4().hex[:6], base))
    body = _Body(rfile, n)
    with open(path, "wb") as f:
        while True:
            b = body.read(1 << 20)
            if not b:
                break
            f.write(b)
    if body.left:
        os.remove(path)
        raise RuntimeError("загрузка прервана")
    with open(path, "rb") as f:
        if f.read(1) != b"d":
            os.remove(path)
            raise ValueError("это не .torrent файл")
    return elementum_add(path, play)



_DIR_PROPS = ["title", "art", "plot", "thumbnail", "file", "year", "rating", "runtime", "duration", "genre",
              "tagline", "size", "artist", "album", "season", "episode", "showtitle", "director", "writer", "studio",
              "country", "mpaa", "votes", "premiered", "originaltitle", "cast", "trailer"]


_KFMT = re.compile(r"\[/?(?:B|I|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT|COLOR[^\]]*)\]", re.I)


def kodi_fmt(t):
    """Убираем разметку Kodi из подписей: [B]…[/B], [COLOR red]…[/COLOR], [CR]."""
    return _KFMT.sub("", (t or "").replace("[CR]", "\n").replace("[cr]", "\n")).strip()


_DIR_PROPS_BASE = ["title", "art", "plot", "thumbnail", "file", "year", "rating", "runtime", "duration", "genre",
                   "tagline", "size", "artist", "album", "season", "episode", "showtitle"]


def _browse_once(path, media, start):
    """Files.GetDirectory с запасными вариантами: Kodi для разных путей (favourites://, pvr://, add-on'ы) принимает
    разные свойства и не везде понимает limits — перебираем от полного набора к минимальному."""
    mini = ["title", "art", "thumbnail", "file"]
    lim = {"start": start, "end": start + 150}
    attempts = [(_DIR_PROPS, lim, media), (_DIR_PROPS_BASE, lim, media), (mini, lim, media), (mini, None, media),
                (["title", "file"], None, media), (mini, None, "files"), (["title", "file"], None, "files")]
    r, last = {}, ""
    for n, (props, lm, md) in enumerate(attempts):
        pr = {"directory": path, "media": md, "properties": props}
        if lm:
            pr["limits"] = lm
        r = rpc("Files.GetDirectory", pr)
        if "error" not in r:
            break
        last = str((r["error"] or {}).get("message") or "")
        log("Files.GetDirectory %s: %s (вариант %d)" % (path[:60], last, n), ev=False)
    if "error" in r:
        raise RuntimeError("Add-on не открылся: %s" % (last or "ошибка"))
    res = r.get("result") or {}
    items = []
    for f in res.get("files") or []:
        art = f.get("art") or {}
        pic = art.get("poster") or art.get("thumb") or f.get("thumbnail") or art.get("icon") or art.get("fanart") or ""
        title = kodi_fmt(f.get("title") or f.get("label") or "")
        sub = []
        if f.get("showtitle"):
            sub.append("%s%s" % (f["showtitle"], " S%02dE%02d" % (f.get("season") or 0, f.get("episode") or 0)
                                 if f.get("episode") else ""))
        if f.get("artist"):
            sub.append(", ".join(f["artist"]) if isinstance(f["artist"], list) else str(f["artist"]))
        if f.get("album"):
            sub.append(str(f["album"]))
        if f.get("year"):
            sub.append(str(f["year"]))
        gen = f.get("genre")
        if gen:
            sub.append(", ".join(gen) if isinstance(gen, list) else str(gen))
        mins = int((f.get("runtime") or f.get("duration") or 0) / 60)
        if mins:
            sub.append("%d мин" % mins)
        if f.get("rating"):
            sub.append("★ %.1f" % float(f["rating"]))
        items.append({"label": kodi_fmt(f.get("label")) or title, "title": title, "dir": f.get("filetype") == "directory",
                      "file": f.get("file", ""), "type": f.get("type") or "", "id": f.get("id"), "thumb": _art_url(pic), "thumb2": _art_proxy(pic),
                      "fanart": _art_url(art.get("fanart")), "fanart2": _art_proxy(art.get("fanart")),
                      "plot": kodi_fmt(f.get("plot") or f.get("tagline") or "")[:1200], "sub": " · ".join(sub),
                      "art": pic if not pic.startswith("image://") or len(pic) < 600 else "",
                      "info": _norm_info(f, f.get("type") or "") if (f.get("filetype") != "directory" and (
                          f.get("cast") or f.get("director") or f.get("writer") or f.get("mpaa") or f.get("country") or
                          f.get("studio") or f.get("tagline") or f.get("originaltitle") or f.get("plot") or
                          f.get("genre") or f.get("year") or f.get("rating"))) else None})
    total = int(((res.get("limits") or {}).get("total")) or 0)
    return {"items": items, "start": start, "total": total, "more": bool(total and start + 150 < total),
            "path": path}


def _norm_pl(p):
    return (p or "").rstrip("/")


def addon_browse(path, media="video", start=0):
    if not path.startswith("plugin://"):
        raise ValueError("недопустимый адрес")
    media = media if media in ("video", "music", "pictures", "files") else "files"
    start = max(0, int(start or 0))
    before = _norm_pl(xbmc.getInfoLabel("Container.FolderPath"))
    out = _browse_once(path, media, start)
    # Поиск и т. п.: add-on спросил текст на ТВ, а результаты открыл в окне ТВ (Container.Update), и сам список вернул
    # пустым («Go back…»). Тогда берём адрес, который открылся на ТВ, и читаем его.
    if not start and all(not i["dir"] and i["label"].lower().startswith(("go back", "..", "назад")) or not i["label"]
                         for i in out["items"]):
        base = path.split("/")[2] if path.count("/") >= 2 else ""
        for _ in range(16):
            xbmc.sleep(400)
            now = xbmc.getInfoLabel("Container.FolderPath")
            if now.startswith("plugin://%s/" % base) and _norm_pl(now) not in (_norm_pl(path), before):
                log("add-on перенаправил на ТВ: %s" % now[:120], ev=False)
                return _browse_once(now, media, 0)
    return out


_HOME_OK = ("videodb://", "musicdb://", "library://", "addons://", "favourites://", "sources://", "pvr://", "plugin://",
            "androidapp://")


def home_browse(path, media="video", start=0):
    """Пункты главного экрана Kodi (библиотеки, источники, избранное, ТВ…) — тот же обзор папок, что и у add-on'ов."""
    if not path.startswith(_HOME_OK):
        raise ValueError("недопустимый адрес")
    media = media if media in ("video", "music", "pictures", "files") else "files"
    if path.rstrip("/") == "favourites:":
        return _favourites_list()
    return _browse_once(path, media, max(0, int(start or 0)))


def _favourites_list():
    """«Избранное» Kodi через Favourites.GetFavourites: Files.GetDirectory для favourites:// отвечает Invalid params."""
    r = rpc("Favourites.GetFavourites", {"properties": ["path", "window", "windowparameter", "thumbnail"]})
    if not isinstance(r, dict) or "error" in r:
        raise RuntimeError("Избранное не открылось: %s" % (((r or {}).get("error") or {}).get("message") or "нет ответа"))
    items = []
    for f in (r.get("result") or {}).get("favourites") or []:
        typ = f.get("type") or ""
        title = kodi_fmt(f.get("title") or "")
        thumb = f.get("thumbnail") or ""
        if typ == "media":
            target, isdir = f.get("path") or "", False
        elif typ == "window":
            target, isdir = f.get("windowparameter") or "", True
        else:
            continue          # скрипты и Android-приложения из избранного через браузер не открываются
        if not target:
            continue
        items.append({"label": title, "title": title, "dir": isdir, "file": target, "type": "", "id": None,
                      "thumb": _art_url(thumb), "thumb2": _art_proxy(thumb), "fanart": "", "fanart2": "", "plot": "",
                      "sub": "", "art": thumb, "info": None})
    return {"items": items, "start": 0, "total": len(items), "more": False, "path": "favourites://"}



# ---------- карточка «Информация», избранное и глобальный поиск ----------
_INFO_PROPS = ["title", "originaltitle", "tagline", "plot", "year", "rating", "votes", "runtime", "genre", "director",
               "writer", "studio", "country", "mpaa", "premiered", "cast", "trailer", "art", "file", "showtitle",
               "season", "episode", "firstaired"]
_INFO_GET = {
    "movie": ("VideoLibrary.GetMovieDetails", "movieid", "moviedetails", _INFO_PROPS),
    "tvshow": ("VideoLibrary.GetTVShowDetails", "tvshowid", "tvshowdetails",
               ["title", "originaltitle", "plot", "year", "rating", "votes", "genre", "studio", "mpaa", "premiered",
                "cast", "art", "season", "episode", "file"]),
    "episode": ("VideoLibrary.GetEpisodeDetails", "episodeid", "episodedetails", _INFO_PROPS),
    "musicvideo": ("VideoLibrary.GetMusicVideoDetails", "musicvideoid", "musicvideodetails",
                   ["title", "plot", "year", "rating", "runtime", "genre", "director", "studio", "premiered", "art",
                    "file", "artist", "album"]),
    "song": ("AudioLibrary.GetSongDetails", "songid", "songdetails",
             ["title", "artist", "album", "genre", "year", "duration", "rating", "art", "file"]),
    "album": ("AudioLibrary.GetAlbumDetails", "albumid", "albumdetails",
              ["title", "artist", "year", "genre", "description", "rating", "art", "label"]),
    "artist": ("AudioLibrary.GetArtistDetails", "artistid", "artistdetails",
               ["description", "genre", "born", "formed", "art"]),
}


def _lst(v):
    return ", ".join(str(x) for x in v if x) if isinstance(v, list) else (str(v) if v else "")


def _norm_info(f, typ=""):
    """Единая карточка «Информация» из полей Kodi (и для пунктов библиотеки, и для пунктов add-on'ов)."""
    art = f.get("art") or {}
    title = kodi_fmt(f.get("title") or f.get("label") or "")
    year = f.get("year") or 0
    rows = []

    def row(label, val):
        val = kodi_fmt(val if isinstance(val, str) else _lst(val)) if val else ""
        if val:
            rows.append([label, val])
    row("Оригинальное название", f.get("originaltitle") if f.get("originaltitle") != title else "")
    if f.get("showtitle"):
        row("Сериал", f["showtitle"] + (" S%02dE%02d" % (f.get("season") or 0, f.get("episode") or 0)
                                         if f.get("episode") else ""))
    row("Режиссёр", f.get("director"))
    row("Сценарий", f.get("writer"))
    if f.get("rating"):
        v = int(f.get("votes") or 0) if str(f.get("votes") or "").isdigit() else 0
        row("Рейтинг", "%.1f%s" % (float(f["rating"]), " (%d голосов)" % v if v else ""))
    row("Жанр", f.get("genre"))
    row("Страна", f.get("country"))
    row("Студия", f.get("studio") if not isinstance(f.get("studio"), list) else f["studio"])
    row("Премьера", f.get("premiered") or f.get("firstaired"))
    row("Возраст", f.get("mpaa"))
    row("Исполнитель", f.get("artist"))
    row("Альбом", f.get("album"))
    mins = int((f.get("runtime") or f.get("duration") or 0) / 60)
    if mins:
        row("Длительность", "%d мин" % mins)
    if typ == "artist":
        row("Родился", f.get("born"))
        row("Основан", f.get("formed"))
    cast = []
    for c in (f.get("cast") or [])[:16]:
        if isinstance(c, dict) and c.get("name"):
            cast.append({"name": c["name"], "role": c.get("role") or "", "thumb": _art_url(c.get("thumbnail"))})
    poster = art.get("poster") or art.get("thumb") or f.get("thumbnail") or art.get("icon") or art.get("fanart") or ""
    return {"title": title, "year": year or "", "tagline": kodi_fmt(f.get("tagline") or ""),
            "plot": kodi_fmt(f.get("plot") or f.get("description") or "")[:4000], "rows": rows, "cast": cast,
            "poster": _art_url(poster), "fanart": _art_url(art.get("fanart")), "trailer": f.get("trailer") or "",
            "file": f.get("file") or "", "type": typ}


def _playing_item():
    pl = [x for x in ((rpc("Player.GetActivePlayers").get("result")) or [])]
    if not pl:
        raise ValueError("Ничего не играет")
    r = rpc("Player.GetItem", {"playerid": pl[0]["playerid"],
                               "properties": ["title", "file", "art", "thumbnail", "showtitle", "season", "episode",
                                              "year", "plot", "tagline", "genre", "director", "writer", "studio",
                                              "cast", "rating", "runtime", "artist", "album", "mpaa", "country"]})
    it = ((r.get("result") or {}).get("item")) or {}
    if not it:
        raise ValueError("Ничего не играет")
    return it


def _info_body(b):
    """Из тела запроса: pid (файл из браузера файлов) или playing (то, что играет сейчас) → type/id/file/title."""
    if b.get("pid"):
        t, name, _k = target_for(str(b["pid"]))
        return {"file": t, "title": os.path.splitext(name)[0], "_name": name}
    if b.get("playing"):
        it = _playing_item()
        return {"type": it.get("type") if isinstance(it.get("id"), int) and it.get("id", 0) > 0 else "",
                "id": it.get("id"), "file": it.get("file") or "", "title": it.get("title") or it.get("label") or "",
                "_item": it, "art": (it.get("art") or {}).get("poster") or it.get("thumbnail") or ""}
    return b


def item_info(body):
    """Подробная информация о фильме/сериале/треке: из библиотеки Kodi по id, иначе по данным, которые есть в списке."""
    typ, iid = str(body.get("type") or ""), body.get("id")
    spec = _INFO_GET.get(typ)
    if spec and isinstance(iid, int) and iid > 0:
        meth, key, res, props = spec
        r = rpc(meth, {key: iid, "properties": props})
        d = ((r.get("result") or {}).get(res)) if isinstance(r, dict) else None
        if d:
            out = _norm_info(d, typ)
            out["id"] = iid
            return out
    f = str(body.get("file") or "")
    if f:
        for props in (_INFO_PROPS, ["title", "plot", "art", "file"]):
            r = rpc("Files.GetFileDetails", {"file": f, "media": "video", "properties": props})
            d = (r.get("result") or {}).get("filedetails") if isinstance(r, dict) and "error" not in r else None
            if d:
                return _norm_info(d, typ)
    if body.get("_item"):
        out = _norm_info(body["_item"], typ)
        return out
    if body.get("title"):
        return {"title": body["title"], "year": "", "tagline": "", "plot": "", "rows": [["Файл", f.rsplit("/", 1)[-1]]] if f else [],
                "cast": [], "poster": "", "fanart": "", "trailer": "", "file": f, "type": typ}
    raise ValueError("Информации об этом пункте нет")


_FAV_WIN = {"video": "videos", "audio": "music", "music": "music", "image": "pictures", "pictures": "pictures"}


def fav_add(body):
    """Добавить пункт в «Избранное» Kodi: файл/видео — как «media», папка — как ссылка на окно."""
    title = kodi_fmt(str(body.get("title") or "")).strip()[:200]
    path = str(body.get("file") or "").strip()
    if not title or not path or len(path) > 4000:
        raise ValueError("нечего добавлять")
    if not path.startswith(("plugin://", "videodb://", "musicdb://", "special://", "/", "smb://", "nfs://", "ftp://",
                            "sftp://", "dav://", "davs://", "http://", "https://", "library://", "pvr://")):
        raise ValueError("недопустимый адрес")
    if "/stream/" in path and "127.0.0.1" in path:
        raise ValueError("Файлы с FTP-источников в избранное добавить нельзя — адрес временный")
    thumb = str(body.get("art") or "")[:1500]
    isdir = bool(body.get("dir"))
    r = rpc("Favourites.GetFavourites", {"properties": ["path", "windowparameter"]})
    for f in ((r.get("result") or {}).get("favourites") or []) if isinstance(r, dict) else []:
        if path in (f.get("path"), f.get("windowparameter")):
            return {"ok": True, "exists": True}
    p = {"title": title}
    if thumb:
        p["thumbnail"] = thumb
    if isdir:
        p.update(type="window", window=_FAV_WIN.get(str(body.get("media") or "video"), "videos"), windowparameter=path)
    else:
        p.update(type="media", path=path)
    r = rpc("Favourites.AddFavourite", p)
    if isinstance(r, dict) and "error" in r:
        raise RuntimeError("Kodi не добавил в избранное: %s" % ((r["error"] or {}).get("message") or "ошибка"))
    log("избранное: %s" % title[:60], ev=False)
    return {"ok": True, "exists": False}


def fav_path(pid):
    """Адрес для избранного из браузера файлов (локальный путь или внешний URL; временные адреса не годятся)."""
    target, name, _kind = target_for(pid)
    if "/stream/" in target and "127.0.0.1" in target:
        raise ValueError("Файлы с FTP-источников в избранное добавить нельзя — адрес временный")
    return {"file": target, "title": os.path.splitext(name)[0]}


def _lib_item(f, typ):
    art = f.get("art") or {}
    pic = art.get("poster") or art.get("thumb") or f.get("thumbnail") or art.get("icon") or art.get("fanart") or ""
    title = kodi_fmt(f.get("title") or f.get("label") or f.get("artist") or "")
    if isinstance(title, list):
        title = ", ".join(title)
    sub = []
    if typ == "episode" and f.get("showtitle"):
        sub.append("%s S%02dE%02d" % (f["showtitle"], f.get("season") or 0, f.get("episode") or 0))
    if typ in ("song", "album") and f.get("artist"):
        sub.append(_lst(f["artist"]))
    if typ == "song" and f.get("album"):
        sub.append(str(f["album"]))
    if f.get("year"):
        sub.append(str(f["year"]))
    if f.get("rating"):
        sub.append("★ %.1f" % float(f["rating"]))
    iid = f.get(typ + "id")
    pth = {"tvshow": "videodb://tvshows/titles/%s/", "artist": "musicdb://artists/%s/",
           "album": "musicdb://albums/%s/"}.get(typ)
    isdir = bool(pth)
    return {"label": title, "title": title, "dir": isdir, "file": (pth % iid) if pth else f.get("file", ""),
            "type": typ, "id": iid, "thumb": _art_url(pic), "thumb2": _art_proxy(pic), "art": pic,
            "fanart": _art_url(art.get("fanart")), "fanart2": _art_proxy(art.get("fanart")),
            "plot": kodi_fmt(f.get("plot") or f.get("description") or "")[:600], "sub": " · ".join(sub),
            "media": "music" if typ in ("song", "album", "artist") else "video"}


def global_search(q):
    """Как script.globalsearch: ищем по библиотеке Kodi (фильмы, сериалы, серии, клипы, артисты, альбомы, треки) и add-on'ам."""
    q = (q or "").strip()
    if len(q) < 2 or len(q) > 100:
        raise ValueError("Введите минимум 2 символа")
    flt = lambda field: {"field": field, "operator": "contains", "value": q}   # noqa: E731
    VP = ["title", "art", "file", "year", "rating", "plot"]
    spec = [("movie", "VideoLibrary.GetMovies", "movies", {"properties": VP, "filter": flt("title")}),
            ("tvshow", "VideoLibrary.GetTVShows", "tvshows", {"properties": VP, "filter": flt("title")}),
            ("episode", "VideoLibrary.GetEpisodes", "episodes",
             {"properties": VP + ["showtitle", "season", "episode"], "filter": flt("title")}),
            ("musicvideo", "VideoLibrary.GetMusicVideos", "musicvideos", {"properties": VP, "filter": flt("title")}),
            ("artist", "AudioLibrary.GetArtists", "artists", {"properties": ["art", "description"], "filter": flt("artist")}),
            ("album", "AudioLibrary.GetAlbums", "albums",
             {"properties": ["title", "art", "artist", "year", "rating"], "filter": flt("album")}),
            ("song", "AudioLibrary.GetSongs", "songs",
             {"properties": ["title", "art", "artist", "album", "file", "year"], "filter": flt("title")})]
    calls = [(m, dict(p, limits={"start": 0, "end": 30})) for _t, m, _k, p in spec]
    res = sorted([r for r in rpc_batch(calls) if isinstance(r, dict)], key=lambda r: r.get("id", 0))
    groups = []
    for (typ, _m, key, _p), r in zip(spec, res):
        its = [_lib_item(dict(f, **({"label": f.get("artist")} if typ == "artist" else {})), typ)
               for f in ((r or {}).get("result") or {}).get(key) or []]
        if its:
            groups.append({"id": typ, "items": its})
    ql = q.lower()
    try:
        ad = [a for a in addons_list()["items"] if a["kind"] != "self" and (ql in a["name"].lower())][:20]
    except Exception:  # noqa
        ad = []
    return {"q": q, "groups": groups, "addons": ad, "gs": addon_has("script.globalsearch")}


def global_search_tv(body):
    """Открыть окно script.globalsearch на ТВ с этим запросом (если add-on установлен)."""
    q = str(body.get("q") or "").strip()[:100]
    if not q:
        raise ValueError("Введите запрос")
    if not addon_has("script.globalsearch"):
        raise ValueError("На ТВ нужен add-on «Global Search» (script.globalsearch) — установите его на вкладке Add-ons")
    xbmc.executebuiltin('RunScript(script.globalsearch,searchstring=%s)' % q.replace(",", " ").replace('"', " "))
    return {"ok": True}


# ---------- IPTV: плейлисты m3u/m3u8 с каналами ----------
_iptv = collections.OrderedDict()
IPTV_MAX = 20 * 1024 * 1024


def _iptv_file():
    d = xbmcvfs.translatePath("special://profile/addon_data/%s/" % ADDON_ID)
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "iptv.json")


def _iptv_saved():
    try:
        with open(_iptv_file(), encoding="utf-8") as f:
            v = json.load(f)
        return [x for x in v if isinstance(x, dict) and x.get("url")][:30]
    except (OSError, ValueError):
        return []


def _iptv_store(lst):
    try:
        with open(_iptv_file(), "w", encoding="utf-8") as f:
            json.dump(lst[:30], f, ensure_ascii=False)
    except OSError as e:
        log("iptv: не удалось сохранить список: %s" % e, ev=False)


def iptv_saved():
    return {"items": [{"url": x["url"], "name": x.get("name") or x["url"]} for x in _iptv_saved()]}


def iptv_forget(body):
    u = str(body.get("url", ""))
    _iptv_store([x for x in _iptv_saved() if x["url"] != u])
    return {"ok": True}


def _iptv_parse(text):
    items, cur = [], None
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        if line.startswith("#EXTINF"):
            attrs = dict(re.findall(r'([\w-]+)="([^"]*)"', line))
            name = line.split(",", 1)[1].strip() if "," in line else ""
            cur = {"name": name or attrs.get("tvg-name") or "?", "logo": attrs.get("tvg-logo", ""),
                   "group": attrs.get("group-title", "")}
        elif line.startswith("#EXTGRP:") and cur is not None and not cur.get("group"):
            cur["group"] = line[8:].strip()
        elif line.startswith("#"):
            continue
        else:
            if cur is None:
                cur = {"name": urllib.parse.unquote(os.path.basename(line.split("?")[0])) or line, "logo": "", "group": ""}
            cur["url"] = line
            items.append(cur)
            cur = None
            if len(items) >= 30000:
                break
    return items


def _iptv_register(text, name, src):
    items = _iptv_parse(text)
    if not items:
        raise ValueError("В плейлисте не найдено ни одного канала (нужен формат m3u / m3u8)")
    pid = hashlib.sha1((src + str(len(items))).encode("utf-8", "replace")).hexdigest()[:10]
    _iptv[pid] = {"name": name, "items": items, "src": src}
    _iptv.move_to_end(pid)
    while len(_iptv) > 6:
        _iptv.popitem(last=False)
    return pid, items


def _iptv_summary(pid, items, name):
    g = collections.Counter(i["group"] for i in items)
    return {"id": pid, "name": name, "count": len(items),
            "groups": [{"name": k, "n": v} for k, v in sorted(g.items(), key=lambda kv: kv[0].lower())]}


def iptv_load(body):
    u = str(body.get("url", "")).strip()
    if not re.match(r"^https?://", u, re.I):
        raise ValueError("Нужна ссылка на плейлист вида http(s)://…")
    req = urllib.request.Request(u, headers={"User-Agent": "Kodi/21 (CoreELEC) PhoneRemote"})
    try:
        with urllib.request.urlopen(req, timeout=25) as r:
            data = r.read(IPTV_MAX + 1)
    except (urllib.error.URLError, OSError, ValueError) as e:
        raise RuntimeError("Не удалось скачать плейлист: %s" % e)
    if len(data) > IPTV_MAX:
        raise ValueError("Плейлист больше 20 МБ")
    name = urllib.parse.unquote(os.path.basename(urllib.parse.urlparse(u).path)) or urllib.parse.urlparse(u).netloc
    pid, items = _iptv_register(data.decode("utf-8", "replace"), name, u)
    saved = [x for x in _iptv_saved() if x["url"] != u]
    saved.insert(0, {"url": u, "name": name})
    _iptv_store(saved)
    log("IPTV: загружен %s (%d каналов)" % (name, len(items)), ev=False)
    return _iptv_summary(pid, items, name)


def iptv_upload(rfile, n, name):
    if n <= 0 or n > IPTV_MAX:
        raise ValueError("файл пустой или больше 20 МБ")
    data = _Body(rfile, n).read(n)
    name = os.path.basename(name or "playlist.m3u")
    pid, items = _iptv_register(data.decode("utf-8", "replace"), name, "file:" + name + str(n))
    return _iptv_summary(pid, items, name)


def _iptv_filter(pid, group, q):
    pl = _iptv.get(pid)
    if not pl:
        raise ValueError("Плейлист устарел — откройте его заново")
    ql = [w for w in (q or "").lower().split() if w]
    out = []
    for i, it in enumerate(pl["items"]):
        if group and it["group"] != group:
            continue
        if ql and not all(w in (it["name"] + " " + it["group"]).lower() for w in ql):
            continue
        out.append((i, it))
    return pl, out


def iptv_list(pid, group, q, start):
    pl, out = _iptv_filter(pid, group, q)
    start = max(0, int(start or 0))
    page = out[start:start + 150]
    return {"items": [{"i": i, "name": it["name"], "logo": it["logo"], "group": it["group"]} for i, it in page],
            "total": len(out), "more": start + 150 < len(out)}


def iptv_play(body):
    pl, out = _iptv_filter(str(body.get("id", "")), str(body.get("group", "")), str(body.get("q", "")))
    idx = int(body.get("index", -1))
    pos = next((n for n, (i, _) in enumerate(out) if i == idx), -1)
    if pos < 0:
        raise ValueError("канал не найден")
    url = out[pos][1]["url"]
    if len(out) <= 500 and len(out) > 1:
        # весь отфильтрованный список — в очередь, чтобы переключать каналы кнопками «вперёд/назад»
        rpc("Playlist.Clear", {"playlistid": 1})
        rpc_batch([("Playlist.Add", {"playlistid": 1, "item": {"file": it["url"]}}) for _, it in out])
        rpc("Player.Open", {"item": {"playlistid": 1, "position": pos}})
    else:
        rpc("Player.Open", {"item": {"file": url}})
    return {"ok": True, "name": out[pos][1]["name"]}



# ---------- «Продолжить просмотр», «Недавно смотрел», избранное, обслуживание медиатеки ----------
_RES_PROPS = ["title", "art", "plot", "year", "rating", "runtime", "file", "resume", "lastplayed", "playcount",
              "showtitle", "season", "episode"]


def _by_id(rr):
    return {x.get("id"): x for x in rr} if isinstance(rr, list) else {}


def _res_item(f, typ):
    it = _lib_item(f, typ)
    res = f.get("resume") or {}
    pos, tot = int(res.get("position") or 0), int(res.get("total") or 0)
    it["resume"] = {"pos": pos, "total": tot} if pos > 0 else None
    it["lastplayed"] = f.get("lastplayed") or ""
    return it


def continue_lists():
    srt = {"method": "lastplayed", "order": "descending"}
    lim = {"start": 0, "end": 30}
    calls = [("VideoLibrary.GetMovies", {"properties": _RES_PROPS, "sort": srt, "limits": lim,
                                         "filter": {"field": "inprogress", "operator": "true", "value": ""}}),
             ("VideoLibrary.GetEpisodes", {"properties": _RES_PROPS, "sort": srt, "limits": lim,
                                           "filter": {"field": "inprogress", "operator": "true", "value": ""}}),
             ("VideoLibrary.GetMovies", {"properties": _RES_PROPS, "sort": srt, "limits": lim,
                                         "filter": {"field": "playcount", "operator": "greaterthan", "value": "0"}}),
             ("VideoLibrary.GetEpisodes", {"properties": _RES_PROPS, "sort": srt, "limits": lim,
                                           "filter": {"field": "playcount", "operator": "greaterthan", "value": "0"}})]
    by = _by_id(rpc_batch(calls))

    def part(i, key, typ):
        return [_res_item(f, typ) for f in ((by.get(i) or {}).get("result") or {}).get(key, []) or []]

    prog = part(1, "movies", "movie") + part(2, "episodes", "episode")
    rec = part(3, "movies", "movie") + part(4, "episodes", "episode")
    prog.sort(key=lambda x: x["lastplayed"], reverse=True)
    rec.sort(key=lambda x: x["lastplayed"], reverse=True)
    return {"progress": prog[:30], "recent": rec[:40]}


def resume_play(body):
    typ = {"movie": "movieid", "episode": "episodeid", "musicvideo": "musicvideoid"}.get(str(body.get("type") or ""))
    iid = body.get("id")
    if not typ or not isinstance(iid, int) or iid <= 0:
        raise ValueError("нет данных для запуска")
    r = rpc("Player.Open", {"item": {typ: iid}, "options": {"resume": bool(body.get("resume"))}})
    if "error" in r:
        raise RuntimeError("Kodi не запустил: %s" % ((r["error"] or {}).get("message") or "ошибка"))
    return {"ok": True}


def _fav_list_raw():
    r = rpc("Favourites.GetFavourites", {"properties": ["window", "windowparameter", "thumbnail", "path"]})
    if "error" in r:
        raise RuntimeError("Kodi: %s" % ((r["error"] or {}).get("message") or "избранное недоступно"))
    return (r.get("result") or {}).get("favourites") or []


def fav_list():
    out = []
    for i, f in enumerate(_fav_list_raw()):
        typ = f.get("type") or ""
        thumb = f.get("thumbnail") or ""
        it = {"i": i, "label": kodi_fmt(f.get("title") or ""), "title": kodi_fmt(f.get("title") or ""), "ftype": typ,
              "thumb": _art_url(thumb), "thumb2": _art_proxy(thumb), "art": thumb, "file": "", "dir": False,
              "kind": "video"}
        if typ == "media":
            it["file"] = f.get("path") or ""
            pth = it["file"].lower()
            it["kind"] = "audio" if pth.endswith((".mp3", ".flac", ".m4a", ".ogg", ".wav", ".aac", ".opus", ".ape")) \
                or pth.startswith("musicdb://") else "video"
        elif typ == "window" and f.get("windowparameter"):
            it["file"] = f["windowparameter"]
            it["dir"] = True
            it["kind"] = {"music": "audio", "pictures": "image"}.get(f.get("window") or "", "video")
        out.append(it)
    return {"items": out}


def fav_remove(body):
    """В Kodi у JSON-RPC нет отдельного «удалить»: повторный AddFavourite с теми же данными убирает пункт из избранного."""
    idx = body.get("i")
    favs = _fav_list_raw()
    if not isinstance(idx, int) or not (0 <= idx < len(favs)):
        raise ValueError("пункт не найден")
    f = favs[idx]
    p = {"title": f.get("title") or "", "type": f.get("type") or "media"}
    if f.get("type") == "window":
        p.update(window=f.get("window") or "videos", windowparameter=f.get("windowparameter") or "")
    elif f.get("type") == "media":
        p["path"] = f.get("path") or ""
    else:
        raise ValueError("Этот пункт избранного можно убрать только на ТВ (контекстное меню → Убрать из избранного)")
    if f.get("thumbnail"):
        p["thumbnail"] = f["thumbnail"]
    rpc("Favourites.AddFavourite", p)
    still = [x for x in _fav_list_raw() if x.get("title") == f.get("title") and (x.get("path") or "") == (f.get("path") or "")
             and (x.get("windowparameter") or "") == (f.get("windowparameter") or "")]
    if still:
        raise ValueError("Kodi не убрал пункт — удалите его на ТВ (контекстное меню → Убрать из избранного)")
    log("избранное убрано: %s" % (f.get("title") or "")[:60], ev=False)
    return {"ok": True}


PHIST_MAX = 200
_ph_lock = threading.Lock()
_ph = {"pending": None, "last": "", "src": {}}
_ELE_STREAM = re.compile(r"^https?://(?:127\.0\.0\.1|localhost):\d+/", re.I)


def _phist_tdir():
    d = os.path.join(data_dir(), "torrents")
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        pass
    return d + os.sep


def _phist_pending(kind, value):
    """Запоминаем источник, с которого пользователь запустил торрент: сам поток Elementum — временный адрес на localhost."""
    if kind == "torrent" and value.startswith(TORRENT_DIR()) and os.path.isfile(value):
        try:
            dst = os.path.join(_phist_tdir(), "%d-%s" % (int(time.time()), os.path.basename(value)))
            shutil.copyfile(value, dst)
            value = dst
        except OSError:
            pass
    _ph["pending"] = {"kind": kind, "value": value, "ts": time.time()}


def _phist_file():
    return os.path.join(data_dir(), "playhist.json")


def phist_load():
    try:
        with open(_phist_file(), encoding="utf-8") as f:
            v = json.load(f)
        return v if isinstance(v, list) else []
    except (OSError, ValueError):
        return []


def phist_save(lst):
    try:
        with open(_phist_file(), "w", encoding="utf-8") as f:
            json.dump(lst[:PHIST_MAX], f, ensure_ascii=False)
    except OSError as e:
        log("playhist: не удалось сохранить: %s" % e, ev=False)


_GENERIC_TITLES = {"", "play", "playuri", "stream", "unknown", "none", "video", "movie", "file", "default", "torrent"}
_ph_names = {}


def _generic_title(t):
    t = (t or "").strip().lower()
    return t in _GENERIC_TITLES or bool(re.fullmatch(r"[\d.\s-]+", t))


def _bdecode(b, i=0, depth=0):
    """Минимальный разбор bencode (для имени из .torrent)."""
    if depth > 12:
        raise ValueError("deep")
    c = b[i:i + 1]
    if c == b"i":
        j = b.index(b"e", i)
        return int(b[i + 1:j]), j + 1
    if c == b"l":
        i += 1
        out = []
        while b[i:i + 1] != b"e":
            v, i = _bdecode(b, i, depth + 1)
            out.append(v)
        return out, i + 1
    if c == b"d":
        i += 1
        out = {}
        while b[i:i + 1] != b"e":
            k, i = _bdecode(b, i, depth + 1)
            v, i = _bdecode(b, i, depth + 1)
            out[k] = v
        return out, i + 1
    j = b.index(b":", i)
    n = int(b[i:j])
    return b[j + 1:j + 1 + n], j + 1 + n


def _dec_name(raw):
    for enc in ("utf-8", "cp1251"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "replace")


def _src_name(src):
    """Название раздачи: dn= из magnet-ссылки или имя внутри .torrent-файла (имя самого файла-раздачи)."""
    k, v = (src or {}).get("kind"), (src or {}).get("value") or ""
    if not v:
        return ""
    ck = "%s:%s" % (k, v)
    if ck in _ph_names:
        return _ph_names[ck]
    name = ""
    try:
        if k == "magnet" or v.startswith("magnet:"):
            dn = urllib.parse.parse_qs(urllib.parse.urlparse(v).query).get("dn")
            name = dn[0] if dn else ""
        elif k == "torrent" and os.path.isfile(v) and os.path.getsize(v) < 8 * 1024 * 1024:
            with open(v, "rb") as fh:
                d, _ = _bdecode(fh.read())
            info = d.get(b"info") or {}
            raw = info.get(b"name.utf-8") or info.get(b"name") or b""
            name = _dec_name(raw)
        elif k == "url":
            name = urllib.parse.unquote(os.path.basename(urllib.parse.urlparse(v).path))
    except Exception as e:  # noqa
        log("playhist: имя раздачи: %r" % e, ev=False)
    name = kodi_fmt(name).strip()
    _ph_names[ck] = name
    if len(_ph_names) > 100:
        _ph_names.pop(next(iter(_ph_names)))
    return name


def _kodi_title():
    for lab in ("VideoPlayer.Title", "Player.Title", "VideoPlayer.OriginalTitle", "Player.Filename"):
        try:
            t = kodi_fmt(xbmc.getInfoLabel(lab) or "").strip()
        except Exception:  # noqa
            t = ""
        if t and not _generic_title(t) and not t.lower().endswith("/play"):
            return t
    return ""


def _phist_title(it, f):
    t = it.get("title") or it.get("label") or ""
    if it.get("showtitle"):
        t = "%s S%02dE%02d%s" % (it["showtitle"], it.get("season") or 0, it.get("episode") or 0, " — " + t if t else "")
    if not t or _generic_title(t):
        t = urllib.parse.unquote(os.path.basename(f.split("?")[0].rstrip("/"))) or f[:80]
    return kodi_fmt(t)


def phist_tick():
    act = _active()
    if not act or act[0].get("type") != "video":
        return
    pid = act[0]["playerid"]
    r = rpc("Player.GetItem", {"playerid": pid, "properties": ["title", "file", "art", "thumbnail", "showtitle", "season",
                                                                 "episode", "year"]})
    it = ((r.get("result") or {}).get("item")) or {}
    f = it.get("file") or ""
    if not f:
        return
    pr = rpc("Player.GetProperties", {"playerid": pid, "properties": ["time", "totaltime"]}).get("result", {})
    pos, total = to_sec(pr.get("time")), to_sec(pr.get("totaltime"))
    if total <= 0:
        return
    iid = it.get("id")
    if it.get("type") in ("movie", "episode", "musicvideo") and isinstance(iid, int) and iid > 0:
        src = {"kind": "library", "type": it["type"], "value": iid}
        key = "lib:%s:%d" % (it["type"], iid)
    elif f in META and META[f].get("id"):
        src = {"kind": "pid", "value": META[f]["id"]}
        key = "pid:" + META[f]["id"]
    else:
        src = _ph["src"].get(f)
        pend = _ph.get("pending")
        if not src and pend and time.time() - pend["ts"] < 300:
            src = {"kind": pend["kind"], "value": pend["value"]}
            _ph["pending"] = None
        if not src:
            kind = "plugin" if f.startswith("plugin://") else ("temp" if _ELE_STREAM.match(f) else
                                                               ("url" if re.match(r"^[a-z]+://", f, re.I) else "file"))
            src = {"kind": kind, "value": f}
        _ph["src"][f] = src
        if len(_ph["src"]) > 50:
            _ph["src"].pop(next(iter(_ph["src"])))
        key = "%s:%s" % (src["kind"], src["value"])
    art = it.get("art") or {}
    pic = art.get("poster") or art.get("thumb") or it.get("thumbnail") or art.get("fanart") or ""
    fin = pos >= total * 0.92 or total - pos < 60
    with _ph_lock:
        lst = phist_load()
        old = next((e for e in lst if e.get("key") == key), None)
        title = _phist_title(it, f)
        if _generic_title(title) or _ELE_STREAM.match(f) and _generic_title(it.get("title") or it.get("label")):
            better = _kodi_title() or _src_name(src)
            if better:
                title = better
        e = {"key": key, "src": src, "file": f if src["kind"] != "pid" else "", "title": title,
             "art": pic if len(pic) < 800 else "", "pos": int(pos), "total": int(total), "ts": time.time(),
             "finished": bool(fin), "year": it.get("year") or 0}
        if old and old.get("title") and _generic_title(e["title"]) and not _generic_title(old["title"]):
            e["title"] = old["title"]
        _ph["last"] = key
        lst = [x for x in lst if x.get("key") != key]
        lst.insert(0, e)
        phist_save(lst)


def phist_list():
    out = []
    labels = {"library": "📚 библиотека", "pid": "📁 файл", "file": "📁 файл", "url": "🔗 ссылка", "magnet": "🧲 magnet",
              "torrent": "🧲 .torrent", "plugin": "🧩 add-on", "temp": "⚠ временный адрес"}
    with _ph_lock:
        lst = phist_load()
    for e in lst:
        k = (e.get("src") or {}).get("kind", "")
        pic = e.get("art") or ""
        out.append({"key": e["key"], "title": e.get("title") or "", "kind": k, "kindlabel": labels.get(k, k),
                    "pos": e.get("pos", 0), "total": e.get("total", 0), "ts": e.get("ts", 0),
                    "finished": bool(e.get("finished")), "thumb": _art_url(pic), "thumb2": _art_proxy(pic),
                    "year": e.get("year") or "", "temp": k == "temp"})
    return {"items": out}


def phist_remove(body):
    key = str(body.get("key", ""))
    with _ph_lock:
        phist_save([e for e in phist_load() if e.get("key") != key] if key else [])
    return {"ok": True}


def _seek_when_new(sec, before, timeout=400):
    """Дождаться, пока начнётся новое видео (у торрентов — после буферизации), и перемотать на сохранённое место."""
    for _ in range(timeout):
        time.sleep(1)
        act = _active()
        if not act:
            continue
        pid = act[0]["playerid"]
        f = (rpc("Player.GetItem", {"playerid": pid}).get("result") or {}).get("item", {}).get("file")
        if f and f == before:
            continue
        pr = rpc("Player.GetProperties", {"playerid": pid, "properties": ["time", "totaltime"]}).get("result", {})
        if to_sec(pr.get("totaltime")) > 0:
            if to_sec(pr.get("time")) < sec - 15:
                rpc("Player.Seek", {"playerid": pid, "value": {"time": from_sec(sec)}})
            return


def _tmdbh_play_url(f):
    """Ссылки TMDb Helper из списков бывают «информационными» (info=details/seasons…): Kodi открывает их как папку
    (окно «Cast in Movies») и ничего не играет. Для истории превращаем их в ссылку на воспроизведение."""
    try:
        u = urllib.parse.urlparse(f)
        if u.netloc != "plugin.video.themoviedb.helper":
            return f
        q = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}
        if q.get("info") == "play" or not q.get("tmdb_id"):
            return f
        typ = q.get("tmdb_type") or ""
        if typ == "movie":
            keep = {"info": "play", "tmdb_type": "movie", "tmdb_id": q["tmdb_id"]}
        elif typ in ("tv", "episode") and q.get("season") and q.get("episode"):
            keep = {"info": "play", "tmdb_type": "episode", "tmdb_id": q["tmdb_id"], "season": q["season"],
                    "episode": q["episode"]}
        else:
            return f
        return "plugin://plugin.video.themoviedb.helper/?" + urllib.parse.urlencode(keep)
    except Exception:  # noqa
        return f


def phist_play(body):
    key = str(body.get("key", ""))
    with _ph_lock:
        e = next((x for x in phist_load() if x.get("key") == key), None)
    if not e:
        raise ValueError("запись не найдена")
    src = e.get("src") or {}
    k, v = src.get("kind"), src.get("value")
    sec = max(0, int(e.get("pos", 0)) - 5) if body.get("resume") and not e.get("finished") else 0
    act = _active()
    before = ""
    if act:
        before = (rpc("Player.GetItem", {"playerid": act[0]["playerid"]}).get("result") or {}).get("item", {}).get("file") or ""
    if k == "library":
        typ = {"movie": "movieid", "episode": "episodeid", "musicvideo": "musicvideoid"}.get(src.get("type"))
        r = rpc("Player.Open", {"item": {typ: int(v)}, "options": {"resume": bool(sec)}})
        if "error" in r:
            raise RuntimeError("Kodi не запустил: %s" % ((r["error"] or {}).get("message") or "ошибка"))
        return {"ok": True}
    if k == "pid":
        api_play({"path": v, "resume": bool(sec)})
        return {"ok": True}
    if k in ("magnet", "torrent"):
        if k == "torrent" and not os.path.isfile(v):
            raise ValueError("Файл .torrent больше не найден")
        elementum_add(v, True)
        if sec:
            threading.Thread(target=_seek_when_new, args=(sec, before), daemon=True).start()
        return {"ok": True, "slow": True}
    if k == "temp":
        raise ValueError("Это был временный адрес потока (торрент запущен не из Phone Remote) — запустите торрент заново")
    if k in ("file", "url", "plugin"):
        if k == "file" and not os.path.exists(v):
            raise ValueError("Файл больше не существует")
        if k == "plugin" or v.startswith("plugin://"):
            v2 = _tmdbh_play_url(v)
            xbmc.executebuiltin('PlayMedia("%s")' % v2.replace('"', "%22"))
            log("история: PlayMedia %s" % v2[:120], ev=False)
        else:
            rpc("Player.Open", {"item": {"file": v}})
        if sec:
            threading.Thread(target=_seek_when_new, args=(sec, before), daemon=True).start()
        return {"ok": True}
    raise ValueError("неизвестный источник")


def play_url(body):
    """Воспроизвести ссылку на ТВ: прямая ссылка на видео/аудио/поток, YouTube, magnet и .torrent."""
    u = str(body.get("url", "")).strip()
    if not u or len(u) > 8000 or "\n" in u:
        raise ValueError("Вставьте ссылку")
    low = u.lower()
    if low.startswith("magnet:?") or (low.startswith(("http://", "https://")) and
                                        urllib.parse.urlparse(u).path.lower().endswith(".torrent")):
        elementum_add(u, True)
        return {"ok": True, "via": "Elementum"}
    if re.match(r"^(?:https?://)?(?:www\.|m\.|music\.)?(?:youtube(?:-nocookie)?\.com|youtu\.be)\b", u, re.I):
        qs = urllib.parse.parse_qs(urllib.parse.urlparse(u if "://" in u else "https://" + u).query)
        path = urllib.parse.urlparse(u if "://" in u else "https://" + u).path
        vid = (qs.get("v") or [""])[0]
        if not vid:
            mm = re.match(r"^/(?:shorts|embed|live|v)/([\w-]{6,})", path) or (
                re.match(r"^/([\w-]{6,})$", path) if "youtu.be" in u.lower() else None)
            vid = mm.group(1) if mm else ""
        pl = (qs.get("list") or [""])[0]
        if not addon_has("plugin.video.youtube"):
            raise ValueError("Для ссылок YouTube нужен add-on YouTube (plugin.video.youtube) — установите его на вкладке Add-ons")
        if vid:
            f = "plugin://plugin.video.youtube/play/?video_id=%s" % urllib.parse.quote(vid)
        elif pl:
            f = "plugin://plugin.video.youtube/play/?playlist_id=%s&order=default" % urllib.parse.quote(pl)
        else:
            raise ValueError("Не удалось найти видео в ссылке YouTube")
        _phist_pending("plugin", f)
        rpc("Player.Open", {"item": {"file": f}})
        return {"ok": True, "via": "YouTube"}
    if not re.match(r"^(https?|rtmps?|rtsp|udp|rtp|mms|ftp|sftp|smb|nfs|dav|davs)://", low):
        raise ValueError("Нужна ссылка вида http(s)://… (или magnet, YouTube)")
    _phist_pending("url", u)
    rpc("Player.Open", {"item": {"file": u}})
    log("играть ссылку: %s" % mask_url(u)[:100], ev=False)
    return {"ok": True, "via": "Kodi"}


def addon_launch(body):
    aid = str(body.get("id", ""))
    if not re.match(r"^[A-Za-z0-9._\-]+$", aid):
        raise ValueError("недопустимый id")
    if body.get("kind") == "program":
        xbmc.executebuiltin('RunAddon(%s)' % aid)
    else:
        win = {"audio": "Music", "image": "Pictures"}.get(body.get("kind"), "Videos")
        xbmc.executebuiltin('ActivateWindow(%s,"plugin://%s/",return)' % (win, aid))
    return {"ok": True}


def addon_play(body):
    f = str(body.get("file", ""))
    if not f.startswith(("plugin://", "http://", "https://", "special://", "videodb://", "musicdb://", "pvr://", "/",
                        "smb://", "nfs://", "ftp://", "sftp://", "dav://", "davs://", "library://")) \
            and not is_url(f):
        raise ValueError("недопустимый адрес")
    if f.startswith("plugin://") and not (isinstance(body.get("id"), int) and body["id"] > 0):
        _phist_pending("plugin", _tmdbh_play_url(f))
    songs = [int(x) for x in (body.get("songs") or [])[:500] if str(x).lstrip("-").isdigit()]
    kind = {"song": "songid", "movie": "movieid", "episode": "episodeid", "musicvideo": "musicvideoid"}.get(
        str(body.get("type") or ""))
    if songs and str(body.get("pos", "")).isdigit() and int(body["pos"]) < len(songs):
        # песня из списка альбома: кладём весь список в очередь и начинаем с нужной (иначе Kodi играет «файл» целиком,
        # а у альбомов из одного flac+cue это всегда первая дорожка)
        rpc("Playlist.Clear", {"playlistid": 0})
        rpc_batch([("Playlist.Add", {"playlistid": 0, "item": {"songid": i}}) for i in songs])
        rpc("Player.Open", {"item": {"playlistid": 0, "position": int(body["pos"])}})
        return {"ok": True}
    if kind and isinstance(body.get("id"), int) and body["id"] > 0:
        rpc("Player.Open", {"item": {kind: body["id"]}})
        return {"ok": True}
    if f.startswith("plugin://plugin.audio."):      # радио и другая музыка из add-on'ов
        _plugin_switch_play(f)
        return {"ok": True}
    if f.startswith("plugin://"):
        _retry_state.update(f=f, t=time.time(), n=0)
    rpc("Player.Open", {"item": {"file": f}})
    return {"ok": True}


_retry_state = {"f": "", "t": 0, "n": 0}


class _RetryPlayer(xbmc.Player):
    """Торрент через Elementum иногда падает «One or more items failed to play»: другие add-on'ы (например,
    service.dvblacklevel) перезапускают воспроизведение сразу после старта, Elementum снимает раздачу и отдаёт 500.
    Если запуск, сделанный с веб-страницы, не удался в первую минуту — один раз повторяем (как делает пользователь)."""

    def onPlayBackError(self):
        st = _retry_state
        if not st["f"] or st["n"] >= 1 or time.time() - st["t"] > 90:
            return
        st["n"] += 1
        f = st["f"]
        log("play: запуск не удался, повторяю один раз: %s" % f[:100])

        def again():
            time.sleep(3)
            xbmc.executebuiltin("Dialog.Close(okdialog,true)")
            time.sleep(0.5)
            rpc("Player.Open", {"item": {"file": f}})
        threading.Thread(target=again, daemon=True).start()


def _active_players():
    try:
        return rpc("Player.GetActivePlayers").get("result", []) or []
    except Exception:  # noqa
        return []


def _plugin_switch_play(f):
    """Смена потока add-on'а (например, радио) во время воспроизведения.
    Раньше Kodi сам останавливал старый поток, а новый иногда не стартовал (плагин ещё «держал» прежний) — приходилось
    нажимать второй раз. Теперь: останавливаем текущее, ждём полной остановки, запускаем новое и, если за 12 с
    ничего не заиграло, повторяем один раз."""
    if _active_players():
        log("play: останавливаю текущее воспроизведение перед %s" % f[:90], ev=False)
        try:
            rpc("Player.Stop", {"playerid": _active_players()[0]["playerid"]})
        except Exception:  # noqa
            pass
        for _ in range(30):
            if not _active_players():
                break
            time.sleep(0.1)
        time.sleep(0.6)       # дать плагину и аудио-движку закрыть прежний поток
    rpc("Player.Open", {"item": {"file": f}})

    def verify():
        end = time.time() + 12
        while time.time() < end:
            time.sleep(0.5)
            if _active_players():
                return
        log("play: ничего не заиграло за 12 с — повторный запуск %s" % f[:90], ev=False)
        try:
            rpc("Player.Open", {"item": {"file": f}})
        except Exception as e:  # noqa
            log("play: повтор не удался: %r" % e, ev=False)
    threading.Thread(target=verify, daemon=True).start()


# ---------- диагностика ошибок торрента ----------
def _mount_ro(path):
    best, ro = "", False
    try:
        with open("/proc/mounts") as f:
            for ln in f:
                p = ln.split()
                if len(p) >= 4 and (path == p[1] or path.startswith(p[1].rstrip("/") + "/")) and len(p[1]) >= len(best):
                    best, ro = p[1], "ro" in p[3].split(",")
    except OSError:
        pass
    return ro


def torrent_diag(t):
    """Почему торрент в состоянии error/missingFiles: нет места, накопитель отключён или смонтирован «только чтение»."""
    sp = t.get("save_path") or ""
    notes = []
    if sp and not os.path.isdir(sp):
        notes.append("Папка загрузки недоступна: %s. Накопитель отключился или не смонтирован." % sp)
    elif sp:
        try:
            free = shutil.disk_usage(sp).free
            left = int(t.get("amount_left") or 0)
            if left and free < left + 50 * MB:
                notes.append("Не хватает места: осталось докачать %s, свободно %s." % (fmtsize(left), fmtsize(free)))
        except OSError:
            pass
        if _mount_ro(os.path.realpath(sp)):
            notes.append("Накопитель смонтирован «только для чтения» — обычно после ошибок файловой системы или "
                         "сбоя карты. Перезагрузите приставку, при необходимости проверьте карту (fsck).")
        else:
            try:
                tf = os.path.join(sp, ".pr_write_test")
                with open(tf, "w") as fh:
                    fh.write("x")
                os.remove(tf)
            except OSError as e:
                notes.append("Запись в папку загрузки не удаётся: %s." % e.strerror)
    if not notes:
        notes.append("qBittorrent остановил торрент из-за ошибки ввода-вывода. Если используется microSD, "
                     "проверьте карту (dmesg | grep -iE 'mmc|ext4|I/O error').")
    return " ".join(notes)


def pid_for_path(p):
    """id папки/файла в браузере файлов для абсолютного пути (чтобы открыть загруженное из вкладки «Торренты»)."""
    if not p:
        return ""
    try:
        rp = os.path.realpath(p)
        best = None
        for i, r in enumerate(roots()):
            if is_url(r):
                continue
            base = os.path.realpath(r)
            if rp == base or rp.startswith(base + os.sep):
                if best is None or len(base) > len(best[1]):
                    best = (i, base)
        if best:
            rel = rp[len(best[1]):].strip(os.sep)
            return "%d:%s" % (best[0], "/".join(x for x in rel.split(os.sep) if x))
    except Exception:  # noqa
        pass
    return ""


# ---------- player ----------
def active_player():
    r = rpc("Player.GetActivePlayers").get("result") or []
    return r[0]["playerid"] if r else None


def _item_name(it):
    """У потоков Elementum Kodi отдаёт заголовок «play» — тогда берём настоящее имя (плеер / раздача / адрес)."""
    t = it.get("title") or it.get("label") or ""
    if t and not _generic_title(t) and not t.lower().endswith("/play"):
        return t
    n = _kodi_title()
    if n:
        return n
    f = it.get("file") or ""
    src = _ph["src"].get(f) or _ph.get("pending") or {}
    n = _src_name(src) if src else ""
    if n:
        return n
    n = urllib.parse.unquote(os.path.basename(f.split("?")[0].rstrip("/")))
    return n if n and not _generic_title(n) else (t or "Видео")


def status():
    app = rpc("Application.GetProperties", {"properties": ["volume", "muted"]}).get("result", {})
    out = {"playing": False, "volume": app.get("volume", 0), "muted": app.get("muted", False),
           "yn": bool(_yn_kind()),
           "keyboard": bool(xbmc.getCondVisibility("Window.IsActive(virtualkeyboard) | Window.IsActive(numericinput)")),
           "dialog": bool(_dlg_active()), "insert": _ele_kind() == "insert"}
    pid = active_player()
    if pid is None:
        return out
    pr = rpc("Player.GetProperties", {"playerid": pid,
             "properties": ["time", "totaltime", "percentage", "speed"]}).get("result", {})
    it = rpc("Player.GetItem", {"playerid": pid, "properties": ["title", "file"]}).get("result", {}).get("item", {})
    name = _item_name(it)
    out.update({"playing": True, "paused": pr.get("speed", 1) == 0, "title": name,
                "time": to_sec(pr.get("time")), "total": to_sec(pr.get("totaltime")),
                "percentage": pr.get("percentage", 0),
                "thumb": "/api/thumb?now=1&k=" + hashlib.md5(it.get("file", "").encode("utf-8", "replace")).hexdigest()[:12]})
    if xbmc.getCondVisibility("Player.HasVideo"):
        g = xbmc.getInfoLabel
        hdr = {"dolbyvision": "Dolby Vision", "hdr10": "HDR10", "hdr10plus": "HDR10+", "hlg": "HLG"}.get(
            g("VideoPlayer.HdrType").lower().replace(" ", ""), g("VideoPlayer.HdrType") or "SDR")
        parts = [g("VideoPlayer.VideoResolution"), g("VideoPlayer.VideoCodec").upper(), hdr,
                 (g("VideoPlayer.AudioCodec").upper() + " " + g("VideoPlayer.AudioChannels")).strip()]
        out["media"] = " · ".join(p for p in parts if p)
    return out


# ---------- диалог выбора на ТВ (например, «доступные потоки» другого add-on'а) ----------
# Не считаем «выбором» эти окна: клавиатура/ввод цифр, индикаторы, уведомления.
_DLG_SKIP = "Window.IsActive(virtualkeyboard) | Window.IsActive(numericinput) | Window.IsActive(busydialog) | " \
            "Window.IsActive(busydialognocancel) | Window.IsActive(volumebar) | Window.IsActive(notification)"


def _num(label):
    try:
        return int(xbmc.getInfoLabel(label) or 0)
    except ValueError:
        return 0


_dlg_seen = [None]
_py_probe = {}


def _did():
    """id открытого сейчас диалога (0, если диалога нет)."""
    try:
        d = xbmcgui.getCurrentWindowDialogId()
    except Exception:
        return 0
    return d if d and d != 9999 else 0


def _py_list():
    """Список окна Elementum через Python-API (не зависит от infolabel'ов): (число пунктов, заголовок, пункты)."""
    return 0, "", []
    d = _did()
    if not d:
        return 0, "", []
    # у каждого диалога пробуем не дольше 6 с (иначе Kodi спамит «Non-Existent Control» в лог)
    st = _py_probe.get(d)
    if st is None or time.time() - st[0] > 600:
        st = _py_probe[d] = [time.time(), False]
    if not st[1] and time.time() - st[0] > 6:
        return 0, "", []
    try:
        w = xbmcgui.Window(d)
        c = w.getControl(32503)
        n = c.size()
        if n <= 0:
            return 0, "", []
        st[1] = True
        try:
            title = w.getControl(32501).getLabel()
        except Exception:
            title = ""
        items = []
        for i in range(min(n, 300)):
            li = c.getListItem(i)
            items.append((li.getLabel(), li.getLabel2(), li.getProperty("description") or li.getProperty("info") or ""))
        return n, title, items
    except Exception:
        return 0, "", []


def _ele_kind():
    """Свои окна Elementum (Python-окна WindowXMLDialog с фиксированными id):
    «select» — «Available streams» (DialogSelectLarge: заголовок 32501, список 32503),
    «insert» — «Insert file or URL» (DialogInsert: кнопки 32505/32507, OK 32508).
    В Kodi 22 такое окно не считается «модальным» (HasModalDialog=False), но getCurrentWindowDialogId его видит."""
    if not (xbmc.getCondVisibility("System.HasModalDialog") or _did()):
        return ""
    g = xbmc.getInfoLabel
    if _num("Container(32503).NumItems") > 0:
        return "select"
    if g("Control.GetLabel(32508)") and g("Control.GetLabel(32501)") and g("Control.GetLabel(32502)"):
        return "insert"
    return ""


def _dlg_active():
    """Открыт ли на ТВ диалог выбора: стандартный selectdialog, окно потоков Elementum или модальное окно
    add-on'а со списком, в котором фокус стоит на списке."""
    if xbmc.getCondVisibility("Window.IsActive(selectdialog) | Window.IsActive(contextmenu)"):
        return True
    if xbmc.getCondVisibility(_DLG_SKIP):
        return False
    if _ele_kind() == "select":
        return True
    if not xbmc.getCondVisibility("System.HasModalDialog"):
        return False
    return _dlg_list()[1] > 0


_LIST_IDS = [32503, 996, 3, 5, 6, 7, 8, 9, 10, 11, 50, 51, 52, 55, 60, 100, 101, 102, 110, 111, 120, 200, 300, 500, 501,
             502, 1000, 1001, 1002, 1003, 1010, 2000, 2001, 3000, 5000, 9000, 9001]


def _dlg_list():
    """(id списка, число пунктов): окно Elementum, затем список в фокусе, затем перебор типичных id."""
    if _num("Container(32503).NumItems") > 0 and (xbmc.getInfoLabel("Control.GetLabel(32501)") or _did()):
        return 32503, _num("Container(32503).NumItems")
    cur = xbmc.getInfoLabel("System.CurrentControlID")
    seen = []
    for c in ([int(cur)] if cur.isdigit() else []) + _LIST_IDS:
        if c in seen:
            continue
        seen.append(c)
        n = _num("Container(%d).NumItems" % c)
        if n > 0:
            return c, n
    return (int(cur) if cur.isdigit() else 3), 0


def dialog_debug():
    """Для диагностики: что Kodi сейчас показывает на ТВ (открыть в браузере, пока окно на экране)."""
    g = xbmc.getInfoLabel
    cid, n = _dlg_list()
    out = {"selectdialog": bool(xbmc.getCondVisibility("Window.IsActive(selectdialog)")),
           "modal": bool(xbmc.getCondVisibility("System.HasModalDialog")),
           "skip": bool(xbmc.getCondVisibility(_DLG_SKIP)), "window": g("System.CurrentWindow"),
           "control": g("System.CurrentControlID"), "list_id": cid, "list_n": n,
           "heading": g("Control.GetLabel(1)"), "ele": _ele_kind(), "ele_title": g("Control.GetLabel(32501)"), "active": bool(_dlg_active()), "yn": _yn_kind()}
    p = "Container(%d).ListItemAbsolute(0)." % cid
    out["first"] = {k: g(p + k) for k in ("Label", "Label2", "Title", "Plot", "Comment", "Property(title)",
                                          "Property(name)", "Property(description)", "Property(info)")}
    return out


def _force_list():
    """Кнопка «окно с ТВ»: берём самый длинный видимый список открытого окна/диалога, что бы это ни было."""
    d = _did() or xbmcgui.getCurrentWindowId()
    best = (0, 0)
    for i in _win_lists(d)[:30]:
        if not xbmc.getCondVisibility("Control.IsVisible(%d)" % i):
            continue
        n = _num("Container(%d).NumItems" % i)
        if n > best[1]:
            best = (i, n)
    return best


def _scan_py_dialogs():
    """Окно Elementum могло не стать «активным диалогом» для infolabel'ов — ищем его среди динамических окон Python
    (id 13000+) и читаем список 32503 напрямую. Возвращает (id окна, заголовок, [(label, label2, extra)])."""
    for wid in list(range(13000, 13040)):
        try:
            w = xbmcgui.Window(wid)
            c = w.getControl(32503)
            n = c.size()
        except Exception:
            continue
        if n <= 0:
            continue
        try:
            title = w.getControl(32501).getLabel()
        except Exception:
            title = ""
        items = []
        for i in range(min(n, 300)):
            li = c.getListItem(i)
            items.append((li.getLabel(), li.getLabel2(), li.getProperty("description") or li.getProperty("info") or ""))
        return wid, title, items
    return 0, "", []


def dialog_info(force=False):
    forced = False
    if _dlg_active():
        cid, n = _dlg_list()
    elif force:
        _win_probe.clear()
        g = xbmc.getInfoLabel
        log("force: did=%s win=%s modal=%s n32503=%s" % (
            _did(), xbmcgui.getCurrentWindowId(), xbmc.getCondVisibility("System.HasModalDialog"),
            g("Container(32503).NumItems")), ev=False)
        if _num("Container(32503).NumItems") > 0:
            cid, n = 32503, _num("Container(32503).NumItems")
        else:
            cid, n = _force_list()
        if not n:
            return {"open": False}
        forced = True
    else:
        return {"open": False}
    g = xbmc.getInfoLabel
    items = []
    for i in range(min(n, 300)):
        p = "Container(%d).ListItemAbsolute(%d)." % (cid, i)
        label = kodi_fmt(g(p + "Label") or g(p + "Title") or g(p + "Property(title)") or g(p + "Property(name)"))
        label2 = kodi_fmt(g(p + "Label2"))
        extra = kodi_fmt(g(p + "Plot") or g(p + "Comment") or g(p + "Property(description)") or g(p + "Property(info)"))
        if extra and extra in (label, label2):
            extra = ""
        items.append({"i": i, "label": label, "label2": label2, "extra": extra[:300]})
    if cid == 32503 and not any(x["label"] or x["label2"] for x in items):
        pn, pt, pit = _py_list()
        if pn:
            items = [{"i": i, "label": kodi_fmt(a), "label2": kodi_fmt(b), "extra": kodi_fmt(c)[:300]}
                     for i, (a, b, c) in enumerate(pit)]
    title = kodi_fmt(g("Control.GetLabel(32501)") if cid == 32503 else g("Control.GetLabel(1)"))
    if not title and xbmc.getCondVisibility("Window.IsActive(contextmenu)"):
        title = "Контекстное меню"
    if cid == 32503 and not title:
        title = "Выбор на ТВ"
    if not title:
        title = g("System.CurrentWindow")
    if forced and not title:
        title = g("Control.GetLabel(1)") or g("System.CurrentWindow")
    return {"open": True, "title": title, "n": n, "window": g("System.CurrentWindow"), "control": cid,
            "readable": any(x["label"] or x["label2"] for x in items), "items": items}


def dialog_select(body):
    if body.get("id"):
        cid = int(body["id"])
        n = _num("Container(%d).NumItems" % cid)
    else:
        if not _dlg_active():
            raise ValueError("Диалог на ТВ уже закрыт")
        cid, n = _dlg_list()
    idx = int(body.get("index", -1))
    if not 0 <= idx < n:
        raise ValueError("нет такого пункта")
    xbmc.executebuiltin("SetFocus(%d,%d,absolute)" % (cid, idx))
    time.sleep(0.3)
    rpc("Input.Select")
    log("dialog select: %d (%s)" % (idx, xbmc.getInfoLabel("Container(%d).ListItemAbsolute(%d).Label" % (cid, idx))[:60]))
    return {"ok": True}


def dialog_cancel():
    rpc("Input.Back")
    return {"ok": True}


# ---------- диалоги «Да/Нет» и «ОК» на ТВ (запрос установки add-on'а и т. п.) ----------
def _yn_kind():
    if xbmc.getCondVisibility("Window.IsActive(yesnodialog)"):
        return "yesno"
    if xbmc.getCondVisibility("Window.IsActive(okdialog)"):
        return "ok"
    return ""


def confirm_info():
    k = _yn_kind()
    if not k:
        return {"open": False}
    g = xbmc.getInfoLabel
    text = ""
    for cid in (9, 5, 2):
        text = g("Control.GetLabel(%d)" % cid)
        if text:
            break
    lines = [x for x in (g("Control.GetLabel(%d)" % i) for i in (2, 3, 4)) if x and x != text]
    if lines and text != "\n".join(lines):
        text = "\n".join([text] + lines) if text else "\n".join(lines)
    return {"open": True, "kind": k, "title": g("Control.GetLabel(1)"), "text": kodi_fmt(text)}


def confirm_answer(body):
    k = _yn_kind()
    if not k:
        raise ValueError("Диалог на ТВ уже закрыт")
    yes = bool(body.get("yes"))
    if k == "yesno":
        want = (xbmc.getLocalizedString(107 if yes else 106) or ("Yes" if yes else "No")).strip().lower()
        for cid in (10, 11, 12):
            if xbmc.getInfoLabel("Control.GetLabel(%d)" % cid).strip().lower() == want:
                xbmc.executebuiltin("SetFocus(%d)" % cid)
                time.sleep(0.25)
                rpc("Input.Select")
                return {"ok": True}
        if yes:
            rpc("Input.Select")      # фокус по умолчанию стоит на «Да» не везде, но это лучший запасной вариант
        else:
            rpc("Input.Back")
    else:
        rpc("Input.Select")
    return {"ok": True}


# ---------- звук и субтитры ----------
DELAY = {"file": "", "ms": 0}  # сдвиг звука, заданный отсюда (Kodi не отдаёт текущее значение по JSON-RPC)


def tracks():
    pid = active_player()
    if pid is None:
        return {"playing": False, "audio": [], "subs": [], "delay": 0}
    pr = rpc("Player.GetProperties", {"playerid": pid, "properties": [
        "audiostreams", "currentaudiostream", "subtitles", "currentsubtitle", "subtitleenabled"]}).get("result", {})
    f = rpc("Player.GetItem", {"playerid": pid}).get("result", {}).get("item", {}).get("file", "")
    if DELAY["file"] != f:
        DELAY.update(file=f, ms=0)

    def label(x):
        bits = [x.get("language") or "", x.get("name") or "", (x.get("codec") or "").upper()]
        if x.get("channels"):
            bits.append("%sch" % x["channels"])
        return " · ".join(b for b in bits if b) or "Дорожка %s" % (x.get("index", 0) + 1)

    return {"playing": True,
            "audio": [{"index": a["index"], "name": label(a)} for a in pr.get("audiostreams", [])],
            "audio_cur": (pr.get("currentaudiostream") or {}).get("index", -1),
            "subs": [{"index": a["index"], "name": label(a)} for a in pr.get("subtitles", [])],
            "sub_cur": (pr.get("currentsubtitle") or {}).get("index", -1),
            "sub_on": bool(pr.get("subtitleenabled")), "delay": DELAY["ms"]}


def audio_delay(steps):
    f = rpc("Player.GetItem", {"playerid": active_player() or 0}).get("result", {}).get("item", {}).get("file", "")
    if DELAY["file"] != f:
        DELAY.update(file=f, ms=0)
    for _ in range(min(abs(steps), 40)):
        rpc("Input.ExecuteAction", {"action": "audiodelayplus" if steps > 0 else "audiodelayminus"})
    DELAY["ms"] += (1 if steps > 0 else -1) * min(abs(steps), 40) * 25


# ---------- питание и таймер сна ----------
SLEEP = {"at": 0.0, "action": "stop", "gen": 0}
POWER_RPC = {"suspend": "System.Suspend", "reboot": "System.Reboot", "shutdown": "System.Shutdown", "quit": "Application.Quit"}


_tv_gen = [0]
_wake_ts = [0.0]


def tv_mac():
    m = (cfg().getSetting("tv_mac") or "").strip()
    if m:
        try:
            return norm_mac(m)
        except ValueError:
            log("tv_mac: неверный MAC %r" % m)
    for d in devices_load():
        if re.search(r"(?i)(\btv\b|тв|телевизор|philips|oled)", d.get("name", "")):
            return d["mac"]
    return None


def tv_wake(delay=0):
    """Включить ТВ и переключить его на HDMI-вход приставки: CEC «активный источник» + запасной WoL на ТВ.
    CEC повторяем несколько раз — Android TV после включения грузится 5–20 секунд и сначала не слушает."""
    _tv_gen[0] += 1
    gen = _tv_gen[0]

    def job():
        time.sleep(delay)
        mac = tv_mac()
        for step, pause in enumerate((0, 8, 8, 12)):
            time.sleep(pause)
            if _tv_gen[0] != gen:
                return
            xbmc.executebuiltin("CECActivateSource")
            if step == 0 and mac:
                for _ in range(3):
                    try:
                        wol_send({"mac": mac})
                    except RuntimeError as e:
                        log("tv wol: %s" % e)
                        break
                    time.sleep(0.5)

    threading.Thread(target=job, daemon=True).start()


def eco_standby():
    """«Режим ожидания»: остановить воспроизведение и выключить ТВ по CEC, а сама приставка остаётся
    включённой (экономно) и доступна с телефона. Из глубокого сна приставку с телефона не разбудить."""
    _tv_gen[0] += 1
    act = _active()
    if act:
        rpc("Player.Stop", {"playerid": act[0]["playerid"]})
    xbmc.executebuiltin("CECStandby")


def on_wake():
    if time.time() - _wake_ts[0] < 30:
        return
    _wake_ts[0] = time.time()
    log("wake from suspend detected")
    if (cfg().getSetting("cec_on_wake") or "true") != "false":
        tv_wake(3)


def power(body):
    a = body.get("action")
    if a in POWER_RPC:
        threading.Timer(0.7, lambda: rpc(POWER_RPC[a])).start()  # сначала ответим телефону
    elif a == "tv_off":
        _tv_gen[0] += 1
        xbmc.executebuiltin("CECStandby")
    elif a == "tv_on":
        tv_wake()
    elif a == "eco":
        eco_standby()
    elif a == "android":
        reboot_android()
    else:
        raise ValueError("unknown action")
    return {"ok": True}


def reboot_android():
    """Как пункт «Reboot from eMMC/NAND» в меню питания CoreELEC:
    System.ExecWait(/usr/sbin/rebootfromnand), затем Reset() — перезагрузка уже в Android."""
    exe = "/usr/sbin/rebootfromnand"
    if not os.path.exists(exe):
        exe = shutil.which("rebootfromnand", path=os.environ.get("PATH", "") + ":/usr/sbin:/sbin:/usr/bin") or ""
    if not exe:
        raise ValueError("команда rebootfromnand не найдена (нужен CoreELEC на Amlogic с Android в eMMC)")
    log("reboot to Android: %s, затем Reset()" % exe)

    def go():
        xbmc.executebuiltin('System.ExecWait("%s")' % exe)
        time.sleep(0.5)
        xbmc.executebuiltin("Reset()")
    threading.Timer(0.7, go).start()


_thumb_cache = collections.OrderedDict()
_thumb_lock = threading.Lock()


def _kodi_image(url):
    """Картинка через Kodi: image://video@… сам вытаскивает кадр из видео (как превью слева в списке файлов)."""
    hit = _thumb_cache.get(url)
    if hit:
        return hit
    with _thumb_lock:
        hit = _thumb_cache.get(url)
        if hit:
            return hit
        f = xbmcvfs.File(url)
        try:
            data = bytes(f.readBytes(8 * MB))
        finally:
            f.close()
        if len(data) < 100:
            raise RuntimeError("нет превью")
        ctype = "image/png" if data[:4] == b"\x89PNG" else "image/webp" if data[:4] == b"RIFF" else "image/jpeg"
        _thumb_cache[url] = (data, ctype)
        while len(_thumb_cache) > 40:
            _thumb_cache.popitem(last=False)
        return data, ctype


def _image_url_for(target, kind):
    q = urllib.parse.quote(target, safe="")
    return "image://%s%s/" % ({"video": "video@", "music": "music@"}.get(kind, ""), q)


def thumb_for_pid(pid):
    target, name, kind = target_for(pid)
    return _kodi_image(_image_url_for(target, kind))


def thumb_for_key(key):
    """Кадр/обложка для записи «Продолжить просмотр» (и для файлов браузера, и для локальных адресов)."""
    e = hist_get(key)
    if not e:
        raise RuntimeError("нет записи")
    if e.get("id"):
        return thumb_for_pid(e["id"])
    return _kodi_image(_image_url_for(e["target"], "video"))


def thumb_now():
    pid = active_player()
    if pid is None:
        raise RuntimeError("ничего не играет")
    it = rpc("Player.GetItem", {"playerid": pid, "properties": ["file", "thumbnail"]}).get("result", {}).get("item", {})
    th = it.get("thumbnail") or ""
    if th:
        try:
            return _kodi_image(th)
        except Exception:  # noqa
            pass
    f = it.get("file") or ""
    if not f:
        raise RuntimeError("нет файла")
    return _kodi_image(_image_url_for(f, kind_of(f)))


SHOT_KEEP = 12


def _shot_dir():
    d = os.path.join(data_dir(), "shots")
    os.makedirs(d, exist_ok=True)
    return d


def _png_from_bgra(w, h, bgra):
    """Минимальный PNG-кодировщик (без внешних библиотек) из буфера BGRA."""
    rgb = bytearray(w * h * 3)
    rgb[0::3], rgb[1::3], rgb[2::3] = bgra[2::4], bgra[1::4], bgra[0::4]
    raw = bytearray()
    for y in range(h):
        raw += b"\x00" + rgb[y * w * 3:(y + 1) * w * 3]

    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)) +
            chunk(b"IDAT", zlib.compress(bytes(raw), 3)) + chunk(b"IEND", b""))


FF_ST = {"running": False, "msg": "", "error": ""}
FF_URLS = {"arm64": ["https://johnvansickle.com/ffmpeg/releases/ffmpeg-release-arm64-static.tar.xz",
                     "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-linuxarm64-gpl.tar.xz"],
           "armhf": ["https://johnvansickle.com/ffmpeg/releases/ffmpeg-release-armhf-static.tar.xz"]}


def ffmpeg_path():
    own = os.path.join(data_dir(), "bin", "ffmpeg")
    if os.path.isfile(own) and os.access(own, os.X_OK):
        return own
    return shutil.which("ffmpeg") or next((p for p in ("/usr/bin/ffmpeg", "/storage/.opt/bin/ffmpeg",
                                                       "/opt/bin/ffmpeg", "/storage/bin/ffmpeg") if os.path.isfile(p)), None)


def ffmpeg_state():
    return {"installed": bool(ffmpeg_path()), "running": FF_ST["running"], "msg": FF_ST["msg"], "error": FF_ST["error"]}


def _ffmpeg_install_job():
    import platform
    import tarfile
    try:
        m = platform.machine().lower()
        arch = "arm64" if m in ("aarch64", "arm64") else "armhf" if m.startswith("arm") else ""
        if not arch:
            raise RuntimeError("неподдерживаемая архитектура: %s" % m)
        bd = os.path.join(data_dir(), "bin")
        os.makedirs(bd, exist_ok=True)
        arc = os.path.join(bd, "ffmpeg.tar.xz")
        last = ""
        for url in FF_URLS[arch]:
            try:
                FF_ST["msg"] = "Скачиваю ffmpeg…"
                req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=30) as r, open(arc, "wb") as fh:
                    total = int(r.headers.get("Content-Length") or 0)
                    got = 0
                    while True:
                        b = r.read(262144)
                        if not b:
                            break
                        fh.write(b)
                        got += len(b)
                        FF_ST["msg"] = "Скачиваю ffmpeg… %d%s МБ" % (got // 1048576, "/%d" % (total // 1048576) if total else "")
                break
            except Exception as e:  # noqa
                last = "%s: %s" % (urllib.parse.urlparse(url).netloc, e)
                log("ffmpeg download failed: %s" % last)
        else:
            raise RuntimeError("не удалось скачать (%s)" % last)
        FF_ST["msg"] = "Распаковываю…"
        dst = os.path.join(bd, "ffmpeg")
        with tarfile.open(arc, "r:xz") as tf:
            mem = next((x for x in tf.getmembers() if x.isfile() and os.path.basename(x.name) == "ffmpeg"), None)
            if not mem:
                raise RuntimeError("в архиве нет ffmpeg")
            with tf.extractfile(mem) as src, open(dst + ".part", "wb") as out:
                shutil.copyfileobj(src, out, 1048576)
        os.chmod(dst + ".part", 0o755)
        os.replace(dst + ".part", dst)
        try:
            os.remove(arc)
        except OSError:
            pass
        r = subprocess.run([dst, "-version"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=20)
        if r.returncode != 0:
            raise RuntimeError("ffmpeg не запускается: %s" % r.stdout.decode("utf-8", "replace")[:120])
        FF_ST.update(msg="Готово", error="")
        log("ffmpeg установлен: %s" % dst)
    except Exception as e:  # noqa
        FF_ST.update(msg="", error=str(e))
        log("ffmpeg install error: %s" % e)
    finally:
        FF_ST["running"] = False


def ffmpeg_install():
    if FF_ST["running"]:
        return {"ok": True}
    FF_ST.update(running=True, msg="Подготовка…", error="")
    threading.Thread(target=_ffmpeg_install_job, daemon=True).start()
    return {"ok": True}


def _frame_ffmpeg(out, why):
    """Кадр из видеофайла на текущей секунде через ffmpeg (если он есть на приставке). Для HDR/DV пробуем tone mapping."""
    ff = ffmpeg_path()
    if not ff:
        why.append("ffmpeg не найден на приставке (его можно установить кнопкой ниже)")
        return False
    pid = active_player()
    it = rpc("Player.GetItem", {"playerid": pid, "properties": ["file"]}).get("result", {}).get("item", {}) if pid is not None else {}
    f = it.get("file") or ""
    if not f or f.startswith("plugin://"):
        why.append("для этого источника кадр через ffmpeg недоступен")
        return False
    t = to_sec(rpc("Player.GetProperties", {"playerid": pid, "properties": ["time"]}).get("result", {}).get("time"))
    hdr = bool(xbmc.getInfoLabel("VideoPlayer.HdrType").strip())
    tone = ("zscale=t=linear:npl=100,format=gbrpf32le,zscale=p=bt709,tonemap=hable:desat=0,"
            "zscale=t=bt709:m=bt709:r=tv,format=rgb24")
    for vf in ([tone, None] if hdr else [None]):
        cmd = [ff, "-v", "error", "-y", "-ss", str(t), "-i", f, "-frames:v", "1", "-an", "-sn"]
        if vf:
            cmd += ["-vf", vf]
        cmd.append(out)
        try:
            r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
        except Exception as e:  # noqa
            why.append("ffmpeg: %s" % e)
            continue
        if os.path.isfile(out) and os.path.getsize(out) > 0:
            return "ffmpeg" + (" + tone mapping" if vf else (" (без tone mapping)" if hdr else ""))
        why.append("ffmpeg%s: %s" % (" (tonemap)" if vf else "", (r.stderr or b"").decode("utf-8", "replace").strip()[-160:]))
    return False


def _frame_rendercapture(out, why):
    """Снимок кадра самим Kodi (RenderCapture). Работает, только если кадр проходит через рендер Kodi, а не аппаратный слой."""
    try:
        cap = xbmc.RenderCapture()
        cap.capture(1280, 720)
        img = None
        for _ in range(10):
            time.sleep(0.15)
            img = cap.getImage(300)
            if img:
                break
        w, h = cap.getWidth(), cap.getHeight()
        if not img or not w or not h or len(img) < w * h * 4:
            why.append("RenderCapture: Kodi не отдаёт кадр (аппаратное декодирование)")
            return False
        img = bytes(img)
        if not any(img[i] for i in range(0, min(len(img), w * h * 4), 997)):
            why.append("RenderCapture: пустой (чёрный) кадр")
            return False
        with open(out, "wb") as fh:
            fh.write(_png_from_bgra(w, h, img))
        return "RenderCapture"
    except Exception as e:  # noqa
        why.append("RenderCapture: %s" % e)
        return False


def take_screenshot():
    """Снимок интерфейса Kodi (TakeScreenshot) + при воспроизведении видео — отдельный кадр видео (ffmpeg или
    RenderCapture). Видеослой Amlogic рисуется аппаратно отдельно от интерфейса, поэтому в снимок интерфейса кадр
    видео не попадает — отсюда второй файл."""
    d = _shot_dir()
    stamp = time.strftime("%Y%m%d_%H%M%S")
    fn = os.path.join(d, "shot_%s.png" % stamp)
    video = bool(xbmc.getCondVisibility("Player.HasVideo"))
    frame_out = os.path.join(d, "shot_%s_video.png" % stamp)
    res = {"ok": True, "video": video, "frame": None, "method": "", "why": []}
    if video:
        for fnc in (_frame_rendercapture, _frame_ffmpeg):
            m = fnc(frame_out, res["why"])
            if m:
                res["frame"], res["method"] = os.path.basename(frame_out), m
                break
    xbmc.executebuiltin('TakeScreenshot(%s,sync)' % fn)
    found = None
    for _ in range(30):
        time.sleep(0.1)
        c = [p for p in glob.glob(os.path.join(d, "shot_%s.*" % stamp)) if os.path.getsize(p) > 0
             and not p.endswith("_video.png")]
        if c:
            found = c[0]
            break
    if not found and not res["frame"]:
        raise RuntimeError("Kodi не сохранил скриншот")
    time.sleep(0.15)  # дописывается файл
    files = sorted(glob.glob(os.path.join(d, "shot_*")))
    for old in files[:-SHOT_KEEP]:
        try:
            os.remove(old)
        except OSError:
            pass
    res["name"] = os.path.basename(found) if found else res["frame"]
    log("screenshot: gui=%s frame=%s %s" % (res["name"], res["frame"], "; ".join(res["why"])), ev=False)
    return res


def read_screenshot(name):
    name = os.path.basename(str(name))
    p = os.path.join(_shot_dir(), name)
    if not name.startswith("shot_") or not os.path.isfile(p):
        raise ValueError("нет такого снимка")
    with open(p, "rb") as f:
        data = f.read()
    ctype = "image/png" if data[:4] == b"\x89PNG" else "image/jpeg"
    return data, ctype, name


def power_caps():
    r = rpc("System.GetProperties", {"properties": ["canshutdown", "canreboot", "cansuspend"]}).get("result", {})
    return {"suspend": r.get("cansuspend", True), "reboot": r.get("canreboot", True),
            "shutdown": r.get("canshutdown", True), "sleep": sleep_state(),
            "android": bool(os.path.exists("/usr/sbin/rebootfromnand") or shutil.which("rebootfromnand"))}


def sleep_state():
    left = max(0, int(SLEEP["at"] - time.time())) if SLEEP["at"] else 0
    return {"left": left, "action": SLEEP["action"]}


def sleep_set(body):
    SLEEP["gen"] += 1
    if body.get("cancel"):
        SLEEP["at"] = 0.0
        return sleep_state()
    minutes = max(1, min(600, int(body.get("minutes", 30))))
    action = body.get("action") if body.get("action") in ("stop", "suspend", "shutdown") else "stop"
    SLEEP.update(at=time.time() + minutes * 60, action=action)
    threading.Thread(target=_sleep_job, args=(SLEEP["gen"],), daemon=True).start()
    return sleep_state()


def _sleep_job(gen):
    warned = False
    while SLEEP["gen"] == gen and time.time() < SLEEP["at"]:
        left = SLEEP["at"] - time.time()
        if left < 60 and not warned:
            warned = True
            xbmcgui.Dialog().notification("Таймер сна", "Через минуту", xbmcgui.NOTIFICATION_INFO, 5000)
        time.sleep(min(2, max(0.2, left)))
    if SLEEP["gen"] != gen:
        return
    SLEEP["at"] = 0.0
    act = _active()
    if act:
        rpc("Player.Stop", {"playerid": act[0]["playerid"]})
    if SLEEP["action"] == "suspend":
        rpc("System.Suspend")
    elif SLEEP["action"] == "shutdown":
        rpc("System.Shutdown")


NAV = {"up": "Input.Up", "down": "Input.Down", "left": "Input.Left", "right": "Input.Right",
       "ok": "Input.Select", "back": "Input.Back", "home": "Input.Home",
       "menu": "Input.ContextMenu", "info": "Input.Info"}


def control(body):
    act = body.get("action")
    if act == "ok":
        # как на обычном пульте: во весь экран видео ОК открывает меню плеера (OSD)
        fs = xbmc.getCondVisibility("Window.IsActive(fullscreenvideo) | Window.IsActive(visualisation)")
        busy = xbmc.getCondVisibility("Window.IsActive(videoosd) | Window.IsActive(musicosd) | System.HasActiveModalDialog")
        rpc("Input.ShowOSD" if fs and not busy else "Input.Select")
        return
    if act in NAV:
        rpc(NAV[act])
        return
    if act in ("cec_vol_up", "cec_vol_down", "cec_mute"):
        cec_volume({"cec_vol_up": 0x41, "cec_vol_down": 0x42, "cec_mute": 0x43}[act], body.get("target"))
        return
    if act == "text":
        rpc("Input.SendText", {"text": str(body.get("text", ""))[:500], "done": bool(body.get("done"))})
        return
    if act == "backspace":
        rpc("Input.ExecuteAction", {"action": "backspace"})
        return
    if act == "volume":
        rpc("Application.SetVolume", {"volume": max(0, min(100, int(body.get("value", 50))))})
        return
    if act == "mute":
        rpc("Application.SetMute", {"mute": "toggle"})
        return
    pid = active_player()
    if pid is None:
        return
    if act == "playpause":
        rpc("Player.PlayPause", {"playerid": pid})
    elif act == "stop":
        rpc("Player.Stop", {"playerid": pid})
    elif act == "seek_rel":
        pr = rpc("Player.GetProperties", {"playerid": pid, "properties": ["time", "totaltime"]}).get("result", {})
        total = to_sec(pr.get("totaltime"))
        target = max(0, min(total - 1 if total else 10 ** 9, to_sec(pr.get("time")) + int(body.get("value", 0))))
        rpc("Player.Seek", {"playerid": pid, "value": {"time": from_sec(target)}})
    elif act == "seek_pct":
        rpc("Player.Seek", {"playerid": pid, "value": {"percentage": max(0.0, min(100.0, float(body.get("value", 0))))}})
    elif act == "audio_set":
        rpc("Player.SetAudioStream", {"playerid": pid, "stream": int(body.get("value", 0))})
    elif act == "sub_set":
        v = int(body.get("value", -1))
        if v < 0:
            rpc("Player.SetSubtitle", {"playerid": pid, "subtitle": "off"})
        else:
            rpc("Player.SetSubtitle", {"playerid": pid, "subtitle": v, "enable": True})
    elif act == "audio_delay":
        audio_delay(int(body.get("value", 0)))
    elif act == "audio_delay_reset":
        audio_delay(-(DELAY["ms"] // 25))
    elif act == "audio":
        rpc("Player.SetAudioStream", {"playerid": pid, "stream": "next"})
    elif act == "subtitle":
        rpc("Player.SetSubtitle", {"playerid": pid, "subtitle": "next", "enable": True})


# ---------- HDMI-CEC volume ----------
# Громкость ТВ/ресивера шлётся командами CEC «User Control Pressed/Released» (0x41 громче, 0x42 тише, 0x43 mute).
# Порядок: своя команда из настроек -> /dev/cec* напрямую -> cec-ctl -> cec-client.
CEC_TARGETS = {"tv": 0, "avr": 5}
_cec_cache = {"t": 0.0, "dest": None}


def _ioc(d, nr, size):
    return (d << 30) | (size << 16) | (ord("a") << 8) | nr


_MSG = struct.Struct("<QQIIII16s7B1x")  # struct cec_msg, 56 байт
CEC_G_LOG_ADDRS = _ioc(2, 3, 92)
CEC_TRANSMIT = _ioc(3, 5, _MSG.size)
CEC_S_MODE = _ioc(1, 9, 4)


def _cec_send(fd, init, dest, payload):
    msg = bytes([(init << 4) | dest]) + bytes(payload)
    raw = bytearray(_MSG.pack(0, 0, len(msg), 1000, 0, 0, msg.ljust(16, b"\0"), 0, 0, 0, 0, 0, 0, 0))
    fcntl.ioctl(fd, CEC_TRANSMIT, raw, True)
    st = _MSG.unpack(bytes(raw))
    return bool(st[9] & 0x01)  # tx_status OK (ACK получен)


def _cec_ioctl(code, dest_pref):
    devs = sorted(glob.glob("/dev/cec*"))
    if not devs:
        return None  # метод недоступен
    last = "нет ответа"
    for dev in devs:
        try:
            fd = os.open(dev, os.O_RDWR)
        except OSError as e:
            last = "%s: %s" % (dev, e.strerror)
            continue
        try:
            fcntl.ioctl(fd, CEC_S_MODE, struct.pack("<I", 1))  # CEC_MODE_INITIATOR
            la = bytearray(92)
            fcntl.ioctl(fd, CEC_G_LOG_ADDRS, la, True)
            if la[7] == 0:
                last = "CEC-адаптер не настроен (запущен ли CEC в Kodi?)"
                continue
            init = la[0] & 0x0F
            if dest_pref == "auto":
                now = time.time()
                if now - _cec_cache["t"] > 60 or _cec_cache["dest"] is None:
                    _cec_cache["dest"] = 5 if _cec_send(fd, init, 5, []) else 0
                    _cec_cache["t"] = now
                dest = _cec_cache["dest"]
            else:
                dest = CEC_TARGETS[dest_pref]
            ok = _cec_send(fd, init, dest, [0x44, code])
            time.sleep(0.05)
            _cec_send(fd, init, dest, [0x45])
            if ok:
                return True
            last = "устройство %d не ответило" % dest
            _cec_cache["t"] = 0
        except OSError as e:
            last = "%s: %s" % (dev, e.strerror or e)
        finally:
            os.close(fd)
    raise RuntimeError("CEC: " + last)


def _run(cmd, **kw):
    return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=6, **kw)


AOCEC_CMD = "/sys/class/aocec/cmd"
AOCEC_LA = "/sys/class/aocec/log_addr"


def _cec_aocec(code, target):
    """Родной CEC-драйвер Amlogic (CoreELEC): сырые кадры пишутся в /sys/class/aocec/cmd
    (или /dev/aocec). Первый байт — заголовок: (наш логический адрес << 4) | адресат."""
    use_sysfs = os.path.exists(AOCEC_CMD)
    if not use_sysfs and not os.path.exists("/dev/aocec"):
        return None
    la = 4
    try:
        v = int(open(AOCEC_LA).read().strip(), 16)
        if 0 < v < 15:
            la = v
    except (OSError, ValueError):
        pass
    dest = CEC_TARGETS["tv" if target == "tv" else "avr"]
    head = (la << 4) | dest
    for frame in ([head, 0x44, code], [head, 0x45]):
        if use_sysfs:
            data = (" ".join("0x%02x" % b for b in frame) + "\n").encode()
            fd = os.open(AOCEC_CMD, os.O_WRONLY)
        else:
            data = bytes(frame)
            fd = os.open("/dev/aocec", os.O_WRONLY)
        try:
            os.write(fd, data)
        finally:
            os.close(fd)
        time.sleep(0.06)
    log("CEC aocec: sent key 0x%02x to %d from %d" % (code, dest, la))
    return True


def cec_volume(code, target=None):
    s = cfg()
    target = target or s.getSetting("cec_target") or "auto"
    if target not in ("auto", "tv", "avr"):
        target = "auto"
    names = {0x41: "cec_cmd_up", 0x42: "cec_cmd_down", 0x43: "cec_cmd_mute"}
    custom = (s.getSetting(names[code]) or "").strip()
    if custom:
        r = _run(custom, shell=True)
        if r.returncode != 0:
            raise RuntimeError("CEC-команда вернула ошибку: " + r.stdout.decode(errors="replace")[-120:])
        return
    try:
        if _cec_aocec(code, target):
            return
    except OSError as e:
        raise RuntimeError("CEC (aocec): %s" % (e.strerror or e))
    res = _cec_ioctl(code, target)
    if res:
        return
    dest = {"tv": 0, "avr": 5}.get(target, 5)
    if shutil.which("cec-ctl"):
        for d in ([dest] if target != "auto" else [5, 0]):
            a = _run(["cec-ctl", "--to", str(d), "--user-control-pressed", "ui-cmd=0x%x" % code])
            _run(["cec-ctl", "--to", str(d), "--user-control-released"])
            if a.returncode == 0:
                return
        raise RuntimeError("cec-ctl не смог отправить команду: " + a.stdout.decode(errors="replace")[-150:].strip())
    if shutil.which("cec-client"):
        cmd = "tx 4%x:44:%02x\ntx 4%x:45" % (dest, code, dest)
        r = subprocess.run(["cec-client", "-s", "-d", "1"], input=cmd.encode(), stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT, timeout=8)
        if r.returncode == 0:
            return
    raise RuntimeError("CEC недоступен: нет /sys/class/aocec, /dev/cec*, cec-ctl и cec-client. "
                       "Задайте свою команду в настройках add-on (вкладка HDMI-CEC).")


# ---------- transmission ----------
_tr_session = {"id": ""}


def tr_call(method, arguments=None):
    s = cfg()
    url = "http://%s:%s/transmission/rpc" % (s.getSetting("tr_host") or "127.0.0.1", s.getSetting("tr_port") or "9091")
    payload = json.dumps({"method": method, "arguments": arguments or {}}).encode()
    for _ in range(2):
        headers = {"Content-Type": "application/json", "X-Transmission-Session-Id": _tr_session["id"]}
        user = s.getSetting("tr_user")
        if user:
            token = base64.b64encode(("%s:%s" % (user, s.getSetting("tr_pass"))).encode()).decode()
            headers["Authorization"] = "Basic " + token
        req = urllib.request.Request(url, payload, headers)
        try:
            with urllib.request.urlopen(req, timeout=8) as r:
                return json.loads(r.read().decode())
        except urllib.error.HTTPError as e:
            if e.code == 409:
                _tr_session["id"] = e.headers.get("X-Transmission-Session-Id", "")
                continue
            if e.code == 401:
                raise RuntimeError("Transmission: неверный логин/пароль")
            raise RuntimeError("Transmission HTTP %s" % e.code)
        except Exception:  # noqa
            raise RuntimeError("Transmission недоступен (установлен и запущен?)")
    raise RuntimeError("Transmission: не удалось получить session id")


TR_FIELDS = ["id", "name", "percentDone", "status", "rateDownload", "rateUpload",
             "totalSize", "eta", "error", "errorString"]
TR_STATE = {0: "paused", 1: "checking", 2: "checking", 3: "queued", 4: "downloading", 5: "queued", 6: "seeding"}


def backend():
    return "transmission" if cfg().getSetting("tr_backend") == "transmission" else "qbittorrent"


def tr_list():
    r = tr_call("torrent-get", {"fields": TR_FIELDS})
    out = []
    for t in r.get("arguments", {}).get("torrents", []):
        st = "error" if t.get("error") else TR_STATE.get(t.get("status"), "unknown")
        out.append({"id": str(t["id"]), "name": t.get("name", ""), "pc": t.get("percentDone", 0), "state": st,
                    "dl": t.get("rateDownload", 0), "ul": t.get("rateUpload", 0), "size": t.get("totalSize", 0),
                    "seq": None, "error": t.get("errorString", "")})
    return out


def tr_add(body):
    args = {}
    if body.get("url"):
        args["filename"] = body["url"].strip()
    elif body.get("file_b64"):
        args["metainfo"] = body["file_b64"]
    else:
        raise ValueError("нужна magnet-ссылка, URL или .torrent файл")
    d = cfg().getSetting("tr_dir")
    if d:
        args["download-dir"] = d
    r = tr_call("torrent-add", args)
    if r.get("result") != "success":
        raise RuntimeError("Transmission: %s" % r.get("result"))


def tr_action(body):
    ids = [int(body["id"])]
    act = body.get("action")
    if act == "start":
        tr_call("torrent-start", {"ids": ids})
    elif act == "stop":
        tr_call("torrent-stop", {"ids": ids})
    elif act == "remove":
        tr_call("torrent-remove", {"ids": ids, "delete-local-data": bool(body.get("delete_data"))})
    elif act == "recheck":
        tr_call("torrent-verify", {"ids": ids})
        tr_call("torrent-start", {"ids": ids})
    else:
        raise ValueError("Transmission не поддерживает это действие")


# ---------- qBittorrent (Web API v2) ----------
import http.cookiejar  # noqa: E402

_qb = {"jar": http.cookiejar.CookieJar(), "ok": False}
_qb_opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(_qb["jar"]))


def qb_base():
    s = cfg()
    return "http://%s:%s" % (s.getSetting("qb_host") or "127.0.0.1", s.getSetting("qb_port") or "9080")


def multipart(fields, files):
    bd = "----PhoneRemote" + os.urandom(8).hex()
    parts = []
    for k, v in fields.items():
        parts.append(('--%s\r\nContent-Disposition: form-data; name="%s"\r\n\r\n%s\r\n' % (bd, k, v)).encode())
    for k, (fn, data) in files.items():
        parts.append(('--%s\r\nContent-Disposition: form-data; name="%s"; filename="%s"\r\n'
                      'Content-Type: application/x-bittorrent\r\n\r\n' % (bd, k, fn)).encode() + data + b"\r\n")
    parts.append(("--%s--\r\n" % bd).encode())
    return b"".join(parts), "multipart/form-data; boundary=" + bd


def qb_raw(path, data=None, files=None):
    base = qb_base()
    headers = {"Referer": base + "/", "Origin": base}
    body = None
    if files is not None:
        body, headers["Content-Type"] = multipart(data or {}, files)
    elif data is not None:
        body = urllib.parse.urlencode(data).encode()
    req = urllib.request.Request(base + "/api/v2/" + path, body, headers)
    try:
        with _qb_opener.open(req, timeout=10) as r:
            return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()
    except Exception:  # noqa
        raise RuntimeError("qBittorrent недоступен (установлен и запущен? порт %s)" % (cfg().getSetting("qb_port") or "9080"))


def qb_local():
    return (cfg().getSetting("qb_host") or "127.0.0.1").strip() in ("127.0.0.1", "localhost", "")


def qb_port():
    try:
        return int(cfg().getSetting("qb_port") or 9080)
    except ValueError:
        return 9080


def qb_status():
    return {"installed": qbctl.installed(), "running": qbctl.running(qb_port()), "local": qb_local(),
            "entware": qbctl.entware_ready(), "can_install": bool(instjob.find_installentware()), "install": {"running": instjob._S["running"], "pending": instjob.pending()}}


def qb_launch():
    ok, msg = qbctl.start(qb_port())
    return {"ok": ok, "msg": msg, "status": qb_status()}


def qb_boot_job(monitor):
    """После загрузки: продолжить прерванную установку и/или запустить qBittorrent (надёжнее autostart.sh)."""
    try:
        if instjob.pending():
            xbmcgui.Dialog().notification("Phone Remote", "Продолжаю установку qBittorrent…", xbmcgui.NOTIFICATION_INFO, 5000)
            instjob.resume_after_boot(monitor)
            return
        if (cfg().getSetting("qb_autostart") or "true") == "false" or not qb_local():
            return
        for _ in range(90):  # до ~3 минут ждём /opt
            if qbctl.installed() or monitor.waitForAbort(2):
                break
        if not qbctl.installed() or monitor.abortRequested():
            return
        if qbctl.running(qb_port()):
            return
        ok, msg = qbctl.start(qb_port())
        log("qBittorrent autostart: %s %s" % (ok, msg))
        if ok:
            xbmcgui.Dialog().notification("Phone Remote", "qBittorrent запущен", xbmcgui.NOTIFICATION_INFO, 4000)
        else:
            xbmcgui.Dialog().notification("Phone Remote", "qBittorrent не запустился: " + msg[:80], xbmcgui.NOTIFICATION_ERROR, 8000)
    except Exception as e:  # noqa
        log("qb_boot_job: %r" % e)


_qb_fix = [0.0]


def qb_login():
    """Вход в qBittorrent. Если сохранённые логин/пароль не подходят — пробуем admin/admin (по умолчанию),
    а для локального qBittorrent при необходимости возвращаем его вход к admin/admin сами."""
    s = cfg()
    cur = (s.getSetting("qb_user") or "admin", s.getSetting("qb_pass") or "admin")
    tries = [cur] + ([("admin", "admin")] if qb_local() and cur != ("admin", "admin") else [])
    for u, pw in tries:
        code, body = qb_raw("auth/login", {"username": u, "password": pw})
        if code == 200 and body.strip().lower().startswith(b"ok"):
            if (u, pw) != cur:
                s.setSetting("qb_user", u)
                s.setSetting("qb_pass", pw)
                log("qBittorrent: в настройках был другой логин/пароль — возвращены admin/admin")
            return True
    if qb_local() and qbctl.installed() and time.time() - _qb_fix[0] > 120:
        _qb_fix[0] = time.time()
        log("qBittorrent: вход не удался — сбрасываю логин/пароль на admin/admin и перезапускаю")
        ok, msg = qbctl.reset_login(qb_port())
        log("qBittorrent reset_login: %s %s" % (ok, msg))
        if ok:
            s.setSetting("qb_user", "admin")
            s.setSetting("qb_pass", "admin")
            code, body = qb_raw("auth/login", {"username": "admin", "password": "admin"})
            return code == 200 and body.strip().lower().startswith(b"ok")
    return False


def qb(path, data=None, files=None):
    code, body = qb_raw(path, data, files)
    if code in (401, 403):
        if not qb_login():
            raise RuntimeError("qBittorrent: неверный логин/пароль (или включите вход без пароля для localhost)")
        code, body = qb_raw(path, data, files)
    return code, body


QB_PAUSED = ("pausedDL", "pausedUP", "stoppedDL", "stoppedUP")


def qb_state(st):
    if st in QB_PAUSED:
        return "paused"
    if st in ("error", "missingFiles"):
        return "error"
    if st.startswith("checking") or st in ("allocating", "moving"):
        return "checking"
    if st.startswith("queued"):
        return "queued"
    if st in ("metaDL", "forcedMetaDL"):
        return "metadata"
    if st == "stalledDL":
        return "stalled"
    if st in ("downloading", "forcedDL"):
        return "downloading"
    if st in ("uploading", "stalledUP", "forcedUP"):
        return "seeding"
    return "unknown"


def qb_list():
    code, body = qb("torrents/info")
    if code != 200:
        raise RuntimeError("qBittorrent: ошибка %s" % code)
    out = []
    for t in json.loads(body.decode()):
        stt = qb_state(t.get("state", ""))
        err = ""
        if stt == "error":
            try:
                err = torrent_diag(t)
            except Exception as e:  # noqa
                err = "Ошибка (%s)" % e
        cp = t.get("content_path") or ""
        out.append({"id": t.get("hash", ""), "name": t.get("name", ""), "pc": t.get("progress", 0),
                    "state": stt, "dl": t.get("dlspeed", 0), "ul": t.get("upspeed", 0),
                    "size": t.get("size", 0), "seq": bool(t.get("seq_dl")), "error": err,
                    "pid": pid_for_path(cp or t.get("save_path") or ""),
                    "raw": t.get("state", "") if stt == "error" else ""})
    return out


def magnet_hash(url):
    m = re.search(r"xt=urn:btih:([A-Za-z0-9]+)", url)
    if not m:
        return None
    h = m.group(1)
    if len(h) == 40:
        return h.lower()
    if len(h) == 32:
        try:
            return base64.b32decode(h.upper()).hex()
        except Exception:  # noqa
            return None
    return None


def _bskip(d, i):
    c = d[i:i + 1]
    if c == b"i":
        return d.index(b"e", i) + 1
    if c in (b"l", b"d"):
        i += 1
        while d[i:i + 1] != b"e":
            i = _bskip(d, i)
        return i + 1
    j = d.index(b":", i)
    return j + 1 + int(d[i:j])


def torrent_file_hash(d):
    """infohash из .torrent: sha1 от bencode-словаря 'info'."""
    import hashlib
    try:
        i = 1
        while d[i:i + 1] != b"e":
            j = d.index(b":", i)
            n = int(d[i:j])
            key = d[j + 1:j + 1 + n]
            v = j + 1 + n
            e = _bskip(d, v)
            if key == b"info":
                return hashlib.sha1(d[v:e]).hexdigest()
            i = e
    except (ValueError, IndexError):
        pass
    return None


_qb_pref_dir = [None]


def qb_add(body):
    s = cfg()
    seq = bool(body.get("sequential") or body.get("watch"))
    fields = {"sequentialDownload": "true" if seq else "false",
              "firstLastPiecePrio": "true" if seq else "false"}
    d = (s.getSetting("tr_dir") or "").rstrip("/") or qbctl.DEFAULT_DL
    fields["savepath"] = d
    if _qb_pref_dir[0] != d:  # заодно делаем эту папку стандартной в самом qBittorrent (для торрентов, добавленных из его веб-интерфейса)
        try:
            qb("app/setPreferences", {"json": json.dumps({"save_path": d})})
            _qb_pref_dir[0] = d
        except Exception:  # noqa
            pass
    pick = bool(body.get("pick")) and not body.get("watch")
    if pick:  # остановиться, как только известен список файлов — дальше пользователь выбирает, что качать
        fields["stopCondition"] = "MetadataReceived"
    h = None
    before = set()
    if body.get("url"):
        url = body["url"].strip()
        h = magnet_hash(url)
        if not h:
            try:
                before = {t["id"] for t in qb_list()}
            except RuntimeError:
                pass
        fields["urls"] = url
        code, resp = qb("torrents/add", fields, {})
    elif body.get("file_b64"):
        raw = base64.b64decode(body["file_b64"])
        h = torrent_file_hash(raw)
        code, resp = qb("torrents/add", fields, {"torrents": ("file.torrent", raw)})
    else:
        raise ValueError("нужна magnet-ссылка, URL или .torrent файл")
    if code != 200 or resp.strip().lower().startswith(b"fails"):
        raise RuntimeError("qBittorrent не принял торрент (код %s)" % code)
    if body.get("watch") or pick:
        if not h:  # ссылка на .torrent: ищем новую запись в списке
            for _ in range(20):
                time.sleep(1)
                new = [t["id"] for t in qb_list() if t["id"] not in before]
                if new:
                    h = new[0]
                    break
        if not h:
            raise RuntimeError("Не удалось определить торрент — найдите его в списке закачек (кнопка «📂 Файлы»)")
        if body.get("watch"):
            watch_start(h)
    return h


def qb_files(h):
    """Список файлов торрента: готов ли он (метаданные получены), имя, файлы с приоритетами и прогрессом."""
    info = qb_info(h)
    if not info:
        raise ValueError("торрент не найден")
    st = info.get("state", "")
    files = []
    code, body = qb_get("torrents/files", hash=h)
    if code == 200:
        try:
            for i, f in enumerate(json.loads(body.decode())):
                files.append({"i": i, "name": f.get("name", ""), "size": f.get("size", 0),
                              "prio": f.get("priority", 1), "pc": f.get("progress", 0)})
        except ValueError:
            files = []
    ready = bool(files) and st not in ("metaDL", "forcedMetaDL")
    return {"ready": ready, "hash": h, "name": info.get("name", ""), "state": qb_state(st), "files": files}


def qb_select(body):
    """Применить выбор файлов: невыбранным ставим приоритет 0 (не качать); для нового торрента — запустить."""
    h = str(body.get("hash", ""))
    sel = {int(x) for x in body.get("files", [])}
    if not h or not sel:
        raise ValueError("Выберите хотя бы один файл")
    files = qb_files(h)["files"]
    if not files:
        raise ValueError("список файлов ещё не получен")
    off = [str(f["i"]) for f in files if f["i"] not in sel]
    on = [str(f["i"]) for f in files if f["i"] in sel and f["prio"] == 0]
    if off:
        qb("torrents/filePrio", {"hash": h, "id": "|".join(off), "priority": "0"})
    if on:
        qb("torrents/filePrio", {"hash": h, "id": "|".join(on), "priority": "1"})
    if body.get("start"):
        qb_action({"id": h, "action": "start"})
    return {"ok": True, "selected": len(sel), "total": len(files)}


def qb_get(path, **params):
    return qb(path + "?" + urllib.parse.urlencode(params))


def qb_info(h):
    code, body = qb_get("torrents/info", hashes=h)
    try:
        return json.loads(body.decode())[0] if code == 200 else {}
    except (ValueError, IndexError):
        return {}


def qb_set_seq(h, on):
    """sequential — качать куски по порядку; first/last — сначала первые и последние куски (заголовок и индекс видео).
    Оба флага ставим в одно значение явно: toggle по отдельности мог бы их рассинхронизировать."""
    info = qb_info(h)
    if bool(info.get("seq_dl", False)) != on:
        qb("torrents/toggleSequentialDownload", {"hashes": h})
    if bool(info.get("f_l_piece_prio", False)) != on:
        qb("torrents/toggleFirstLastPiecePrio", {"hashes": h})


def qb_action(body):
    h = str(body.get("id", ""))
    act = body.get("action")
    if not h:
        raise ValueError("нет id")
    if act in ("stop", "start"):
        new, old = ("stop", "pause") if act == "stop" else ("start", "resume")
        code, _ = qb("torrents/" + new, {"hashes": h})
        if code == 404:  # qBittorrent 4.x
            qb("torrents/" + old, {"hashes": h})
    elif act == "remove":
        qb("torrents/delete", {"hashes": h, "deleteFiles": "true" if body.get("delete_data") else "false"})
    elif act == "seq":
        qb_set_seq(h, not qb_info(h).get("seq_dl", False))
    elif act == "watch":
        watch_start(h)
    elif act == "recheck":
        # пересчитать хеши уже скачанных кусков (после ошибки диска/«missing files»), затем снова запустить
        code, resp = qb("torrents/recheck", {"hashes": h})
        if code != 200:
            raise RuntimeError("qBittorrent не смог запустить проверку (код %s)" % code)
        log("torrent recheck: %s" % h[:8])
        new, old = ("start", "resume")
        code, _ = qb("torrents/" + new, {"hashes": h})
        if code == 404:  # qBittorrent 4.x
            qb("torrents/" + old, {"hashes": h})
    else:
        raise ValueError("unknown action")


# ---------- dispatch ----------
def torrents_list():
    be = backend()
    return {"backend": be, "seq_supported": be == "qbittorrent",
            "seq_default": cfg().getSetting("seq_default") != "false",
            "torrents": qb_list() if be == "qbittorrent" else tr_list()}


def torrents_add(body):
    if backend() != "qbittorrent":
        if body.get("watch"):
            raise ValueError("Просмотр во время загрузки работает только с qBittorrent")
        tr_add(body)
    else:
        return {"ok": True, "hash": qb_add(body)}
    return {"ok": True}


def torrents_action(body):
    if backend() != "qbittorrent" and body.get("action") == "watch":
        raise ValueError("Просмотр во время загрузки работает только с qBittorrent")
    (qb_action if backend() == "qbittorrent" else tr_action)(body)
    return {"ok": True}


# ---------- запуск, очередь, история ----------
META = {}  # адрес, отданный Kodi -> {"id", "name", "kind"}
_hist_lock = threading.Lock()
HIST_MAX = 30


def _active():
    r = rpc("Player.GetActivePlayers").get("result")
    return r if isinstance(r, list) else []


def start_item(target, name, kind, pid="", mode="play", resume=0):
    """mode: play — сразу играть; queue — в конец очереди (если ничего не играет — играть);
    next — следующим; add — просто добавить в конец."""
    META[target] = {"id": pid, "name": name, "kind": kind}
    if kind == "photo":
        xbmc.executebuiltin('ShowPicture("%s")' % target)
        return
    plid = 0 if kind == "music" else 1
    item = {"file": target}
    act = _active()
    if mode == "add" or (mode in ("queue", "next") and act):
        if mode == "next" and act:
            pos = rpc("Player.GetProperties", {"playerid": act[0]["playerid"], "properties": ["position"]}
                      ).get("result", {}).get("position", -1)
            rpc("Playlist.Insert", {"playlistid": plid, "position": pos + 1, "item": item})
        else:
            rpc("Playlist.Add", {"playlistid": plid, "item": item})
        return
    rpc("Playlist.Clear", {"playlistid": plid})
    rpc("Playlist.Add", {"playlistid": plid, "item": item})
    rpc("Player.Open", {"item": {"playlistid": plid, "position": 0}})
    if resume > 5:
        threading.Thread(target=_seek_when_started, args=(target, resume), daemon=True).start()


def _seek_when_started(target, sec):
    for _ in range(50):
        time.sleep(0.5)
        act = _active()
        if not act:
            continue
        pid = act[0]["playerid"]
        f = rpc("Player.GetItem", {"playerid": pid}).get("result", {}).get("item", {}).get("file")
        pr = rpc("Player.GetProperties", {"playerid": pid, "properties": ["totaltime"]}).get("result", {})
        if f == target and to_sec(pr.get("totaltime")) > 0:
            rpc("Player.Seek", {"playerid": pid, "value": {"time": from_sec(sec)}})
            return


def hist_load():
    try:
        with open(os.path.join(data_dir(), "history.json"), encoding="utf-8") as f:
            return json.load(f)
    except Exception:  # noqa
        return []


def hist_save(lst):
    try:
        with open(os.path.join(data_dir(), "history.json"), "w", encoding="utf-8") as f:
            json.dump(lst[:HIST_MAX], f, ensure_ascii=False)
    except OSError as e:
        log("history save failed: %s" % e)


def hist_get(key):
    with _hist_lock:
        return next((e for e in hist_load() if e.get("key") == key), None)


def hist_remove(key):
    with _hist_lock:
        hist_save([e for e in hist_load() if e.get("key") != key])
    return {"ok": True}


def hist_list():
    with _hist_lock:
        lst = sorted(hist_load(), key=lambda e: -e.get("ts", 0))
    try:
        lib = lib_meta()
    except Exception:  # noqa
        lib = {}
    cat = {}
    want = {e.get("key") for e in lst}
    for it in CAT["items"]:
        if it.get("p") in want:
            cat[it["p"]] = it
    tok = urllib.parse.quote(STREAM_TOKEN, safe="")
    out = []
    for e in lst:
        key = e["key"]
        name = e.get("name", "")
        meta = lib.get(name.lower()) or {}
        art = ""
        if meta.get("art"):
            art = "l:" + meta["art"]
        elif cat.get(key, {}).get("a"):
            art = "f:" + cat[key]["a"]
        out.append({"key": key, "name": name, "title": meta.get("title", ""), "pos": e.get("pos", 0),
                    "total": e.get("total", 0), "ts": e.get("ts", 0), "browsable": bool(e.get("id")),
                    "art": "/api/art?r=%s&t=%s" % (urllib.parse.quote(art, safe=""), tok) if art else "",
                    "thumb": "/api/thumb?key=" + urllib.parse.quote(key, safe="")})
    return {"items": out}


def track_once():
    act = _active()
    if not act:
        return
    pid = act[0]["playerid"]
    f = rpc("Player.GetItem", {"playerid": pid}).get("result", {}).get("item", {}).get("file")
    m = META.get(f)
    if not m or m["kind"] != "video":
        return
    pr = rpc("Player.GetProperties", {"playerid": pid, "properties": ["time", "totaltime"]}).get("result", {})
    pos, total = to_sec(pr.get("time")), to_sec(pr.get("totaltime"))
    if total <= 0:
        return
    key = m["id"] or f
    with _hist_lock:
        lst = [e for e in hist_load() if e.get("key") != key]
        if pos < total * 0.95 and total - pos > 45 and pos >= 30:
            lst.insert(0, {"key": key, "id": m["id"], "target": "" if m["id"] else f, "name": m["name"],
                           "pos": pos, "total": total, "ts": time.time()})
        hist_save(lst)


def tracker(monitor):
    while not monitor.abortRequested():
        if monitor.waitForAbort(5):
            break
        try:
            track_once()
        except Exception as e:  # noqa
            log("tracker error: %r" % e)
        try:
            phist_tick()
        except Exception as e:  # noqa
            log("playhist error: %r" % e, ev=False)


def api_play(body):
    mode = body.get("mode") or "play"
    key = body.get("key")
    resume = 0
    if key:  # из «Продолжить просмотр»
        e = hist_get(key)
        if not e:
            raise ValueError("запись истории не найдена")
        if e.get("id"):
            target, name, kind = target_for(e["id"])
            pid = e["id"]
        else:
            target, name, kind, pid = e["target"], e.get("name", ""), "video", ""
            if not os.path.isfile(target):
                raise ValueError("файл больше не существует")
        resume = max(0, e.get("pos", 0) - 5)
    else:
        pid = body.get("path", "")
        target, name, kind = target_for(pid)
        if body.get("resume"):
            e = hist_get(pid)
            resume = max(0, e.get("pos", 0) - 5) if e else 0
    start_item(target, name, kind, pid, mode, resume)


_qadd_lock = threading.Lock()


def _bg_add(adds):
    """Остальные файлы добавляем в фоне пачками, чтобы не держать запрос и не заваливать Kodi сотнями вызовов."""
    with _qadd_lock:
        for i in range(0, len(adds), 40):
            rpc_batch([("Playlist.Add", {"playlistid": plid, "item": {"file": f}}) for plid, f in adds[i:i + 40]])
            time.sleep(0.15)  # даём Kodi и плееру подышать
        log("queue: добавлено в фоне %d" % len(adds))


def queue_add(body):
    paths = [p for p in (body.get("paths") or [])][:300]
    if not paths:
        raise ValueError("нет файлов")
    if body.get("replace"):  # «играть всю папку»: останавливаем текущее и очищаем списки
        QLAST["ts"] = 0.0
        if _active():
            rpc("Player.Stop", {"playerid": _active()[0]["playerid"]})
            time.sleep(0.4)
        for n in (0, 1):
            rpc("Playlist.Clear", {"playlistid": n})
    first = True
    rest = []
    for p in paths:
        target, name, kind = target_for(p)
        if kind == "photo":
            continue
        if first or len(paths) == 1:
            start_item(target, name, kind, p, body.get("mode", "queue") if len(paths) == 1 else "queue")
            first = False
        else:
            META[target] = {"id": p, "name": name, "kind": kind}
            rest.append((0 if kind == "music" else 1, target))
    if rest:
        threading.Thread(target=_bg_add, args=(rest,), daemon=True).start()


QLAST = {"plid": None, "pos": -1, "ts": 0.0}  # последняя достоверно известная позиция в очереди
QSTICKY = 12.0  # сек: столько держим подсветку, если Kodi на миг перестал отвечать (старт 4K/DoVi, смена частоты)


def _plid():
    """Какой список считаем «очередью»: у играющего плеера — его; иначе непустой (видео, затем музыка)."""
    act = _active()
    if act:
        return act[0]["playerid"]
    if QLAST["plid"] is not None and time.time() - QLAST["ts"] < QSTICKY:
        return QLAST["plid"]
    for n in (1, 0):
        r = rpc("Playlist.GetProperties", {"playlistid": n, "properties": ["size"]}).get("result") or {}
        if r.get("size", 0) > 0:
            return n
    return 1


def queue_state():
    act = _active()
    plid = _plid()
    r = rpc("Playlist.GetItems", {"playlistid": plid, "properties": ["file", "title"]}).get("result", {})
    pos, shuffled, repeat = -1, False, "off"
    items = r.get("items") or []
    if act:
        pr = rpc("Player.GetProperties", {"playerid": plid, "properties": ["position", "shuffled", "repeat"]}
                 ).get("result", {})
        p = pr.get("position")
        pos, shuffled, repeat = (p if isinstance(p, int) else -1), bool(pr.get("shuffled")), pr.get("repeat") or "off"
        if not (0 <= pos < len(items)):
            # Kodi не отдал позицию (бывает при открытии тяжёлого файла) — ищем играющий файл в списке по адресу
            cf = (rpc("Player.GetItem", {"playerid": plid, "properties": ["file"]}).get("result", {})
                  .get("item", {}) or {}).get("file")
            pos = next((i for i, it in enumerate(items) if cf and it.get("file") == cf), -1)
        if 0 <= pos < len(items):
            QLAST.update(plid=plid, pos=pos, ts=time.time())
    playing = bool(act)
    if not (playing and 0 <= pos < len(items)) and QLAST["plid"] == plid and \
            time.time() - QLAST["ts"] < QSTICKY and 0 <= QLAST["pos"] < len(items):
        pos, playing = QLAST["pos"], True  # держим рамку на последнем известном элементе, пока Kodi «занят»
    out = []
    for n, it in enumerate(items):
        f = it.get("file", "")
        name = (META.get(f) or {}).get("name") or it.get("title") or it.get("label") or \
            urllib.parse.unquote(posixpath.basename(f.split("?")[0]))
        out.append({"pos": n, "name": name})
    return {"playlistid": plid, "position": pos, "playing": playing, "items": out,
            "shuffled": shuffled, "repeat": repeat}


QGO = {"gen": 0}


def _cur_pos(plid):
    act = _active()
    if not act:
        return None
    return rpc("Player.GetProperties", {"playerid": act[0]["playerid"], "properties": ["position"]}
               ).get("result", {}).get("position")


def _goto_job(gen, plid, pos):
    """Переход на нужный элемент очереди. Kodi при заранее подготовленном «следующем» треке (gapless) иногда
    после GoTo включает не тот элемент — поэтому проверяем позицию и при ошибке повторяем (в конце — Stop + Open)."""
    for attempt in range(3):
        if gen != QGO["gen"]:
            return  # пользователь нажал другой элемент — актуален только последний выбор
        players = _active()
        if attempt < 2 and players:
            rpc("Player.GoTo", {"playerid": players[0]["playerid"], "to": pos})
        else:
            if players:
                rpc("Player.Stop", {"playerid": players[0]["playerid"]})
                for _ in range(10):
                    if not _active():
                        break
                    time.sleep(0.2)
            rpc("Player.Open", {"item": {"playlistid": plid, "position": pos}})
        end = time.time() + (4.0 if attempt == 0 else 3.0)  # тяжёлые файлы (4K DoVi) открываются дольше
        while time.time() < end:
            time.sleep(0.25)
            if gen != QGO["gen"]:
                return
            if _cur_pos(plid) == pos:
                time.sleep(0.4)  # убедимся, что Kodi не переключил на подготовленный следующий трек
                if _cur_pos(plid) == pos:
                    return
                break
        log("queue goto: wanted %d, got %s, retry %d" % (pos, _cur_pos(plid), attempt + 1))


def queue_action(body):
    act = body.get("action")
    plid = _plid()
    players = _active()
    pos = int(body.get("pos", 0))
    if act == "goto":
        QLAST.update(plid=plid, pos=pos, ts=time.time())  # рамка сразу переезжает на выбранный элемент
        QGO["gen"] += 1
        threading.Thread(target=_goto_job, args=(QGO["gen"], plid, pos), daemon=True).start()
    elif act in ("next", "prev"):
        if players:
            rpc("Player.GoTo", {"playerid": plid, "to": "next" if act == "next" else "previous"})
    elif act == "remove":
        rpc("Playlist.Remove", {"playlistid": plid, "position": pos})
    elif act == "clear":
        QLAST["ts"] = 0.0
        rpc("Playlist.Clear", {"playlistid": plid})
    elif act == "move":
        queue_move(plid, int(body.get("from", -1)), int(body.get("to", -1)))
    elif act == "shuffle":
        if not players:
            raise ValueError("Перемешивание работает, пока что-то играет")
        rpc("Player.SetShuffle", {"playerid": players[0]["playerid"], "shuffle": "toggle"})
    elif act == "repeat":
        if not players:
            raise ValueError("Повтор работает, пока что-то играет")
        rpc("Player.SetRepeat", {"playerid": players[0]["playerid"], "repeat": "cycle"})  # выкл → всё → один
    else:
        raise ValueError("unknown action")


def queue_move(plid, a, b):
    """Перенос элемента очереди с позиции a на позицию b цепочкой обменов соседних (Kodi сам ведёт «текущий» элемент)."""
    n = (rpc("Playlist.GetProperties", {"playlistid": plid, "properties": ["size"]}).get("result") or {}).get("size", 0)
    if not (0 <= a < n and 0 <= b < n):
        raise ValueError("позиция вне очереди")
    if a == b:
        return
    step = 1 if b > a else -1
    rpc_batch([("Playlist.Swap", {"playlistid": plid, "position1": i, "position2": i + step})
               for i in range(a, b, step)])


# ---------- сохранённые плейлисты (очередь → плейлист → очередь) ----------
_pl_lock = threading.Lock()
PL_FILE = "saved_playlists.json"


def _pl_load():
    try:
        with open(os.path.join(data_dir(), PL_FILE), encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:  # noqa
        return {}


def _pl_save(d):
    tmp = os.path.join(data_dir(), PL_FILE + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False)
    os.replace(tmp, os.path.join(data_dir(), PL_FILE))


def _item_ref(f, title):
    """Как запомнить элемент очереди. id из браузера файлов надёжнее адреса: адрес FTP-ретранслятора меняется при перезапуске."""
    m = META.get(f) or {}
    if m.get("id"):
        return {"id": m["id"], "name": m.get("name") or title}
    if "/stream/" in f and "id=" in f:
        pid = urllib.parse.parse_qs(urllib.parse.urlparse(f).query).get("id", [""])[0]
        if pid:
            return {"id": pid, "name": title}
    return {"file": f, "name": m.get("name") or title}


def _queue_refs():
    plid = _plid()
    r = rpc("Playlist.GetItems", {"playlistid": plid, "properties": ["file", "title"]}).get("result", {})
    refs = []
    for it in r.get("items") or []:
        f = it.get("file", "")
        if f:
            refs.append(_item_ref(f, it.get("title") or it.get("label") or
                                  urllib.parse.unquote(posixpath.basename(f.split("?")[0]))))
    return plid, refs


def playlist_get(name):
    with _pl_lock:
        pl = _pl_load().get(name)
    if not pl:
        raise ValueError("плейлист не найден")
    items = [{"idx": i, "name": e.get("name") or e.get("id") or e.get("file") or "?"}
             for i, e in enumerate(pl.get("items", []))]
    return {"name": name, "kind": pl.get("kind", "video"), "items": items}


def playlist_edit(body):
    """Правка сохранённого плейлиста: remove / move / add (файлы из браузера файлов) / add_queue / rename."""
    name = str(body.get("name", ""))
    act = body.get("action")
    new_refs, new_kind = [], None
    if act == "add":
        for p in (body.get("paths") or [])[:300]:
            try:
                _t, nm, kind = target_for(p)
            except Exception:  # noqa
                continue
            if kind == "photo":
                continue
            new_refs.append({"id": p, "name": nm})
            new_kind = new_kind or kind
        if not new_refs:
            raise ValueError("нечего добавлять")
    elif act == "add_queue":
        plid, new_refs = _queue_refs()
        new_kind = "music" if plid == 0 else "video"
        if not new_refs:
            raise ValueError("Очередь пуста — добавлять нечего")
    with _pl_lock:
        d = _pl_load()
        pl = d.get(name)
        if not pl:
            raise ValueError("плейлист не найден")
        items = pl.setdefault("items", [])
        if act == "remove":
            i = int(body.get("idx", -1))
            if not 0 <= i < len(items):
                raise ValueError("нет такого элемента")
            del items[i]
        elif act == "move":
            a, b = int(body.get("from", -1)), int(body.get("to", -1))
            if not (0 <= a < len(items) and 0 <= b < len(items)):
                raise ValueError("позиция вне плейлиста")
            items.insert(b, items.pop(a))
        elif act in ("add", "add_queue"):
            if not items and new_kind:
                pl["kind"] = "music" if new_kind == "music" else "video"
            items.extend(new_refs)
        elif act == "rename":
            nn = " ".join(str(body.get("new_name", "")).split())[:60]
            if not nn:
                raise ValueError("Введите название плейлиста")
            if nn != name:
                if nn in d:
                    raise ValueError("Плейлист с таким именем уже есть")
                d[nn] = d.pop(name)
                name = nn
        else:
            raise ValueError("unknown action")
        _pl_save(d)
    return {"ok": True, "name": name, "count": len(items)}


def playlists_list():
    with _pl_lock:
        d = _pl_load()
    items = [{"name": k, "count": len(v.get("items", [])), "kind": v.get("kind", "video"), "ts": v.get("ts", 0)}
             for k, v in d.items()]
    items.sort(key=lambda x: -x["ts"])
    return {"items": items}


def playlist_save(body):
    name = " ".join(str(body.get("name", "")).split())[:60]
    if not name:
        raise ValueError("Введите название плейлиста")
    plid, refs = _queue_refs()
    if not refs:
        raise ValueError("Очередь пуста — сохранять нечего")
    with _pl_lock:
        d = _pl_load()
        d[name] = {"kind": "music" if plid == 0 else "video", "ts": time.time(), "items": refs}
        _pl_save(d)
    log("playlist saved: %s (%d)" % (name, len(refs)), ev=False)
    return {"ok": True, "name": name, "count": len(refs)}


def playlist_delete(body):
    with _pl_lock:
        d = _pl_load()
        d.pop(str(body.get("name", "")), None)
        _pl_save(d)
    return {"ok": True}


def playlist_load(body):
    """mode: replace — заменить очередь и играть; add — добавить в конец текущей."""
    name = str(body.get("name", ""))
    with _pl_lock:
        pl = _pl_load().get(name)
    if not pl:
        raise ValueError("плейлист не найден")
    resolved, skipped = [], 0
    for e in pl.get("items", []):
        try:
            if e.get("id"):
                target, nm, kind = target_for(e["id"])
                resolved.append((e["id"], target, e.get("name") or nm, kind))
            else:
                f = e["file"]
                nm = e.get("name") or posixpath.basename(f)
                resolved.append(("", f, nm, kind_of(nm) if pl.get("kind") != "music" else "music"))
        except Exception:  # noqa
            skipped += 1
    if not resolved:
        raise ValueError("файлы плейлиста больше недоступны")
    replace = body.get("mode", "replace") == "replace"
    if replace:
        QLAST["ts"] = 0.0
        if _active():
            rpc("Player.Stop", {"playerid": _active()[0]["playerid"]})
            time.sleep(0.4)
        for n in (0, 1):
            rpc("Playlist.Clear", {"playlistid": n})
    rest = []
    for i, (pid, target, nm, kind) in enumerate(resolved):
        if i == 0:
            start_item(target, nm, kind, pid, "play" if replace else "queue")
        else:
            META[target] = {"id": pid, "name": nm, "kind": kind}
            rest.append((0 if kind == "music" else 1, target))
    if rest:
        threading.Thread(target=_bg_add, args=(rest,), daemon=True).start()
    return {"ok": True, "count": len(resolved), "skipped": skipped}


# ---------- терминал и отправка логов ----------
SHELL_MAX_OUT = 200000
PASTE_PRESETS = {
    "dmesg": "dmesg",
    "kodi": "cat /storage/.kodi/temp/kodi.log",
    "journal": "journalctl -b --no-pager | tail -n 3000",
}
_URL_RX = re.compile(r"https?://\S+")


def _shell_env():
    e = dict(os.environ)
    e["PATH"] = "/opt/bin:/opt/sbin:" + e.get("PATH", "") + ":/usr/sbin:/sbin:/usr/bin:/bin"
    e["LD_LIBRARY_PATH"] = e.get("LD_LIBRARY_PATH", "")
    return e


def _shell(cmd, timeout):
    try:
        r = subprocess.run(["sh", "-c", cmd], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                           timeout=timeout, cwd="/storage" if os.path.isdir("/storage") else None, env=_shell_env())
        out = r.stdout.decode("utf-8", "replace")
        return r.returncode, out[-SHELL_MAX_OUT:], len(out) > SHELL_MAX_OUT
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or b"").decode("utf-8", "replace") if isinstance(e.stdout, bytes) else (e.stdout or "")
        return 124, out[-SHELL_MAX_OUT:] + "\n[прервано по таймауту %d с]" % timeout, False


RUN_VERSION = ""
try:
    RUN_VERSION = xbmcaddon.Addon(ADDON_ID).getAddonInfo("version")
except Exception:  # noqa
    pass


def shell_state():
    return {"enabled": (cfg().getSetting("shell_enabled") or "false") == "true", "version": RUN_VERSION}


_tl = threading.local()


def shell_gate():
    """Терминал включается только в настройках Kodi на приставке (физический доступ), не со страницы."""
    if not getattr(_tl, "local", True) and (cfg().getSetting("remote_shell") or "false") != "true":
        raise ValueError("Терминал из интернета выключен: включите «Allow terminal from the internet» в настройках Phone Remote на приставке")
    if (cfg().getSetting("shell_enabled") or "false") != "true":
        raise ValueError("Терминал выключен: включите «Allow shell commands» в настройках Phone Remote на приставке")


def shell_run(body):
    """Команда оболочки с телефона — только если включено в настройках Kodi."""
    shell_gate()
    cmd = str(body.get("cmd", "")).strip()
    if not cmd:
        raise ValueError("пустая команда")
    timeout = max(1, min(int(body.get("timeout") or 30), 120))
    ev_add("shell: " + cmd[:200], "info", "system")
    rc, out, cut = _shell(cmd, timeout)
    return {"rc": rc, "out": out, "cut": cut}


# ---- интерактивный терминал (сессия оболочки root на приставке; как SSH, но без пароля — аддон уже на приставке) ----
TERM_S = {}
_term_lock = threading.Lock()
TERM_KEEP = 200000
TERM_IDLE = 600


def _term_reader(t):
    dec = codecs.getincrementaldecoder("utf-8")(errors="replace")
    while True:
        try:
            r, _, _ = select.select([t["fd"]], [], [], 1.0)
        except (OSError, ValueError):
            break
        if time.time() - t["used"] > TERM_IDLE:
            try:
                os.kill(t["pid"], signal.SIGHUP)
            except OSError:
                pass
        if not r:
            continue
        try:
            raw = os.read(t["fd"], 4096)
        except OSError:
            break
        if not raw:
            break
        txt = dec.decode(raw)
        with t["cv"]:
            t["text"] += txt
            if len(t["text"]) > TERM_KEEP:
                cut = len(t["text"]) - TERM_KEEP
                t["text"] = t["text"][cut:]
                t["base"] += cut
            t["cv"].notify_all()
    with t["cv"]:
        t["alive"] = False
        t["cv"].notify_all()
    try:
        t["proc"].wait(timeout=5)
    except Exception:  # noqa
        pass
    try:
        os.close(t["fd"])
    except OSError:
        pass


def _setsid_ctty():
    """Поддерживает ли setsid ключ -c (сделать tty управляющим терминалом — нужно для Ctrl+C и для ssh)."""
    try:
        r = subprocess.run(["setsid", "--help"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=4)
        return b"-c" in r.stdout
    except Exception:  # noqa
        return False


def term_open(body):
    """Сессия оболочки root на приставке. В Kodi аддон работает в суб-интерпретаторе Python, где os.fork/pty.fork
    запрещены, поэтому процесс запускается через subprocess (без fork) и подключается к pty."""
    shell_gate()
    if pty is None or fcntl is None or termios is None:
        raise ValueError("Терминал недоступен на этой системе (нужен Linux: CoreELEC, LibreELEC, Android)")
    term_close({})
    cols = max(30, min(int(body.get("cols") or 50), 200))
    rows = max(10, min(int(body.get("rows") or 24), 80))
    home = "/storage" if os.path.isdir("/storage") else "/"
    env = _shell_env()
    env.update(TERM="xterm", HOME=home, LANG="C.UTF-8")
    master, slave = pty.openpty()
    fcntl.ioctl(master, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
    ctty = _setsid_ctty()
    try:
        if ctty:
            proc = subprocess.Popen(["setsid", "-c", "sh", "-l"], stdin=slave, stdout=slave, stderr=slave,
                                    cwd=home, env=env, close_fds=True)
        else:
            proc = subprocess.Popen(["sh", "-l"], stdin=slave, stdout=slave, stderr=slave,
                                    cwd=home, env=env, close_fds=True, start_new_session=True)
    except Exception:
        os.close(master)
        raise
    finally:
        os.close(slave)
    t = {"id": os.urandom(6).hex(), "pid": proc.pid, "proc": proc, "fd": master, "ctty": ctty, "text": "", "base": 0,
         "alive": True, "cv": threading.Condition(), "used": time.time()}
    with _term_lock:
        TERM_S["cur"] = t
    threading.Thread(target=_term_reader, args=(t,), daemon=True).start()
    ev_add("terminal: сессия открыта (ctty=%s)" % ctty, "info", "system")
    if body.get("mode") == "ssh":  # как в Termux: первая команда вводится сама, дальше — запрос пароля
        ip = get_ip() or "127.0.0.1"
        time.sleep(0.4)
        os.write(master, ("ssh -tt -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null root@%s\n" % ip).encode())
    return {"id": t["id"], "ctty": ctty}


def _term_get(tid):
    t = TERM_S.get("cur")
    if not t or t["id"] != tid:
        raise ValueError("сессия не найдена — подключитесь заново")
    return t


def term_read(tid, pos, wait):
    shell_gate()
    t = _term_get(tid)
    t["used"] = time.time()
    end = time.time() + max(0, min(wait, 25))
    with t["cv"]:
        while t["alive"] and t["base"] + len(t["text"]) <= pos and time.time() < end:
            t["cv"].wait(timeout=max(0.05, end - time.time()))
        start = max(0, pos - t["base"])
        data = t["text"][start:]
        return {"data": data, "pos": t["base"] + len(t["text"]), "alive": t["alive"] or bool(data)}


def _term_sigint(shell_pid):
    try:
        for d in os.listdir("/proc"):
            if d.isdigit():
                try:
                    with open("/proc/%s/stat" % d) as f:
                        ppid = int(f.read().rsplit(")", 1)[1].split()[1])
                except (OSError, ValueError, IndexError):
                    continue
                if ppid == shell_pid:
                    os.kill(int(d), signal.SIGINT)
    except OSError:
        pass


def term_write(body):
    shell_gate()
    t = _term_get(str(body.get("id", "")))
    t["used"] = time.time()
    data = str(body.get("data", ""))[:4000].encode("utf-8")
    if b"\x03" in data and not t.get("ctty"):
        _term_sigint(t["pid"])  # без управляющего терминала ядро само SIGINT не пошлёт
    os.write(t["fd"], data)
    return {"ok": True}


def term_close(body):
    t = TERM_S.pop("cur", None)
    if t:
        try:
            os.kill(t["pid"], signal.SIGHUP)
        except OSError:
            pass
    return {"ok": True}



def paste_log(body):
    """Отправляет лог на paste-сервис командой `<команда> | paste` и возвращает ссылку."""
    what = body.get("what", "dmesg")
    if what not in PASTE_PRESETS:
        raise ValueError("unknown log")
    ev_add("paste: " + what, "info", "system")
    rc, out, _ = _shell("%s 2>&1 | paste" % PASTE_PRESETS[what], 90)
    m = _URL_RX.search(out)
    if not m:
        raise RuntimeError("Команда paste не вернула ссылку (код %s): %s" % (rc, out.strip()[-300:] or "нет вывода — нет интернета или paste не установлен"))
    return {"url": m.group(0).strip(), "what": what}


# ---------- сводка о системе ----------
_net_prev = {}


def _read(p, default=""):
    try:
        with open(p, encoding="utf-8", errors="replace") as f:
            return f.read().strip()
    except OSError:
        return default


def _net_sample():
    best = None
    for ln in _read("/proc/net/dev").splitlines()[2:]:
        name, _, rest = ln.partition(":")
        name = name.strip()
        f = rest.split()
        if name == "lo" or name.startswith(("sit", "tun", "dummy", "docker", "veth", "bond", "ip6")) or len(f) < 10:
            continue
        rx, tx = int(f[0]), int(f[8])
        if best is None or rx + tx > best[1] + best[2]:
            best = (name, rx, tx)
    return best


def dv_profile():
    """Профиль Dolby Vision текущего видео — из kodi.log (строка CAMLCodec::OpenDecoder DOVI: ...)."""
    try:
        path = xbmcvfs.translatePath("special://logpath/kodi.log")
        with open(path, "rb") as f:
            f.seek(0, 2)
            f.seek(max(0, f.tell() - 600000))
            txt = f.read().decode("utf-8", "replace")
    except Exception:  # noqa
        return ""
    m = None
    for m in re.finditer(r"OpenDecoder DOVI: version ([\d.]+), profile (\d+)([^\n]*)", txt):
        pass
    if not m:
        return ""
    prof, tail = int(m.group(2)), m.group(3).lower()
    tail_all = txt[m.end():]
    el = ""
    if "full enhancement" in tail or "fel" in tail.split():
        el = "FEL"
    elif "minimal enhancement" in tail or "mel" in tail.split():
        el = "MEL"
    later = re.findall(r"enhancement layer now reported as (FEL|MEL)", tail_all)
    if later:
        el = later[-1]
    if prof == 0:
        return ""
    out = "Profile %d" % prof
    if prof == 7 and el:
        out += " " + el
    elif prof == 7:
        out += " (MEL/FEL не определён)"
    if "native CMv4.0 RPU detected" in txt[max(0, m.start() - 3000):] and prof in (7, 8):
        out += " · CMv4.0"
    return out


def sysinfo():
    out = {}
    temps = []
    for p in glob.glob("/sys/class/thermal/thermal_zone*/temp"):
        try:
            v = int(_read(p))
            temps.append(v / 1000.0 if abs(v) > 1000 else float(v))
        except ValueError:
            pass
    out["temp"] = round(max(temps), 1) if temps else None
    mem = {}
    for ln in _read("/proc/meminfo").splitlines():
        k, _, v = ln.partition(":")
        try:
            mem[k] = int(v.split()[0]) * 1024
        except (ValueError, IndexError):
            pass
    out["mem_total"], out["mem_free"] = mem.get("MemTotal"), mem.get("MemAvailable")
    try:
        out["uptime"] = int(float(_read("/proc/uptime").split()[0]))
    except (ValueError, IndexError):
        out["uptime"] = None
    try:
        out["load"] = [round(x, 2) for x in os.getloadavg()]
    except (OSError, AttributeError):
        out["load"] = None
    cands = [("/storage", "Внутренняя память")]
    for r in roots():
        if not is_url(r):
            cands.append((r, os.path.basename(r.rstrip("/")) or r))
    d = cfg().getSetting("tr_dir")
    if d:
        cands.append((d, os.path.basename(d.rstrip("/")) or d))
    for ln in _read("/proc/mounts").splitlines():
        parts = ln.split()
        if len(parts) > 1 and parts[1].startswith(("/media/", "/var/media/")):
            cands.append((parts[1], os.path.basename(parts[1])))
    disks, seen = [], set()
    for path, name in cands:
        try:
            st = os.stat(path)
            if st.st_dev in seen:
                continue
            if hasattr(os, "statvfs"):
                vs = os.statvfs(path)
                total, free = vs.f_blocks * vs.f_frsize, vs.f_bavail * vs.f_frsize
            else:  # Windows
                du = shutil.disk_usage(path)
                total, free = du.total, du.free
        except OSError:
            continue
        seen.add(st.st_dev)
        if total:
            disks.append({"name": name, "path": path, "total": total, "free": free})
    out["disks"] = disks
    net = _net_sample()
    rate = {"iface": net[0] if net else "", "rx": 0, "tx": 0, "speed": None}
    if net:
        now = time.time()
        prev = _net_prev.get("v")
        if prev and prev[1] == net[0] and now - prev[0] > 0.4:
            rate["rx"] = max(0, int((net[1] - prev[2]) / (now - prev[0])))
            rate["tx"] = max(0, int((net[2] - prev[3]) / (now - prev[0])))
        _net_prev["v"] = (now, net[0], net[1], net[2])
        try:
            sp = int(_read("/sys/class/net/%s/speed" % net[0]))
            rate["speed"] = sp if sp > 0 else None
        except ValueError:
            pass
    out["net"] = rate
    out["ip"] = get_ip()
    out["kodi"] = xbmc.getInfoLabel("System.BuildVersion")
    m = re.search(r'^PRETTY_NAME="?([^"\n]+)', _read("/etc/os-release"), re.M)
    out["os"] = m.group(1) if m else ""
    out["screen"] = xbmc.getInfoLabel("System.ScreenMode")
    if xbmc.getCondVisibility("Player.HasVideo"):
        g = xbmc.getInfoLabel
        out["video"] = {"res": g("VideoPlayer.VideoResolution"), "codec": g("VideoPlayer.VideoCodec"),
                        "hdr": g("VideoPlayer.HdrType"),
                        "dv": dv_profile() if "dolby" in g("VideoPlayer.HdrType").lower() else "",
                        "audio": (g("VideoPlayer.AudioCodec") + " " + g("VideoPlayer.AudioChannels")).strip()}
    return out


# ---------- торрент + просмотр во время загрузки ----------
WATCH = {"state": "idle", "gen": 0}
_watch_lock = threading.Lock()
MB = 1024 * 1024


def watch_state():
    s = dict(WATCH)
    s["age"] = int(time.time() - s.get("ts", time.time()))
    return s


def watch_cancel():
    with _watch_lock:
        WATCH["gen"] += 1
        WATCH.update(state="idle", msg="")
    return {"ok": True}


def watch_start(h):
    with _watch_lock:
        WATCH["gen"] += 1
        gen = WATCH["gen"]
        WATCH.update(state="metadata", msg="Получение данных торрента…", pct=0, ts=time.time(), hash=h, name="")
    threading.Thread(target=_watch_job, args=(gen, h), daemon=True).start()


def _watch_job(gen, h):
    def alive():
        return WATCH.get("gen") == gen

    def st(**kw):
        if alive():
            kw["ts"] = time.time() if kw.get("state") in ("playing", "failed") else WATCH.get("ts", time.time())
            WATCH.update(kw)

    try:
        files, t0 = None, time.time()
        while alive() and time.time() - t0 < 240:
            code, body = qb_get("torrents/files", hash=h)
            if code == 200:
                try:
                    files = json.loads(body.decode())
                except ValueError:
                    files = None
                if files:
                    break
            time.sleep(2)
        if not alive():
            return
        if not files:
            return st(state="failed", msg="Не удалось получить список файлов (нет источников?)")
        vids = [(i, f) for i, f in enumerate(files) if os.path.splitext(f["name"])[1].lower() in VIDEO_EXT]
        if not vids:
            return st(state="failed", msg="В торренте нет видеофайлов")
        mx = max(f["size"] for _, f in vids)
        idx, f = next((i, f) for i, f in vids if f["size"] >= mx * 0.5)
        if len(files) > 1:  # качаем только выбранный файл — всё, что есть, уходит на него
            others = "|".join(str(i) for i in range(len(files)) if i != idx)
            qb("torrents/filePrio", {"hash": h, "id": others, "priority": "0"})
            qb("torrents/filePrio", {"hash": h, "id": str(idx), "priority": "1"})
        qb_set_seq(h, True)
        code, body = qb_get("torrents/properties", hash=h)
        props = json.loads(body.decode()) if code == 200 else {}
        piece = int(props.get("piece_size") or 0)
        save = props.get("save_path", "")
        fname = os.path.basename(f["name"])
        size = int(f["size"])
        try:
            buf_mb = int(cfg().getSetting("watch_buffer_mb") or 150)
        except ValueError:
            buf_mb = 150
        need = max(10 * MB, min(buf_mb * MB, int(size * 0.9)))
        st(state="buffering", name=fname, msg="Буферизация…", pct=0, need=need)
        best, last_move, ok_since = -1, time.time(), None
        while alive():
            code, body = qb_get("torrents/files", hash=h)
            cur = json.loads(body.decode())[idx] if code == 200 else f
            rng = cur.get("piece_range")
            buffered, last_ok = None, False
            if rng and piece:
                code2, b2 = qb_get("torrents/pieceStates", hash=h)
                if code2 == 200:
                    ps = json.loads(b2.decode())
                    n = 0
                    for v in ps[rng[0]:rng[1] + 1]:
                        if v != 2:
                            break
                        n += 1
                    buffered = min(size, n * piece)
                    last_ok = ps[rng[1]] == 2
            if buffered is None:  # старый qBittorrent: считаем по прогрессу (при последовательной загрузке это префикс)
                buffered = int(cur.get("progress", 0) * size)
                last_ok = cur.get("progress", 0) >= 1
            if buffered > best:
                best, last_move = buffered, time.time()
            done = cur.get("progress", 0) >= 1
            if buffered >= need and ok_since is None:
                ok_since = time.time()
            speed = qb_info(h).get("dlspeed", 0)
            st(state="buffering", pct=min(100, int(buffered * 100 / need)), buffered=buffered, need=need,
               speed=speed, msg="Буферизация…")
            if done or (ok_since and (last_ok or time.time() - ok_since > 60)):
                break
            if time.time() - last_move > 600:
                return st(state="failed", msg="Загрузка не идёт 10 минут (нет источников?)")
            time.sleep(2)
        if not alive():
            return
        path = os.path.join(save, f["name"])
        if not os.path.isfile(path) and os.path.isfile(path + ".!qB"):
            path += ".!qB"
        if not os.path.isfile(path):
            return st(state="failed", msg="Файл не найден: %s (qBittorrent сохраняет в другое место?)" % path)
        start_item(path, fname, "video", "", "play")
        st(state="playing", msg="Запущено", pct=100)
    except Exception as e:  # noqa
        log("watch job failed: %r" % e)
        st(state="failed", msg=str(e)[:200] or "ошибка")


# ---------- wake on lan ----------
def data_dir():
    try:
        import xbmcvfs
        d = xbmcvfs.translatePath(cfg().getAddonInfo("profile"))
    except Exception:  # noqa
        d = "/storage/.kodi/userdata/addon_data/" + ADDON_ID
    os.makedirs(d, exist_ok=True)
    return d


def norm_mac(m):
    h = "".join(c for c in (m or "").lower() if c in "0123456789abcdef")
    if len(h) != 12:
        raise ValueError("MAC должен содержать 12 hex-символов, например AA:BB:CC:DD:EE:FF")
    return ":".join(h[i:i + 2] for i in range(0, 12, 2))


def devices_load():
    try:
        with open(os.path.join(data_dir(), "devices.json"), encoding="utf-8") as f:
            return json.load(f)
    except Exception:  # noqa
        return []


def devices_save(body):
    out = []
    for d in body.get("devices", [])[:50]:
        out.append({"name": str(d.get("name", ""))[:60] or "Устройство", "mac": norm_mac(d.get("mac"))})
    with open(os.path.join(data_dir(), "devices.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False)
    return {"ok": True, "devices": out}


def own_nics():
    res = []
    try:
        for n in sorted(os.listdir("/sys/class/net")):
            if n == "lo" or n.startswith(("sit", "tun", "dummy", "docker", "veth", "bond", "ip6")):
                continue
            try:
                mac = open("/sys/class/net/%s/address" % n).read().strip()
                st = open("/sys/class/net/%s/operstate" % n).read().strip()
            except OSError:
                continue
            if mac and mac != "00:00:00:00:00:00":
                res.append({"iface": n, "mac": mac, "state": st})
    except OSError:
        pass
    res.sort(key=lambda x: x["state"] != "up")
    return res


def wol_info():
    return {"devices": devices_load(), "self": own_nics(), "ip": get_ip()}


def wol_send(body):
    mac = norm_mac(body.get("mac"))
    raw = bytes.fromhex(mac.replace(":", ""))
    packet = b"\xff" * 6 + raw * 16
    targets = [("255.255.255.255", 9), ("255.255.255.255", 7)]
    ip = get_ip()
    if ip.count(".") == 3:
        targets.append((ip.rsplit(".", 1)[0] + ".255", 9))
    sent = []
    sk = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sk.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        for t in targets:
            try:
                sk.sendto(packet, t)
                sent.append("%s:%s" % t)
            except OSError:
                pass
    finally:
        sk.close()
    if not sent:
        raise RuntimeError("Не удалось отправить пакет (нет сети?)")
    log("WoL sent to %s via %s" % (mac, ",".join(sent)))
    return {"ok": True, "mac": mac, "sent": sent}


# ---------- http ----------
# ---------- журнал событий ----------
def kodi_errors(limit=40):
    """Последние ошибки из kodi.log — чтобы не нужен был SSH."""
    try:
        with open(xbmcvfs.translatePath("special://logpath/kodi.log"), "rb") as f:
            f.seek(0, 2)
            f.seek(max(0, f.tell() - 400000))
            lines = f.read().decode("utf-8", "replace").split("\n")
    except Exception:  # noqa
        return []
    tag = "[%s]" % ADDON_ID
    out = [ln.strip()[:300] for ln in lines
           if re.search(r"\b(error|fatal)\b\s*<", ln, re.I) or (tag in ln and _ERR.search(ln) and "page request" not in ln)]
    return out[-limit:][::-1]


def events_list():
    lst = list(EVENTS)[-150:]
    lst.reverse()
    return {"items": lst, "kodi": kodi_errors()}


def events_clear():
    EVENTS.clear()
    return {"ok": True}


# ---------- каталог и поиск по своим файлам ----------
# Обложки и описания — только локальные: файлы рядом с видео (poster.jpg, folder.jpg, <имя>.jpg, .nfo)
# и библиотека Kodi (то, что она уже сохранила у себя). В интернет ничего не запрашивается.
CAT_FILE = "catalog.json"
CAT = {"items": [], "ts": 0, "busy": False, "msg": "", "count": 0}
_cat_lock = threading.Lock()
CAT_MAX = 40000
CAT_DEPTH = 8
IMG_EXT = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp"}
COVER_NAMES = ("poster", "folder", "cover", "movie", "front", "fanart", "banner", "thumb", "landscape", "clearlogo")
COVER_SUFFIX = ("-poster", "-thumb", "-cover", "-fanart", "-banner", "-landscape", "-clearlogo")
LIB = {"ts": 0, "by_name": {}, "arts": set()}
_nfo_cache = {}


def norm(s):
    s = (s or "").lower().replace("ё", "е")
    return " ".join(re.sub(r"[._\-\[\]\(\)\{\}]+", " ", s).split())


def cat_load():
    try:
        with open(os.path.join(data_dir(), CAT_FILE), encoding="utf-8") as f:
            d = json.load(f)
        CAT["items"] = d.get("items", [])
        CAT["ts"] = d.get("ts", 0)
        CAT["count"] = len(CAT["items"])
        for it in CAT["items"]:
            it["_h"] = norm(it["n"] + " " + it.get("d", ""))
    except Exception:  # noqa
        pass


def cat_save():
    try:
        items = [{k: v for k, v in it.items() if k != "_h"} for it in CAT["items"]]
        tmp = os.path.join(data_dir(), CAT_FILE + ".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"ts": CAT["ts"], "items": items}, f, ensure_ascii=False)
        os.replace(tmp, os.path.join(data_dir(), CAT_FILE))
    except Exception as e:  # noqa
        log("catalog save failed: %r" % e)


def _raw_list(i, root, rel):
    """Все записи папки (имя, папка?, размер) для любого типа корня."""
    if is_url(root):
        if urllib.parse.urlparse(root).scheme.lower() == "ftp":
            return ftp_list(root, rel)
        base = url_abs(root, rel)
        return vfs_list(base if base.endswith("/") else base + "/")
    _, p = local_abs(root, rel)
    out = []
    with os.scandir(p) as it:
        for e in it:
            try:
                d = e.is_dir()
                out.append((e.name, d, 0 if d else e.stat().st_size))
            except OSError:
                continue
    return out


def _scan_wait(root):
    """FTP-серверам с одним соединением нельзя мешать воспроизведению — на время просмотра сканирование ждёт."""
    if not (is_url(root) and urllib.parse.urlparse(root).scheme.lower() == "ftp"):
        return
    while xbmc.getCondVisibility("Player.HasVideo") and CAT["busy"]:
        CAT["msg"] = "Пауза: идёт воспроизведение"
        time.sleep(5)
    CAT["msg"] = "Сканирую…"


def catalog_scan():
    with _cat_lock:
        if CAT["busy"]:
            return False
        CAT["busy"] = True
        CAT["msg"] = "Сканирую…"
    threading.Thread(target=_catalog_job, daemon=True).start()
    return True


def _find_cover(base, names):
    for ext in IMG_EXT:
        for suffix in ("-poster", "", "-thumb", "-cover"):
            n = (base + suffix + ext).lower()
            if n in names:
                return names[n]
    return ""


def _catalog_job():
    items = []
    problems = 0
    try:
        for i, root in enumerate(user_roots()):
            stack = [("", 0)]
            while stack and len(items) < CAT_MAX:
                rel, depth = stack.pop()
                _scan_wait(root)
                try:
                    entries = _raw_list(i, root, rel)
                except Exception as e:  # noqa
                    problems += 1
                    log("catalog: пропущена папка %s: %s" % (mask_url(root) + "/" + rel, e))
                    continue
                q = is_url(root)
                files = {n.lower(): n for n, d, s in entries if not d}
                folder_art = ""
                for cn in COVER_NAMES:
                    folder_art = _find_cover(cn, files) if not folder_art else folder_art
                shown_dir = urllib.parse.unquote(rel)
                has_video = any(os.path.splitext(n)[1].lower() in VIDEO_EXT for n in files)
                for name, is_dir, size in entries:
                    if name.startswith("."):
                        continue
                    if is_dir:
                        if depth < CAT_DEPTH:
                            stack.append((child_id(i, rel, name, q).split(":", 1)[1], depth + 1))
                        continue
                    ext = os.path.splitext(name)[1].lower()
                    if ext not in VIDEO_EXT and ext not in MUSIC_EXT and ext not in PHOTO_EXT:
                        continue
                    base = os.path.splitext(name)[0]
                    if ext in IMG_EXT and has_video and (base.lower() in COVER_NAMES or base.lower().endswith(COVER_SUFFIX)):
                        continue  # обложки не показываем как отдельные фото
                    it = {"n": name, "p": child_id(i, rel, name, q), "d": root_name(root) + ("/" + shown_dir if shown_dir else ""),
                          "k": kind_of(name), "s": size}
                    if it["k"] == "video":
                        art = _find_cover(base, files)
                        art = art or folder_art
                        if art:
                            it["a"] = child_id(i, rel, art, q)
                        nfo = files.get((base + ".nfo").lower()) or files.get("movie.nfo")
                        if nfo:
                            it["o"] = child_id(i, rel, nfo, q)
                    items.append(it)
                CAT["count"] = len(items)
        for it in items:
            it["_h"] = norm(it["n"] + " " + it["d"])
        CAT["items"] = items
        CAT["ts"] = time.time()
        CAT["count"] = len(items)
        cat_save()
        lib_meta(force=True)
        CAT["msg"] = "Готово" + (" (часть папок недоступна: %d)" % problems if problems else "")
    except Exception as e:  # noqa
        log("catalog scan failed: %r" % e)
        CAT["msg"] = "Ошибка: %s" % e
    finally:
        CAT["busy"] = False


def catalog_status():
    return {"busy": CAT["busy"], "count": CAT["count"], "ts": CAT["ts"], "msg": CAT["msg"]}


def lib_meta(force=False):
    """Библиотека Kodi: имя файла -> название, год, описание, обложка (всё уже у Kodi)."""
    if not force and time.time() - LIB["ts"] < 600:
        return LIB["by_name"]
    by, arts = {}, set()
    for method, key, props in (
            ("VideoLibrary.GetMovies", "movies", ["title", "year", "plot", "file", "art"]),
            ("VideoLibrary.GetEpisodes", "episodes", ["title", "showtitle", "season", "episode", "plot", "file", "art"])):
        try:
            r = rpc(method, {"properties": props, "limits": {"start": 0, "end": 20000}})
            for m in (r.get("result") or {}).get(key, []) or []:
                fn = os.path.basename(urllib.parse.unquote(m.get("file", "")).rstrip("/")).lower()
                if not fn:
                    continue
                title = m.get("title", "")
                if key == "episodes" and m.get("showtitle"):
                    title = "%s S%02dE%02d %s" % (m["showtitle"], int(m.get("season") or 0), int(m.get("episode") or 0), title)
                art = m.get("art") or {}
                a = art.get("poster") or art.get("thumb") or art.get("tvshow.poster") or ""
                if a:
                    arts.add(a)
                by[fn] = {"title": title, "year": m.get("year") or "", "plot": m.get("plot", ""), "art": a}
        except Exception as e:  # noqa
            log("lib_meta %s: %r" % (method, e))
    LIB["by_name"], LIB["arts"], LIB["ts"] = by, arts, time.time()
    return by


def nfo_info(pid):
    if pid in _nfo_cache:
        return _nfo_cache[pid]
    info = {}
    try:
        i, root, rel = split_id(pid)
        if is_url(root) and urllib.parse.urlparse(root).scheme.lower() == "ftp":
            raise RuntimeError("ftp")
        data = _read_file_bytes(root, rel, 300000)
        txt = data.decode("utf-8", "replace")
        for tag in ("title", "year", "plot"):
            m = re.search(r"<%s>(.*?)</%s>" % (tag, tag), txt, re.S | re.I)
            if m:
                info[tag] = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", m.group(1))).strip()
    except Exception:  # noqa
        pass
    _nfo_cache[pid] = info
    return info


def _read_file_bytes(root, rel, limit):
    if is_url(root):
        scheme = urllib.parse.urlparse(root).scheme.lower()
        if scheme == "ftp":
            if xbmc.getCondVisibility("Player.HasVideo"):
                raise RuntimeError("busy")
            u = urllib.parse.urlparse(root)
            buf = bytearray()
            with _ftp_lock:
                ftp = ftp_connect_retry(u, tries=2)
                try:
                    conn = ftp.transfercmd("RETR " + ftp_path(root, rel))
                    try:
                        while len(buf) < limit:
                            ch = conn.recv(65536)
                            if not ch:
                                break
                            buf += ch
                    finally:
                        conn.close()
                finally:
                    try:
                        ftp.close()
                    except Exception:  # noqa
                        pass
            return bytes(buf[:limit])
        f = xbmcvfs.File(url_abs(root, rel).rstrip("/"))
        try:
            return bytes(f.readBytes(limit))
        finally:
            f.close()
    _, p = local_abs(root, rel)
    with open(p, "rb") as f:
        return f.read(limit)


def lib_art_path(ref):
    cands = [ref]
    inner = ref
    if ref.startswith("image://"):
        inner = urllib.parse.unquote(ref[8:].rstrip("/"))
        cands.append(inner)
    for c in cands:
        r = rpc("Textures.GetTextures", {"properties": ["cachedurl"], "filter": {"field": "url", "operator": "is", "value": c}})
        t = (r.get("result") or {}).get("textures") or []
        if t and t[0].get("cachedurl"):
            return "special://thumbnails/" + t[0]["cachedurl"]
    if inner.startswith("/") or inner.startswith("special://"):
        return inner
    return ""


def art_bytes(ref):
    """Картинка по ссылке из каталога: ('f:'+id файла рядом с видео) или ('l:'+ссылка из библиотеки Kodi)."""
    kind, _, val = ref.partition(":")
    if kind == "f":
        i, root, rel = split_id(val)
        ext = os.path.splitext(rel)[1].lower()
        if ext not in IMG_EXT:
            raise ValueError("not an image")
        return _read_file_bytes(root, rel, 6 * MB), IMG_EXT[ext]
    if kind == "l":
        if val not in LIB["arts"]:
            raise ValueError("unknown art")
        path = lib_art_path(val)
        if not path or ".." in path:
            raise ValueError("no art")
        f = xbmcvfs.File(path)
        try:
            data = bytes(f.readBytes(6 * MB))
        finally:
            f.close()
        ctype = "image/png" if data[:4] == b"\x89PNG" else "image/webp" if data[:4] == b"RIFF" else "image/jpeg"
        return data, ctype
    raise ValueError("bad ref")


def catalog_search(q, kind="", token="", offset=0):
    toks = norm(q).split()
    if not toks and not kind:
        return {"items": [], "count": CAT["count"], "total": 0, "offset": 0}
    exts = shown_exts()
    lib = lib_meta()
    scored = []
    for it in CAT["items"]:
        if kind and it["k"] != kind:
            continue
        if os.path.splitext(it["n"])[1].lower() not in exts:
            continue
        h = it.get("_h", "")
        if all(t in h for t in toks):
            nn = norm(it["n"])
            scored.append((0 if all(t in nn for t in toks) else 1, len(it["n"]) if toks else 0, nn, it))
    scored.sort(key=lambda x: (x[0], x[1], x[2]))
    out = []
    port_tok = urllib.parse.quote(token, safe="")
    offset = max(0, int(offset or 0))
    for _, _, _, it in scored[offset:offset + 60]:
        meta = lib.get(it["n"].lower()) or {}
        title, year, plot = meta.get("title", ""), meta.get("year", ""), meta.get("plot", "")
        art = ""
        if meta.get("art"):
            art = "l:" + meta["art"]
        elif it.get("a"):
            art = "f:" + it["a"]
        if it.get("o") and (not plot or not title) and len(out) < 12:
            n = nfo_info(it["o"])
            title, year, plot = title or n.get("title", ""), year or n.get("year", ""), plot or n.get("plot", "")
        out.append({"name": it["n"], "path": it["p"], "dir": it["d"], "kind": it["k"], "size": it["s"],
                    "title": title, "year": year, "plot": plot[:350],
                    "art": "/api/art?r=%s&t=%s" % (urllib.parse.quote(art, safe=""), port_tok) if art else ""})
    return {"items": out, "count": CAT["count"], "total": len(scored), "offset": offset}



def _web_dir():
    cands = []
    try:
        cands.append(os.path.join(cfg().getAddonInfo("path"), "web"))
    except Exception:  # noqa
        pass
    try:
        cands.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "web"))
    except Exception:  # noqa
        pass
    for c in cands:
        if os.path.isfile(os.path.join(c, "index.html")):
            return c
    return cands[0] if cands else "web"


WEB = _web_dir()
STATIC = {"/manifest.webmanifest": ("manifest.webmanifest", "application/manifest+json"),
          "/icon-192.png": ("icon-192.png", "image/png"), "/icon-512.png": ("icon-512.png", "image/png"),
          "/sw.js": ("sw.js", "text/javascript"), "/donate.png": ("donate.png", "image/png")}


_pin_fail = {}


def _is_private(ip):
    try:
        a = ipaddress.ip_address(ip.split("%")[0])
        if getattr(a, "ipv4_mapped", None):
            a = a.ipv4_mapped
        return a.is_private or a.is_loopback or a.is_link_local or a in ipaddress.ip_network("100.64.0.0/10")  # + VPN (Tailscale)
    except ValueError:
        return False


def remote_enabled():
    return (cfg().getSetting("remote_enabled") or "false") == "true"


def remote_pin():
    p = (cfg().getSetting("remote_pin") or "").strip()
    return p if len(p) >= 6 else ""


def remote_ext_port():
    try:
        return max(1, min(65535, int(cfg().getSetting("remote_port") or 0))) or 8090
    except ValueError:
        return int(cfg().getSetting("port") or 8090)


def remote_status():
    st = dict(remote.STATE)
    port = int(cfg().getSetting("port") or 8090)
    lan = get_ip()
    en = remote_enabled()
    st.update({"enabled": en, "pin_set": bool(remote_pin()), "lan": ("http://%s:%s" % (lan, port)) if lan else "",
               "port": port, "ext_port": remote_ext_port()})
    st["url"] = "http://%s:%s" % (st["ext_ip"], st["ext_port"]) if st.get("ext_ip") and en and st.get("state") in ("ok", "manual") else ""
    return st


def remote_loop(monitor):
    """Раз в 10 минут (и сразу после смены настроек) проверяем настройки и поддерживаем проброс порта."""
    last = None
    while not monitor.abortRequested():
        en, pin_ok = remote_enabled(), bool(remote_pin())
        cur = (en, pin_ok, remote_ext_port(), int(cfg().getSetting("port") or 8090), get_ip())
        try:
            if cur != last or time.time() - remote.STATE["ts"] > 600:
                remote.apply(en, pin_ok, cur[4], cur[3], cur[2], log=lambda m: log(m, ev=False))
                last = cur
        except Exception as e:  # noqa
            log("remote: %r" % e, ev=False)
        if monitor.waitForAbort(10):
            break
    try:
        remote.apply(False, False, "", 0, remote_ext_port())
    except Exception:  # noqa
        pass


class Handler(BaseHTTPRequestHandler):
    server_version = "PhoneRemote/1.1"
    protocol_version = "HTTP/1.1"
    timeout = 20  # drop idle / half-open (browser preconnect) sockets

    def log_message(self, fmt, *args):
        try:
            if "/api/status" in self.path or "/api/torrents" in self.path:
                return
            log("%s %s | UA: %s" % (self.client_address[0], fmt % args, (self.headers.get("User-Agent") or "")[:120]), ev=False)
        except Exception:  # noqa
            pass

    def handle_one_request(self):
        try:
            first = self.connection.recv(1, socket.MSG_PEEK)
        except OSError:  # idle/half-open browser preconnect timed out
            self.close_connection = True
            return
        if not first:
            self.close_connection = True
            return
        if first == b"\x16":  # TLS ClientHello: browser tries https:// first
            log("TLS handshake from %s (browser tried https://, closing so it falls back to http)"
                % self.client_address[0])
            self.close_connection = True
            try:
                self.connection.settimeout(0.3)
                self.connection.recv(65536)  # drain, so close() sends FIN and not RST
            except OSError:
                pass
            return
        return super().handle_one_request()

    def _send(self, code, data, ctype="application/json"):
        if code >= 400 and code != 401 and isinstance(data, dict):
            ev_add("%d %s — %s" % (code, urllib.parse.urlparse(self.path).path, data.get("error", "")), "err")
        body = data if isinstance(data, bytes) else json.dumps(data).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype + ("; charset=utf-8" if "json" in ctype or "html" in ctype else ""))
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)
        self.close_connection = True

    def _stream_out(self, name, size, gen):
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Disposition", "attachment; filename*=UTF-8''" + urllib.parse.quote(name, safe=""))
        if size:
            self.send_header("Content-Length", str(size))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.end_headers()
        self.close_connection = True
        self.connection.settimeout(300)
        for chunk in gen():
            self.wfile.write(chunk)

    def _zip_out(self, parts, zname=None):
        class W:  # поток без seek: zipfile пишет «на лету»
            def __init__(s, w):
                s.w = w

            def write(s, b):
                s.w.write(b)
                return len(b)

            def flush(s):
                pass
        self.send_response(200)
        self.send_header("Content-Type", "application/zip")
        self.send_header("Content-Disposition", "attachment; filename*=UTF-8''" +
                         urllib.parse.quote(zname or ("coreelec_%s.zip" % time.strftime("%Y%m%d_%H%M%S")), safe=""))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.end_headers()
        self.close_connection = True
        self.connection.settimeout(300)
        used = set()
        with zipfile.ZipFile(W(self.wfile), "w", zipfile.ZIP_STORED, allowZip64=True) as zf:
            for name, size, gen in parts:
                n, k = name, 1
                while n in used:
                    stem, ext = os.path.splitext(name)
                    n, k = "%s (%d)%s" % (stem, k, ext), k + 1
                used.add(n)
                zi = zipfile.ZipInfo(n, time.localtime()[:6])
                zi.compress_type = zipfile.ZIP_STORED
                with zf.open(zi, "w", force_zip64=True) as dst:
                    for chunk in gen():
                        dst.write(chunk)

    def _authed(self):
        return True

    def _remote_gate(self, u):
        """Подключения не из локальной сети пускаем только при включённом «доступе из интернета» и верном PIN.
        Возвращает None (можно) или (код, текст)."""
        ip = self.client_address[0]
        _tl.local = _is_private(ip)
        if _tl.local:
            return None
        if not remote_enabled():
            return 403, "Доступ из интернета выключен"
        now = time.time()
        bad = [t for t in _pin_fail.get(ip, []) if now - t < 600]
        if len(bad) >= 8:
            return 429, "Слишком много неверных попыток PIN — подождите 10 минут"
        if u.path in ("/", "/index.html", "/screen", "/favicon.ico", "/sw.js", "/manifest.webmanifest",
                      "/icon-192.png", "/icon-512.png"):
            return None
        qa = urllib.parse.parse_qs(u.query)
        ck = ""
        for part in (self.headers.get("Cookie") or "").split(";"):
            k, _, v = part.strip().partition("=")
            if k == "prpin":
                ck = urllib.parse.unquote(v)
        given = self.headers.get("X-Pin") or ck or (qa.get("pin") or [""])[0]
        if given and hmac.compare_digest(given.encode(), remote_pin().encode()):
            return None
        if given:
            _pin_fail[ip] = bad + [now]
        return 401, "pin"

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > 20 * 1024 * 1024:
            raise ValueError("слишком большой запрос")
        try:
            return json.loads(self.rfile.read(n).decode() or "{}") if n else {}
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise ValueError("неверный запрос (возможно, запущена старая версия add-on'а — перезапустите Kodi)")

    def _route(self, method):
        try:
            return self._route2(method)
        except (BrokenPipeError, ConnectionResetError, TimeoutError):
            self.close_connection = True
        except Exception as e:  # noqa
            log("handler error: %r" % e)
            try:
                self._send(500, {"error": "internal error"})
            except Exception:  # noqa
                self.close_connection = True

    def _stream(self, method, u):
        q = urllib.parse.parse_qs(u.query)
        if q.get("t", [""])[0] != STREAM_TOKEN:
            return self._send(403, {"error": "forbidden"})
        try:
            i, root, rel = split_id(q.get("id", [""])[0])
        except ValueError:
            return self._send(400, {"error": "bad id"})
        if not rel or urllib.parse.urlparse(root).scheme.lower() != "ftp":
            return self._send(400, {"error": "bad id"})
        pu = urllib.parse.urlparse(root)
        path = ftp_path(root, rel)
        key = (root, path)
        size0 = _size_cache.get(key)
        if method == "HEAD" and size0 is not None:  # размер уже известен — отвечаем без FTP и без очереди
            self.send_response(200)
            self.send_header("Content-Type", mimetypes.guess_type(path)[0] or "application/octet-stream")
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(size0))
            self.send_header("Connection", "close")
            self.end_headers()
            self.close_connection = True
            return
        # Тот же файл (перемотка) — новый запрос вытесняет прежний. Другой файл (Kodi читает теги/готовит следующий
        # трек) играющий поток не обрывает: ждём недолго, а если поток живой — отвечаем 503 (теги не критичны).
        same = _stream_cur["key"] == key
        stalled = time.time() - _stream_cur["t"] > 20
        if same or stalled or not _stream_lock.locked():
            _stream_gen[0] += 1
            wait = 10
        else:
            wait = 2.5
        gen = _stream_gen[0]
        if not _stream_lock.acquire(timeout=wait):
            return self._send(503, {"error": "busy"})
        _stream_cur["key"] = key
        _stream_cur["t"] = time.time()
        ftp = conn = None
        try:
            try:
                ftp = ftp_connect_retry(pu)
                size = _size_cache.get((root, path))
                if size is None:
                    size = _size_cache[(root, path)] = ftp_file_size(ftp, path)
            except (ftplib.all_errors, RuntimeError) as e:
                log("stream open failed %s: %s" % (mask_url(root), e))
                return self._send(502, {"error": "FTP: %s" % e})
            start, end, code = 0, size - 1, 200
            rng = self.headers.get("Range") or ""
            if rng.startswith("bytes="):
                a, _, b = rng[6:].split(",")[0].strip().partition("-")
                try:
                    if a == "":
                        start = max(0, size - int(b))
                    else:
                        start = int(a)
                        end = min(int(b), size - 1) if b else size - 1
                except ValueError:
                    start, end = 0, size - 1
                if start >= size or start > end:
                    self.send_response(416)
                    self.send_header("Content-Range", "bytes */%d" % size)
                    self.send_header("Content-Length", "0")
                    self.send_header("Connection", "close")
                    self.end_headers()
                    self.close_connection = True
                    return
                code = 206
            self.send_response(code)
            self.send_header("Content-Type", mimetypes.guess_type(path)[0] or "application/octet-stream")
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(end - start + 1))
            if code == 206:
                self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
            self.send_header("Connection", "close")
            self.end_headers()
            self.close_connection = True
            if method == "HEAD":
                return
            self.connection.settimeout(300)  # Kodi на паузе может долго не читать
            ftp.voidcmd("TYPE I")
            conn = ftp.transfercmd("RETR " + path, rest=start if start else None)
            left = end - start + 1
            while left > 0 and _stream_gen[0] == gen:
                chunk = conn.recv(min(262144, left))
                if not chunk:
                    break
                _stream_cur["t"] = time.time()
                self.wfile.write(chunk)
                left -= len(chunk)
        except (ftplib.all_errors, BrokenPipeError, ConnectionResetError, TimeoutError) as e:
            log("stream ended: %r" % (e,))
            self.close_connection = True
        finally:
            for c in (conn, ftp):
                try:
                    if c is not None:
                        c.close()
                except Exception:  # noqa
                    pass
            _stream_cur["key"] = None
            _stream_lock.release()

    def _route2(self, method):
        u = urllib.parse.urlparse(self.path)
        gate = self._remote_gate(u)
        if gate:
            return self._send(gate[0], {"error": gate[1]})
        if u.path.startswith("/stream/") and method in ("GET", "HEAD"):
            return self._stream(method, u)
        if u.path == "/favicon.ico":
            self.send_response(204)
            self.send_header("Content-Length", "0")
            self.send_header("Connection", "close")
            self.end_headers()
            self.close_connection = True
            return
        if method == "GET" and u.path in ("/", "/index.html", "/screen"):
            log("page request from %s | UA: %s" % (self.client_address[0], (self.headers.get("User-Agent") or "")[:120]), ev=False)
            with open(os.path.join(WEB, "index.html"), "rb") as f:
                return self._send(200, f.read(), "text/html")
        if method == "GET" and u.path in STATIC:
            fn, ctype = STATIC[u.path]
            try:
                with open(os.path.join(WEB, fn), "rb") as f:
                    return self._send(200, f.read(), ctype)
            except OSError:
                return self._send(404, {"error": "not found"})
        if method == "GET" and u.path == "/api/art":
            qa = urllib.parse.parse_qs(u.query)
            if qa.get("t", [""])[0] != STREAM_TOKEN:
                return self._send(403, {"error": "forbidden"})
            try:
                data, ctype = art_bytes(qa.get("r", [""])[0])
            except Exception as e:  # noqa
                return self._send(404, {"error": "no image (%s)" % type(e).__name__})
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "max-age=86400")
            self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.write(data)
            self.close_connection = True
            return
        if method == "GET" and u.path == "/api/addonart":
            try:
                data, ctype = art_fetch(urllib.parse.parse_qs(u.query).get("u", [""])[0])
            except Exception as e:  # noqa
                log("art failed: %s (%s)" % (urllib.parse.parse_qs(u.query).get("u", [""])[0][:140], e), ev=False)
                return self._send(404, {"error": "no art: %s" % e})
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "max-age=86400")
            self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.write(data)
            self.close_connection = True
            return
        if method == "GET" and u.path == "/api/thumb":
            qa = urllib.parse.parse_qs(u.query)
            try:
                data, ctype = thumb_now() if qa.get("now") else thumb_for_key(qa["key"][0]) if qa.get("key") \
                    else thumb_for_pid(qa.get("id", [""])[0])
            except Exception as e:  # noqa
                return self._send(404, {"error": "no thumb: %s" % e})
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "max-age=3600")
            self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.write(data)
            self.close_connection = True
            return
        if not u.path.startswith("/api/"):
            return self._send(404, {"error": "not found"})
        if not self._authed():
            return self._send(401, {"error": "pin"})
        q = urllib.parse.parse_qs(u.query)
        try:
            if method == "GET" and u.path == "/api/dialog":
                return self._send(200, dialog_info(q.get("force", [""])[0] == "1"))
            if method == "GET" and u.path == "/api/msrc/resolve":
                return self._send(200, src_resolve(q.get("path", [""])[0]))
            if method == "GET" and u.path == "/api/msrc/scrapers":
                return self._send(200, src_scrapers(q.get("content", [""])[0]))
            if method == "GET" and u.path == "/api/msrc/content":
                return self._send(200, src_content_get(q.get("path", [""])[0]))
            if method == "GET" and u.path == "/api/sources":
                return self._send(200, sources_public())
            if method == "GET" and u.path == "/api/addons":
                return self._send(200, addons_list())
            if method == "GET" and u.path == "/api/ui":
                return self._send(200, ui_get())
            if method == "GET" and u.path == "/api/macros":
                return self._send(200, {"macros": mk_load()})
            if method == "GET" and u.path == "/api/win":
                return self._send(200, win_info())
            if method == "GET" and u.path == "/api/msrc":
                return self._send(200, src_list())
            if method == "GET" and u.path == "/api/remote":
                return self._send(200, remote_status())
            if method == "GET" and u.path == "/api/ks/sysinfo":
                return self._send(200, ks_sysinfo())
            if method == "GET" and u.path == "/api/ks/sections":
                return self._send(200, ks_sections(q.get("level", [""])[0]))
            if method == "GET" and u.path == "/api/ks/categories":
                return self._send(200, ks_categories(q.get("section", [""])[0], q.get("level", [""])[0]))
            if method == "GET" and u.path == "/api/ks/settings":
                return self._send(200, ks_settings(q.get("section", [""])[0], q.get("category", [""])[0],
                                                   q.get("level", [""])[0]))
            if method == "GET" and u.path == "/api/ks/search":
                return self._send(200, ks_search(q.get("q", [""])[0], q.get("level", [""])[0]))
            if method == "GET" and u.path == "/api/gsearch":
                return self._send(200, global_search(q.get("q", [""])[0]))
            if method == "GET" and u.path == "/api/home/browse":
                return self._send(200, home_browse(q.get("path", [""])[0], q.get("media", ["video"])[0],
                                                   q.get("start", ["0"])[0]))
            if method == "GET" and u.path == "/api/iptv/saved":
                return self._send(200, iptv_saved())
            if method == "GET" and u.path == "/api/iptv/list":
                return self._send(200, iptv_list(q.get("id", [""])[0], q.get("group", [""])[0], q.get("q", [""])[0],
                                                 q.get("start", ["0"])[0]))
            if method == "POST" and u.path == "/api/iptv/upload":
                self.connection.settimeout(120)
                return self._send(200, iptv_upload(self.rfile, int(self.headers.get("Content-Length") or 0),
                                                   urllib.parse.unquote(q.get("name", [""])[0])))
            if method == "GET" and u.path == "/api/phist":
                return self._send(200, phist_list())
            if method == "GET" and u.path == "/api/continue":
                return self._send(200, continue_lists())
            if method == "GET" and u.path == "/api/fav/list":
                return self._send(200, fav_list())
            if method == "GET" and u.path == "/api/addons/all":
                return self._send(200, addons_all())
            if method == "GET" and u.path == "/api/dialog/debug":
                return self._send(200, dialog_debug())
            if method == "GET" and u.path == "/api/confirm":
                return self._send(200, confirm_info())
            if method == "GET" and u.path == "/api/repo/cats":
                return self._send(200, repo_cats())
            if method == "GET" and u.path == "/api/repo/list":
                return self._send(200, repo_list(q.get("q", [""])[0], q.get("kind", [""])[0], q.get("start", ["0"])[0]))
            if method == "GET" and u.path == "/api/addon/state":
                return self._send(200, addon_state(q.get("id", [""])[0]))
            if method == "POST" and u.path == "/api/item/info":
                return self._send(200, item_info(_info_body(self._body())))
            if method == "POST" and u.path == "/api/fav/add":
                b = self._body()
                if b.get("pid"):
                    b = dict(b, **fav_path(str(b["pid"])))
                elif b.get("playing"):
                    b = _info_body(b)
                    if not b.get("file"):
                        raise ValueError("У этого элемента нет адреса")
                return self._send(200, fav_add(b))
            if method == "POST" and u.path == "/api/gsearch/tv":
                return self._send(200, global_search_tv(self._body()))
            if method == "POST" and u.path == "/api/elementum/upload":
                self.connection.settimeout(120)
                return self._send(200, elementum_upload(self.rfile, int(self.headers.get("Content-Length") or 0),
                                                        urllib.parse.unquote(q.get("name", [""])[0]),
                                                        q.get("play", [""])[0] == "1"))
            if method == "POST" and u.path == "/api/addon/zip":
                self.connection.settimeout(300)
                return self._send(200, install_zip(self.rfile, int(self.headers.get("Content-Length") or 0), ""))
            if method == "GET" and u.path == "/api/addon/settings":
                return self._send(200, addon_settings(q.get("id", [""])[0]))
            if method == "GET" and u.path == "/api/addon/browse":
                return self._send(200, addon_browse(q.get("path", [""])[0], q.get("media", ["video"])[0],
                                                    q.get("start", ["0"])[0]))
            if method == "GET" and u.path == "/api/file/download":
                try:
                    name, size, gen = _open_chunks(q.get("path", [""])[0])
                except (ValueError, RuntimeError) as e:
                    return self._send(404, {"error": str(e)})
                return self._stream_out(name, size, gen)
            if method == "GET" and u.path == "/api/file/zipdir":
                try:
                    top, parts = _dir_parts(q.get("path", [""])[0])
                except (ValueError, RuntimeError, OSError) as e:
                    return self._send(404, {"error": str(e)})
                return self._zip_out(parts, top + ".zip")
            if method == "GET" and u.path == "/api/file/zip":
                try:
                    pids = json.loads(q.get("paths", ["[]"])[0])[:200]
                    parts = [_open_chunks(p) for p in pids]
                except (ValueError, RuntimeError) as e:
                    return self._send(404, {"error": str(e)})
                return self._zip_out(parts)
            if method == "POST" and u.path == "/api/file/upload":
                n = int(self.headers.get("Content-Length") or 0)
                self.connection.settimeout(300)
                res = upload_file(self.rfile, n, q.get("dir", [""])[0], urllib.parse.unquote(q.get("name", [""])[0]))
                return self._send(200, res)
            if method == "GET" and u.path == "/api/file/job":
                return self._send(200, fop_job(q.get("id", [""])[0]))
            if method == "GET" and u.path == "/api/files":
                return self._send(200, list_dir(q.get("path", [""])[0], q.get("all", [""])[0] == "1",
                                           q.get("hidden", [""])[0] == "1"))
            if method == "GET" and u.path == "/api/status":
                return self._send(200, status())
            if method == "GET" and u.path == "/api/torrents":
                return self._send(200, torrents_list())
            if method == "GET" and u.path == "/api/shell/state":
                return self._send(200, shell_state())
            if method == "GET" and u.path == "/api/term/read":
                return self._send(200, term_read(q.get("id", [""])[0], int(q.get("pos", ["0"])[0]),
                                                 float(q.get("wait", ["0"])[0])))
            if method == "GET" and u.path == "/api/torrents/files":
                if backend() != "qbittorrent":
                    raise ValueError("Выбор файлов работает только с qBittorrent")
                return self._send(200, qb_files(q.get("hash", [""])[0]))
            if method == "GET" and u.path == "/api/wol":
                return self._send(200, wol_info())
            if method == "GET" and u.path == "/api/tracks":
                return self._send(200, tracks())
            if method == "GET" and u.path == "/api/power":
                return self._send(200, power_caps())
            if method == "GET" and u.path == "/api/history":
                return self._send(200, hist_list())
            if method == "GET" and u.path == "/api/queue":
                return self._send(200, queue_state())
            if method == "GET" and u.path == "/api/ffmpeg":
                return self._send(200, ffmpeg_state())
            if method == "GET" and u.path == "/api/screenshot/get":
                try:
                    data, ctype, nm = read_screenshot(q.get("name", [""])[0])
                except ValueError as e:
                    return self._send(404, {"error": str(e)})
                return self._send(200, data, ctype)
            if method == "GET" and u.path == "/api/playlists":
                return self._send(200, playlists_list())
            if method == "GET" and u.path == "/api/playlists/get":
                return self._send(200, playlist_get(q.get("name", [""])[0]))
            if method == "GET" and u.path == "/api/system":
                return self._send(200, sysinfo())
            if method == "GET" and u.path == "/api/log":
                return self._send(200, events_list())
            if method == "GET" and u.path == "/api/catalog":
                return self._send(200, catalog_status())
            if method == "GET" and u.path == "/api/search":
                return self._send(200, catalog_search(q.get("q", [""])[0], q.get("kind", [""])[0], STREAM_TOKEN,
                                                     q.get("offset", ["0"])[0]))
            if method == "GET" and u.path == "/api/install":
                return self._send(200, instjob.state())
            if method == "GET" and u.path == "/api/qb":
                return self._send(200, qb_status())
            if method == "GET" and u.path == "/api/watch":
                return self._send(200, watch_state())
            if method == "POST":
                body = self._body()
                if u.path == "/api/ks/set":
                    return self._send(200, ks_set(body))
                if u.path == "/api/ks/reset":
                    return self._send(200, ks_reset(body))
                if u.path == "/api/dialog/select":
                    return self._send(200, dialog_select(body))
                if u.path == "/api/dialog/cancel":
                    return self._send(200, dialog_cancel())
                if u.path == "/api/sources/save":
                    return self._send(200, source_save(body))
                if u.path == "/api/sources/delete":
                    return self._send(200, source_delete(body))
                if u.path == "/api/sources/test":
                    return self._send(200, source_test(body))
                if u.path == "/api/iptv/load":
                    return self._send(200, iptv_load(body))
                if u.path == "/api/iptv/play":
                    return self._send(200, iptv_play(body))
                if u.path == "/api/iptv/forget":
                    return self._send(200, iptv_forget(body))
                if u.path == "/api/phist/play":
                    return self._send(200, phist_play(body))
                if u.path == "/api/phist/remove":
                    return self._send(200, phist_remove(body))
                if u.path == "/api/resume/play":
                    return self._send(200, resume_play(body))
                if u.path == "/api/fav/remove":
                    return self._send(200, fav_remove(body))
                if u.path == "/api/play/url":
                    return self._send(200, play_url(body))
                if u.path == "/api/elementum/add":
                    return self._send(200, elementum_add(body.get("uri"), bool(body.get("play"))))
                if u.path == "/api/addon/uninstall":
                    return self._send(200, addon_uninstall(body))
                if u.path == "/api/confirm/answer":
                    return self._send(200, confirm_answer(body))
                if u.path == "/api/addon/install":
                    return self._send(200, addon_install(body))
                if u.path == "/api/addon/settings":
                    return self._send(200, addon_setting_set(body))
                if u.path == "/api/addon/launch":
                    return self._send(200, addon_launch(body))
                if u.path == "/api/addon/play":
                    return self._send(200, addon_play(body))
                if u.path == "/api/play":
                    api_play(body)
                    return self._send(200, {"ok": True})
                if u.path == "/api/msrc/add":
                    return self._send(200, src_add(body))
                if u.path == "/api/msrc/content":
                    return self._send(200, src_content_set(body))
                if u.path == "/api/msrc/del":
                    return self._send(200, src_del(body))
                if u.path == "/api/ui":
                    return self._send(200, ui_save(body))
                if u.path == "/api/macros/save":
                    return self._send(200, mk_save(body))
                if u.path == "/api/macros/run":
                    return self._send(200, mk_run(body))
                if u.path == "/api/ctx/open":
                    return self._send(200, ctx_open(body))
                if u.path == "/api/win/act":
                    return self._send(200, win_act(body))
                if u.path == "/api/library/scan":
                    return self._send(200, library_scan(body))
                if u.path == "/api/power":
                    return self._send(200, power(body))
                if u.path == "/api/sleep":
                    return self._send(200, sleep_set(body))
                if u.path == "/api/ffmpeg/install":
                    return self._send(200, ffmpeg_install())
                if u.path == "/api/screenshot":
                    return self._send(200, take_screenshot())
                if u.path == "/api/queue/add":
                    queue_add(body)
                    return self._send(200, {"ok": True})
                if u.path == "/api/queue/action":
                    queue_action(body)
                    return self._send(200, {"ok": True})
                if u.path == "/api/file/rename":
                    return self._send(200, fop_rename(body))
                if u.path == "/api/file/mkdir":
                    return self._send(200, fop_mkdir(body))
                if u.path == "/api/file/copy":
                    return self._send(200, fop_copy(body))
                if u.path == "/api/file/move":
                    return self._send(200, fop_move(body))
                if u.path == "/api/file/delete":
                    return self._send(200, fop_delete(body))
                if u.path == "/api/playlists/save":
                    return self._send(200, playlist_save(body))
                if u.path == "/api/playlists/load":
                    return self._send(200, playlist_load(body))
                if u.path == "/api/playlists/edit":
                    return self._send(200, playlist_edit(body))
                if u.path == "/api/playlists/delete":
                    return self._send(200, playlist_delete(body))
                if u.path == "/api/history/remove":
                    return self._send(200, hist_remove(body.get("key", "")))
                if u.path == "/api/log/clear":
                    return self._send(200, events_clear())
                if u.path == "/api/catalog/scan":
                    return self._send(200, {"started": catalog_scan()})
                if u.path == "/api/install/start":
                    return self._send(200, instjob.start(str(body.get("step", ""))))
                if u.path == "/api/install/reboot":
                    threading.Timer(1.5, lambda: xbmc.executebuiltin("Reboot")).start()
                    return self._send(200, {"ok": True})
                if u.path == "/api/qb/start":
                    return self._send(200, qb_launch())
                if u.path == "/api/watch/cancel":
                    return self._send(200, watch_cancel())
                if u.path == "/api/control":
                    control(body)
                    return self._send(200, {"ok": True})
                if u.path == "/api/wol/save":
                    return self._send(200, devices_save(body))
                if u.path == "/api/wol/send":
                    return self._send(200, wol_send(body))
                if u.path == "/api/torrents/add":
                    return self._send(200, torrents_add(body))
                if u.path == "/api/shell":
                    return self._send(200, shell_run(body))
                if u.path == "/api/term/open":
                    return self._send(200, term_open(body))
                if u.path == "/api/term/write":
                    return self._send(200, term_write(body))
                if u.path == "/api/term/close":
                    return self._send(200, term_close(body))
                if u.path == "/api/paste":
                    return self._send(200, paste_log(body))
                if u.path == "/api/torrents/select":
                    if backend() != "qbittorrent":
                        raise ValueError("Выбор файлов работает только с qBittorrent")
                    return self._send(200, qb_select(body))
                if u.path == "/api/torrents/action":
                    return self._send(200, torrents_action(body))
            return self._send(404, {"error": "not found"})
        except (ValueError, FileNotFoundError, NotADirectoryError, PermissionError) as e:
            return self._send(400, {"error": str(e)})
        except RuntimeError as e:
            return self._send(502, {"error": str(e)})
        except Exception as e:  # noqa
            log("error: %r" % e)
            return self._send(500, {"error": "internal error"})

    def do_GET(self):
        self._route("GET")

    def do_HEAD(self):
        self._route("HEAD")

    def do_POST(self):
        self._route("POST")


def get_ip():
    """Real LAN IP of this box (Kodi's Network.IPAddress label can say 'Busy')."""
    for target in ("8.8.8.8", "192.168.1.1", "192.168.0.1", "10.0.0.1"):
        try:
            sk = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sk.settimeout(0.5)
            sk.connect((target, 80))  # UDP: no packet is actually sent
            ip = sk.getsockname()[0]
            sk.close()
            if ip and not ip.startswith("127.") and ip != "0.0.0.0":
                return ip
        except Exception:  # noqa
            pass
    lab = xbmc.getInfoLabel("Network.IPAddress")
    if lab and lab[0].isdigit():
        return lab
    return ""


class Srv(ThreadingHTTPServer):
    request_queue_size = 64
    allow_reuse_address = True
    daemon_threads = True

    def handle_error(self, request, client_address):
        import sys
        log("connection error from %s: %r" % (client_address[0], sys.exc_info()[1]))


def main():
    class Mon(xbmc.Monitor):
        def onNotification(self, sender, method, data):
            if method.endswith("System.OnWake") or method == "System.OnWake":
                on_wake()

    monitor = Mon()
    _rp = _RetryPlayer()   # noqa: нужен живой экземпляр, чтобы приходил onPlayBackError
    port = int(cfg().getSetting("port") or 8090)
    try:
        httpd = Srv(("0.0.0.0", port), Handler)
    except OSError as e:
        log("cannot bind port %s: %s" % (port, e))
        xbmcgui.Dialog().notification("Phone Remote", "Порт %s занят" % port, xbmcgui.NOTIFICATION_ERROR, 5000)
        return
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    threading.Thread(target=tracker, args=(monitor,), daemon=True).start()
    threading.Thread(target=remote_loop, args=(monitor,), daemon=True).start()

    def _warm():   # через минуту после старта подготовить список add-on'ов из репозиториев (на диске + в памяти)
        if monitor.waitForAbort(60):
            return
        try:
            _repo_load()
        except Exception as e:  # noqa
            log("repo warm: %s" % e, ev=False)
    threading.Thread(target=_warm, daemon=True).start()
    def _inst_done(result, msg, reboot):
        if result == "ok":
            for k, v in (("tr_backend", "qbittorrent"), ("qb_host", "127.0.0.1"), ("qb_port", "9080"),
                         ("qb_user", "admin"), ("qb_pass", "admin")):
                if instjob._S["step"] != "entware":
                    cfg().setSetting(k, v)
        xbmcgui.Dialog().notification("Phone Remote", msg, xbmcgui.NOTIFICATION_ERROR if result == "fail"
                                      else xbmcgui.NOTIFICATION_INFO, 8000)
    instjob.init(os.path.dirname(os.path.abspath(__file__)), data_dir(),
                 lambda: (cfg().getSetting("tr_dir") or "").rstrip("/") or qbctl.DEFAULT_DL, _inst_done)
    threading.Thread(target=qb_boot_job, args=(monitor,), daemon=True).start()
    cat_load()
    # Network may not be up yet right after boot: wait up to ~90 s for an IP.
    ip = ""
    for _ in range(45):
        ip = get_ip()
        if ip or monitor.waitForAbort(2):
            break
    log("listening on %s:%s" % (ip or "0.0.0.0", port))
    shown = ""

    def announce(addr):
        xbmcgui.Dialog().notification("Phone Remote", addr, xbmcgui.NOTIFICATION_INFO, 10000)

    if ip:
        shown = ip
        announce("http://%s:%s" % (ip, port))
    else:
        announce("Сеть не найдена, порт %s" % port)
    last_t = time.time()
    while not monitor.abortRequested():
        if monitor.waitForAbort(5):
            break
        if time.time() - last_t > 25:  # часы «прыгнули»: приставка просыпалась из сна
            on_wake()
        last_t = time.time()
        cur = get_ip()
        if cur and cur != shown:
            shown = cur
            log("address changed: %s:%s" % (cur, port))
            announce("http://%s:%s" % (cur, port))
    httpd.shutdown()
    httpd.server_close()


if __name__ == "__main__":
    main()
