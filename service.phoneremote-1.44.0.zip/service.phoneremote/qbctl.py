"""Управление qBittorrent (Entware) на CoreELEC: проверка, запуск, остановка. Общий код для service.py и installer.py."""
import os
import signal
import subprocess
import time
import urllib.error
import urllib.request

OPT = os.environ.get("PR_OPT", "/opt")
PROFILE = os.environ.get("PR_PROFILE", "/storage/qbittorrent")
AUTOSTART = os.environ.get("PR_AUTOSTART", "/storage/.config/autostart.sh")
DEFAULT_PORT = 9080
DEFAULT_DL = "/storage/videos/Torrents"


def binpath():
    return os.path.join(OPT, "bin", "qbittorrent-nox")


def entware_ready():
    return os.access(os.path.join(OPT, "bin", "opkg"), os.X_OK)


def installed():
    return os.access(binpath(), os.X_OK)


def _env():
    e = dict(os.environ)
    # CoreELEC подсовывает свою новую libc — для программ Entware указываем их библиотеки.
    e["LD_LIBRARY_PATH"] = "%s/lib:%s/usr/lib" % (OPT, OPT)
    e["PATH"] = "%s/bin:%s/sbin:" % (OPT, OPT) + e.get("PATH", "") + ":/usr/sbin:/sbin"
    return e


def running(port=DEFAULT_PORT):
    """Веб-интерфейс qBittorrent отвечает (даже кодом 403 — значит, он жив)."""
    try:
        with urllib.request.urlopen("http://127.0.0.1:%s/api/v2/app/version" % port, timeout=2):
            return True
    except urllib.error.HTTPError:
        return True
    except Exception:  # noqa
        return False


def version():
    if not installed():
        return ""
    try:
        out = subprocess.run([binpath(), "--version"], env=_env(), capture_output=True, text=True, timeout=15)
        return (out.stdout or out.stderr or "").strip()
    except Exception:  # noqa
        return ""


def _pids():
    res = []
    try:
        for d in os.listdir("/proc"):
            if not d.isdigit():
                continue
            try:
                with open("/proc/%s/cmdline" % d, "rb") as f:
                    cmd = f.read().split(b"\0")[0]
            except OSError:
                continue
            if os.path.basename(cmd.decode("utf-8", "replace")) == "qbittorrent-nox":
                res.append(int(d))
    except OSError:
        pass
    return res


def start(port=DEFAULT_PORT, wait=25):
    """Запускает qBittorrent. Возвращает (ok, сообщение)."""
    if running(port):
        return True, "уже запущен"
    if not installed():
        return False, "не установлен"
    try:
        os.makedirs(PROFILE, exist_ok=True)
        log = open(os.path.join(PROFILE, "start.log"), "ab")
        subprocess.Popen([binpath(), "--daemon", "--profile=" + PROFILE, "--webui-port=%s" % port],
                         env=_env(), stdout=log, stderr=log, stdin=subprocess.DEVNULL, start_new_session=True)
    except Exception as e:  # noqa
        return False, "не удалось запустить: %s" % e
    end = time.time() + wait
    while time.time() < end:
        if running(port):
            return True, "запущен"
        time.sleep(1)
    tail = ""
    try:
        with open(os.path.join(PROFILE, "start.log"), "rb") as f:
            tail = f.read()[-400:].decode("utf-8", "replace").strip()
    except OSError:
        pass
    return False, "не отвечает на порту %s. %s" % (port, tail)


def stop(wait=10):
    for p in _pids():
        try:
            os.kill(p, signal.SIGTERM)
        except OSError:
            pass
    end = time.time() + wait
    while time.time() < end and _pids():
        time.sleep(0.5)
    for p in _pids():
        try:
            os.kill(p, signal.SIGKILL)
        except OSError:
            pass
    return not _pids()


def autostart_has():
    try:
        with open(AUTOSTART) as f:
            return "phoneremote-qbittorrent" in f.read()
    except OSError:
        return False


PBKDF_ADMIN = ('"@ByteArray(XzqcHnstSAahw+X3CStNbg==:MX8SzdMqn+UPBq0vK/v0epAYKjltZAfKLUYQKuPAoXphGzmUOgXW1yknry2O0GAeYiYGgKTwRNoZ51WqLWs8TQ==)"')


def reset_login(port=DEFAULT_PORT):
    """Возвращает вход в веб-интерфейс qBittorrent к admin / admin (как при установке) и перезапускает его.
    Возвращает (ok, сообщение)."""
    if not installed():
        return False, "не установлен"
    stop()
    cfgdir = os.path.join(PROFILE, "qBittorrent", "config")
    cfg = os.path.join(cfgdir, "qBittorrent.conf")
    try:
        os.makedirs(cfgdir, exist_ok=True)
        try:
            with open(cfg, encoding="utf-8", errors="replace") as f:
                lines = f.read().split("\n")
        except OSError:
            lines = ["[LegalNotice]", "Accepted=true", "", "[Preferences]"]
        try:
            with open(cfg + ".bak", "w", encoding="utf-8") as f:
                f.write("\n".join(lines))
        except OSError:
            pass
        drop = ("WebUI\\Username=", "WebUI\\Password_PBKDF2=", "WebUI\\LocalHostAuth=", "WebUI\\HostHeaderValidation=",
                "WebUI\\CSRFProtection=", "WebUI\\Address=")
        lines = [ln for ln in lines if not ln.startswith(drop)]
        new = ["WebUI\\Username=admin", "WebUI\\Password_PBKDF2=" + PBKDF_ADMIN, "WebUI\\LocalHostAuth=false",
               "WebUI\\Address=*", "WebUI\\HostHeaderValidation=false", "WebUI\\CSRFProtection=false"]
        if "[Preferences]" in lines:
            i = lines.index("[Preferences]")
            lines[i + 1:i + 1] = new
        else:
            lines += ["", "[Preferences]"] + new
        if "[LegalNotice]" not in lines:
            lines += ["", "[LegalNotice]", "Accepted=true"]
        with open(cfg, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
    except OSError as e:
        return False, "не удалось записать конфиг: %s" % e
    return start(port)
