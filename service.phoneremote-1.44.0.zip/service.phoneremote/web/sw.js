// Минимальный service worker: нужен Chrome, чтобы предлагать установку страницы как приложения.
self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('fetch',()=>{});
