"""Установка Entware и qBittorrent как фоновое задание сервиса.
Шаги: entware | qbittorrent | all. Состояние и журнал — в профиле аддона (переживают перезагрузку).
Используется и веб-интерфейсом (service.py), и кнопками в настройках Kodi (installer.py через HTTP)."""
import json
import os
import shutil
import subprocess
import threading
import time

import qbctl

ADDON_ID = "service.phoneremote"
SCRIPT_NAME = "setup-qbittorrent.sh"
_lock = threading.Lock()
_S = {"running": False, "step": "", "result": "", "msg": "", "reboot": False, "log": []}
_hooks = {"addon_dir": "", "state_dir": "", "dl": lambda: qbctl.DEFAULT_DL, "after": None}


def init(addon_dir, state_dir, dl_getter=None, after=None):
    _hooks["addon_dir"] = addon_dir
    _hooks["state_dir"] = state_dir
    if dl_getter:
        _hooks["dl"] = dl_getter
    _hooks["after"] = after
    try:
        os.makedirs(state_dir, exist_ok=True)
    except OSError:
        pass
    st = _load()
    # прошлое задание могло оборваться (перезагрузка) — показываем его итог, но не «идёт»
    _S.update({"result": st.get("result", ""), "msg": st.get("msg", ""), "reboot": bool(st.get("reboot")),
               "step": st.get("step", "")})
    try:
        with open(_logfile(), encoding="utf-8", errors="replace") as f:
            _S["log"] = f.read().splitlines()[-200:]
    except OSError:
        pass


def _statefile():
    return os.path.join(_hooks["state_dir"], "install_state.json")


def _logfile():
    return os.path.join(_hooks["state_dir"], "install.log")


def _load():
    try:
        with open(_statefile(), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _save(**kw):
    st = _load()
    st.update(kw)
    try:
        with open(_statefile(), "w", encoding="utf-8") as f:
            json.dump(st, f)
    except OSError:
        pass


def pending():
    return _load().get("pending", "")


def say(line):
    line = (line or "").rstrip()
    if not line:
        return
    _S["log"].append(line)
    del _S["log"][:-300]
    try:
        with open(_logfile(), "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


def state():
    d = dict(_S)
    d["log"] = _S["log"][-40:]
    d["entware"] = entware_ok()
    d["installed"] = qbctl.installed()
    d["running_qb"] = qbctl.running(qbctl.DEFAULT_PORT)
    d["pending"] = pending()
    return d


def entware_ok():
    return qbctl.entware_ready()


def _env():
    e = dict(os.environ)
    e["PATH"] = e.get("PATH", "") + ":/usr/sbin:/sbin:/usr/bin:/bin:/storage/.opt/bin"
    e["TERM"] = e.get("TERM") or "dumb"
    return e


def _run(cmd, stdin_text=None, timeout=900, extra_env=None):
    env = _env()
    if extra_env:
        env.update(extra_env)
    say("$ " + " ".join(cmd))
    p = subprocess.Popen(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         stdin=subprocess.PIPE if stdin_text is not None else subprocess.DEVNULL,
                         universal_newlines=True, errors="replace")
    if stdin_text is not None:
        def feed():
            try:
                p.stdin.write(stdin_text)
                p.stdin.close()
            except OSError:
                pass
        threading.Thread(target=feed, daemon=True).start()
    t0 = time.time()

    def kill():
        if p.poll() is None:
            p.kill()
    timer = threading.Timer(timeout, kill)
    timer.start()
    try:
        for ln in p.stdout:
            say(ln)
    finally:
        timer.cancel()
    p.wait()
    say("[код выхода %s, %.0f с]" % (p.returncode, time.time() - t0))
    return p.returncode


def find_installentware():
    env = _env()
    w = shutil.which("installentware", path=env["PATH"])
    if w:
        return w
    for c in ("/usr/bin/installentware", "/usr/sbin/installentware", "/storage/.kodi/addons/installentware",
              "/usr/local/bin/installentware"):
        if os.access(c, os.X_OK):
            return c
    return ""


def try_bind_mount():
    """installentware кладёт Entware в /storage/.opt; /opt привязывается при загрузке. Пробуем привязать сразу."""
    if qbctl.entware_ready():
        return True
    src = "/storage/.opt"
    if qbctl.OPT == "/opt" and os.access(os.path.join(src, "bin", "opkg"), os.X_OK):
        say("Entware лежит в %s, но /opt ещё не подключён — пробую mount --bind" % src)
        try:
            os.makedirs("/opt", exist_ok=True)
        except OSError:
            pass
        _run(["mount", "-o", "bind", src, "/opt"], timeout=30)
    return qbctl.entware_ready()


def step_entware():
    """Возвращает 'ok' | 'reboot' | 'fail'."""
    if qbctl.entware_ready():
        say("Entware уже установлен.")
        return "ok"
    exe = find_installentware()
    if not exe:
        say("Команда installentware не найдена. Это точно CoreELEC? Запустите по SSH: installentware")
        return "fail"
    say("== Устанавливаю Entware (%s). Нужен интернет, 1–3 минуты." % exe)
    # на случай вопроса «продолжить? y/n» подаём «y» на вход
    _run([exe], stdin_text="y\n" * 10, timeout=900)
    if try_bind_mount():
        say("Entware установлен и подключён (/opt/bin/opkg есть).")
        return "ok"
    if os.path.isdir("/storage/.opt") and os.listdir("/storage/.opt"):
        say("Entware скачан в /storage/.opt, но подключится к /opt только после перезагрузки.")
        return "reboot"
    say("Entware не установился: после installentware нет ни /opt/bin/opkg, ни /storage/.opt. Смотрите журнал выше "
        "(нет интернета до bin.entware.net?).")
    return "fail"


def step_qb():
    if not qbctl.entware_ready():
        say("Entware не установлен/не подключён — сначала установите Entware.")
        return "fail"
    script = os.path.join(_hooks["addon_dir"], "resources", SCRIPT_NAME)
    say("== Устанавливаю qBittorrent (opkg), настраиваю admin/admin, запускаю")
    rc = _run(["sh", script, "--resume", _hooks["dl"]()], timeout=1500, extra_env={"NOREBOOT": "1", "NORESUME": "1"})
    if rc == 0 and qbctl.running(qbctl.DEFAULT_PORT):
        return "ok"
    return "fail"


def _job(step):
    try:
        res = "ok"
        if step in ("entware", "all"):
            res = step_entware()
            if res == "fail":
                _finish("fail", "Entware не установился — см. журнал")
                return
            if res == "reboot":
                if step == "all":
                    _save(pending="qbittorrent")
                _finish("reboot", "Нужна перезагрузка приставки" +
                        (": после неё qBittorrent поставится САМ" if step == "all" else ""), reboot=True)
                return
        if step in ("qbittorrent", "all"):
            res = step_qb()
            if res != "ok":
                _save(pending="")
                _finish("fail", "qBittorrent не установился — см. журнал")
                return
        _save(pending="")
        msg = {"entware": "Entware установлен", "qbittorrent": "qBittorrent установлен и запущен",
               "all": "Entware и qBittorrent установлены, qBittorrent запущен"}[step]
        _finish("ok", msg)
    except Exception as e:  # noqa
        say("ОШИБКА: %r" % (e,))
        _finish("fail", "Ошибка: %r" % (e,))


def _finish(result, msg, reboot=False):
    _S.update({"running": False, "result": result, "msg": msg, "reboot": reboot})
    _save(result=result, msg=msg, reboot=reboot, step=_S["step"])
    say("== " + msg)
    if _hooks["after"]:
        try:
            _hooks["after"](result, msg, reboot)
        except Exception:  # noqa
            pass


def start(step):
    if step not in ("entware", "qbittorrent", "all"):
        return {"ok": False, "error": "unknown step"}
    with _lock:
        if _S["running"]:
            return {"ok": False, "error": "уже идёт установка"}
        _S.update({"running": True, "step": step, "result": "", "msg": "", "reboot": False, "log": []})
    try:
        os.remove(_logfile())
    except OSError:
        pass
    _save(step=step, result="", msg="", reboot=False)
    if step != "qbittorrent":
        _save(pending="")
    threading.Thread(target=_job, args=(step,), daemon=True).start()
    return {"ok": True}


def resume_after_boot(monitor):
    """Вызывается сервисом при старте: если после установки Entware ждали перезагрузку — ставим qBittorrent."""
    if pending() != "qbittorrent":
        return False
    for _ in range(90):  # до 3 минут ждём монтирования /opt
        if qbctl.entware_ready() or monitor.waitForAbort(2):
            break
    if monitor.abortRequested():
        return False
    if not qbctl.entware_ready():
        say("После перезагрузки Entware так и не подключился (/opt/bin/opkg нет). Нажмите «Установить Entware» ещё раз.")
        _save(pending="", result="fail", msg="Entware не подключился после перезагрузки")
        _S.update({"result": "fail", "msg": "Entware не подключился после перезагрузки"})
        return False
    say("== Перезагрузка прошла, продолжаю: qBittorrent")
    r = start("qbittorrent")
    if r.get("ok"):
        _save(pending="qbittorrent")  # start() для шага qbittorrent маркер не стирает; снимется по успеху
    return r.get("ok", False)
