"""Кнопки в настройках Phone Remote: установка / запуск / статус / удаление qBittorrent.
Вызывается как RunScript(service.phoneremote,<команда>): entware | qbittorrent | start | stop | status | uninstall | resume"""
import os
import shutil
import json
import socket
import urllib.request
import subprocess
import sys
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import qbctl

ADDON_ID = "service.phoneremote"
ADDON = xbmcaddon.Addon(ADDON_ID)
RU = (xbmc.getLanguage(xbmc.ISO_639_1) or "").lower().startswith("ru")
TITLE = "Phone Remote — qBittorrent"


def T(ru, en):
    return ru if RU else en


def log(m):
    xbmc.log("[%s] installer: %s" % (ADDON_ID, m), xbmc.LOGINFO)


def port():
    try:
        return int(ADDON.getSetting("qb_port") or qbctl.DEFAULT_PORT)
    except ValueError:
        return qbctl.DEFAULT_PORT


def lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return "IP-приставки"


def download_dir():
    return (ADDON.getSetting("tr_dir") or "").rstrip("/") or qbctl.DEFAULT_DL


def autofill():
    """После установки прописываем в настройках аддона доступ к qBittorrent (admin/admin)."""
    for k, v in (("tr_backend", "qbittorrent"), ("qb_host", "127.0.0.1"), ("qb_port", str(qbctl.DEFAULT_PORT)),
                 ("qb_user", "admin"), ("qb_pass", "admin"), ("qb_autostart", "true")):
        ADDON.setSetting(k, v)
    if not (ADDON.getSetting("tr_dir") or "").strip():
        ADDON.setSetting("tr_dir", qbctl.DEFAULT_DL)


def api(path, data=None):
    p = int(ADDON.getSetting("port") or 8090)
    req = urllib.request.Request("http://127.0.0.1:%s%s" % (p, path),
                                 data=json.dumps(data).encode() if data is not None else None,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read().decode() or "{}")


STEPS = {
    "entware": ("Entware", "Будет установлен Entware (менеджер пакетов).\nПосле установки приставка ПЕРЕЗАГРУЗИТСЯ. После перезагрузки запустите этот пункт ЕЩЁ РАЗ (его нужно запускать дважды).",
                "Entware (package manager) will be installed.\nAfter installation the box will REBOOT. After the reboot run this item ONCE MORE (it must be run twice)."),
    "qbittorrent": ("qBittorrent", "Будет установлен qBittorrent (нужен установленный Entware).", "qBittorrent will be installed (Entware must be installed)."),
}


def install(step="entware"):
    title, ru, en = STEPS[step]
    tail_q = T("\nНужен интернет.\n\nНачать?", "\nInternet is required.\n\nStart?") if step == "entware" else T(
        "\nНужен интернет. Логин/пароль qBittorrent: admin / admin.\n\nНачать?",
        "\nInternet is required. qBittorrent login/password: admin / admin.\n\nStart?")
    if not xbmcgui.Dialog().yesno(TITLE, T(ru, en) + tail_q):
        return
    try:
        r = api("/api/install/start", {"step": step})
    except Exception as e:  # noqa
        xbmcgui.Dialog().ok(TITLE, T("Не удалось связаться со службой Phone Remote (%s).\nВключено ли дополнение? Откройте "
                                     "настройки → Дополнения → Мои дополнения → Службы.",
                                     "Cannot reach the Phone Remote service (%s).\nIs the add-on enabled?") % e)
        return
    if not r.get("ok"):
        xbmcgui.Dialog().notification(TITLE, str(r.get("error", "?")), xbmcgui.NOTIFICATION_WARNING, 5000)
        return
    dlg = xbmcgui.DialogProgress()
    dlg.create(TITLE, T("Установка… это займёт несколько минут", "Installing… this takes a few minutes"))
    mon = xbmc.Monitor()
    t0 = time.time()
    st = {}
    while not mon.waitForAbort(1):
        try:
            st = api("/api/install")
        except Exception:  # noqa
            continue
        last = (st.get("log") or [""])[-1]
        dlg.update(min(95, int((time.time() - t0) / 3)), last[:120])
        if dlg.iscanceled():
            dlg.close()
            xbmcgui.Dialog().notification(TITLE, T("Установка продолжается в фоне (журнал — в веб-интерфейсе → Статус)",
                                                   "Installation continues in the background (log: web UI → Status)"),
                                          xbmcgui.NOTIFICATION_INFO, 6000)
            return
        if not st.get("running"):
            break
    dlg.close()
    res = st.get("result")
    tail = "\n".join((st.get("log") or [])[-18:])
    already = step == "entware" and "Entware уже установлен" in tail
    if res in ("ok", "reboot") and step == "entware" and not already:
        # Entware ставится один раз; перезагрузка гарантирует, что /opt подключён и всё стартует чисто
        xbmcgui.Dialog().ok(TITLE, T(
            "Entware установлен. Приставка перезагрузится сейчас.\n\nПосле загрузки запустите пункт "
            "«Установить Entware» ещё раз, затем «Установить qBittorrent».",
            "Entware is installed. The box reboots now.\n\nAfter it starts, run “Install Entware” once more, "
            "then “Install qBittorrent”."))
        xbmc.executebuiltin("Reboot")
    elif res == "ok":
        autofill() if step != "entware" else None
        extra = T("\n\nВеб-интерфейс: http://%s:%s\nЛогин: admin   Пароль: admin", "\n\nWeb UI: http://%s:%s\nLogin: admin   Password: admin") % (
            lan_ip(), qbctl.DEFAULT_PORT) if step != "entware" else T(
            "\n\nТеперь нажмите «Установить qBittorrent».", "\n\nNow press “Install qBittorrent”.")
        xbmcgui.Dialog().ok(TITLE, T("Готово: ", "Done: ") + str(st.get("msg", "")) + extra)
    else:
        xbmcgui.Dialog().textviewer(TITLE, T("Установка не удалась. Журнал:\n\n", "Installation failed. Log:\n\n") + tail)


def resume():
    """Оставлено для совместимости: продолжение после перезагрузки делает сам сервис."""
    return


def do_start():
    if not qbctl.installed():
        xbmcgui.Dialog().ok(TITLE, T("qBittorrent не установлен. Нажмите «Установить qBittorrent».",
                                     "qBittorrent is not installed. Press “Install qBittorrent”."))
        return
    ok, msg = qbctl.start(port())
    if ok:
        xbmcgui.Dialog().notification(TITLE, T("qBittorrent запущен", "qBittorrent is running"),
                                      xbmcgui.NOTIFICATION_INFO, 4000)
    else:
        xbmcgui.Dialog().ok(TITLE, T("Не удалось запустить qBittorrent:\n", "Could not start qBittorrent:\n") + msg)


def do_stop():
    qbctl.stop()
    xbmcgui.Dialog().notification(TITLE, T("qBittorrent остановлен", "qBittorrent stopped"),
                                  xbmcgui.NOTIFICATION_INFO, 4000)


def yn(v):
    return T("да", "yes") if v else T("нет", "no")


def status():
    p = port()
    run = qbctl.running(p)
    txt = T(
        "Entware: %s\nqBittorrent установлен: %s %s\nЗапущен: %s\nАвтозапуск (аддон): %s\nАвтозапуск (autostart.sh): %s\n"
        "Веб-интерфейс: http://%s:%s\nЛогин / пароль: admin / admin\nЗагрузки: %s",
        "Entware: %s\nqBittorrent installed: %s %s\nRunning: %s\nAutostart (add-on): %s\nAutostart (autostart.sh): %s\n"
        "Web UI: http://%s:%s\nLogin / password: admin / admin\nDownloads: %s") % (
        yn(qbctl.entware_ready()), yn(qbctl.installed()), qbctl.version(), yn(run),
        yn((ADDON.getSetting("qb_autostart") or "true") != "false"), yn(qbctl.autostart_has()),
        lan_ip(), p, download_dir())
    xbmcgui.Dialog().textviewer(TITLE, txt)


def strip_autostart():
    try:
        with open(qbctl.AUTOSTART) as f:
            src = f.read().split("\n")
    except OSError:
        return
    out, skip = [], 0
    for ln in src:
        if skip:
            skip -= 1
            continue
        if "# phoneremote-qbittorrent" in ln:
            skip = 2
            continue
        if "phoneremote-install-resume" in ln:
            continue
        out.append(ln)
    with open(qbctl.AUTOSTART, "w") as f:
        f.write("\n".join(out))


def uninstall():
    if not xbmcgui.Dialog().yesno(TITLE, T("Удалить qBittorrent? Скачанные файлы останутся.",
                                           "Remove qBittorrent? Downloaded files are kept.")):
        return
    qbctl.stop()
    opkg = os.path.join(qbctl.OPT, "bin", "opkg")
    if os.access(opkg, os.X_OK):
        try:
            subprocess.run([opkg, "remove", "qbittorrent"], env=dict(os.environ, PATH=qbctl.OPT + "/bin:" + os.environ.get("PATH", "")),
                           capture_output=True, timeout=120)
        except Exception as e:  # noqa
            log("opkg remove: %s" % e)
    strip_autostart()
    if os.path.isdir(qbctl.PROFILE) and xbmcgui.Dialog().yesno(TITLE, T(
            "Удалить также настройки qBittorrent и список торрентов?", "Also delete qBittorrent settings and torrent list?")):
        shutil.rmtree(qbctl.PROFILE, ignore_errors=True)
    xbmcgui.Dialog().notification(TITLE, T("qBittorrent удалён", "qBittorrent removed"), xbmcgui.NOTIFICATION_INFO, 4000)


def reset_login():
    if not qbctl.installed():
        xbmcgui.Dialog().ok(TITLE, T("qBittorrent не установлен.", "qBittorrent is not installed."))
        return
    if not xbmcgui.Dialog().yesno(TITLE, T("Вернуть вход в qBittorrent к admin / admin и перезапустить его?",
                                           "Reset the qBittorrent login to admin / admin and restart it?")):
        return
    ok, msg = qbctl.reset_login(port())
    if ok:
        autofill()
        xbmcgui.Dialog().notification(TITLE, T("Логин и пароль: admin / admin", "Login and password: admin / admin"),
                                      xbmcgui.NOTIFICATION_INFO, 5000)
    else:
        xbmcgui.Dialog().ok(TITLE, T("Не удалось перезапустить qBittorrent:\n", "Could not restart qBittorrent:\n") + msg)


def main():
    cmd = (sys.argv[1] if len(sys.argv) > 1 else "status").lower()
    log("command %s" % cmd)
    if cmd in ("entware", "qbittorrent"):
        return install(cmd)
    {"start": do_start, "stop": do_stop, "status": status, "uninstall": uninstall, "resetlogin": reset_login,
     "resume": resume}.get(cmd, status)()


if __name__ == "__main__":
    main()
